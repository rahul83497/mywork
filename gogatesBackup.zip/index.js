'use strict';
require('dotenv').config();
const {loadDbConfig} = require('./src/utils/bin/global');
loadDbConfig();
require('./src/bin')();
