module.exports = {
    version: '1.0.0',
    title: 'GoGates Backend Documentation.',
    description: 'GPS Backend APIs.',
    termsOfService: "https://swagger.io/terms/",
    contact: {
        name: "Rahul singh"
    },
    license: {
        name: "MIT"
    }
};