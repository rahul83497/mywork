"use strict";
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable("organization", {
      id: {
        allowNull: false,
        autoIncrement: true,
        initialAutoIncrement: 1000,
        primaryKey: true,
        type: Sequelize.INTEGER,
      },
      org_name: {
        type: Sequelize.STRING,
      },
      org_type: {
        type: Sequelize.STRING,
      },
      org_owner: {
        type: Sequelize.STRING,
      },
      status: {
        type: Sequelize.BOOLEAN,
        defaultValue: true,
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE,
      },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable("organization");
  },
};
