//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class CompaniesGates extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  CompaniesGates.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },      
    companies_id: {
      field: 'companies_id',
      type: DataTypes.TEXT
    },
    gate_id: {
      field: 'gate_id',
      type: DataTypes.TEXT
    },               
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'companiesgates',
  });

  CompaniesGates.beforeCreate(async (CompaniesGates, options) => {  
    CompaniesGates.id = uuidv4();
  })
 return CompaniesGates;  
};
