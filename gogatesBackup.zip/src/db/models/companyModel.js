'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class Company extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
    
  Company.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },
    short_name: {
        field: 'short_name',
        type: DataTypes.TEXT
    },
    ename: {
        field: 'ename',
        type: DataTypes.TEXT
    },
    aname: {
      field: 'aname',
      type: DataTypes.TEXT
    },
    phone: {
      field: 'phone',
      type: DataTypes.TEXT
    },
    email: {
      field: 'email',
      type: DataTypes.TEXT
    },
    countries_id: {
      field: 'countries_id',
      type: DataTypes.UUID
    },
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    cr: {
      field: 'cr',
      type: DataTypes.INTEGER
    },             
    logo: {
      field: 'logo',
      type: DataTypes.TEXT
    },    
    
    long: {
      field: 'long',
      type: DataTypes.TEXT
    },  
    lat: {
      field: 'lat',
      type: DataTypes.TEXT
    },    
    company_type_id: {
      field: 'company_type_id',
      type: DataTypes.UUID
    }, 
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
    deletedAt: {
      field: 'deleted_at',
      type: DataTypes.DATE,
      default: null
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'company',
  });

  Company.beforeCreate(async (Company, options) => {  
  Company.id = uuidv4();
  })
 return Company;  
};