//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class Drivers extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  Drivers.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },      
    user_id: {
      field: 'user_id',
      type: DataTypes.UUID
    },
    driver_license: {
      field: 'driver_license',
      type: DataTypes.UUID
    },    
    license_front: {
      field: 'license_front',
      type: DataTypes.UUID
    },    
    license_back: {
      field: 'license_back',
      type: DataTypes.UUID
    },    
    address: {
      field: 'address',
      type: DataTypes.TEXT
    },    
    gate_id: {
      field: 'gate_id',
      type: DataTypes.UUID
    },    
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'drivers',
  });

  Drivers.beforeCreate(async (Drivers, options) => {  
    Drivers.id = uuidv4();
  })
 return Drivers;  
};
