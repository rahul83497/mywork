'use strict';
const {Model} = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class Email extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Email.belongsTo(models.user, {foreignKey: 'user_id', as: 'user'});  
    }
  }
  Email.init({  
    id: {
      unique: true,
      primaryKey: true,
      type: DataTypes.UUID
    },
    user_id: {
      type: DataTypes.UUID
    },
    email: DataTypes.STRING,
    is_verified: DataTypes.BOOLEAN,
    is_primary: DataTypes.BOOLEAN,
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'email',
  });


  Email.beforeCreate(async (doc, options) => {  
    doc.id = uuidv4();
  })
  return Email; 
};