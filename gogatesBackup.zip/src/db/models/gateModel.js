//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class Gate extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  Gate.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },      
    aname: {
      field: 'aname',
      type: DataTypes.TEXT
    },
    ename: {
      field: 'ename',
      type: DataTypes.TEXT
    },
    longititude: {
      field: 'longititude',
      type: DataTypes.TEXT
    },  
    letitude: {
      field: 'letitude',
      type: DataTypes.TEXT
    },             
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'gate',
  });

  Gate.beforeCreate(async (Gate, options) => {  
    Gate.id = uuidv4();
  })
 return Gate;  
};
