//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class NormalUsers extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  NormalUsers.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },      
    user_id: {
      field: 'user_id',
      type: DataTypes.UUID
    },
    company_id: {
      field: 'company_id',
      type: DataTypes.UUID
    },
    gate_id: {
      field: 'gate_id',
      type: DataTypes.UUID
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'normal_users',
  });

  NormalUsers.beforeCreate(async (NormalUsers, options) => {  
    NormalUsers.id = uuidv4();
  })
 return NormalUsers;  
};
