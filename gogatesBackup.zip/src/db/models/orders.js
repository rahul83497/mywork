//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class Orders extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  Orders.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },      
    invoice: {
      field: 'invoice',
      type: DataTypes.TEXT
    },
    number_of_trucks: {
      field: 'number_of_trucks',
      type: DataTypes.INTEGER
    },
    user_id: {
      field: 'user_id',
      type: DataTypes.UUID
    },  
    gate_type_id: {
      field: 'gate_type_id',
      type: DataTypes.UUID
    },             
    status: {
      field: 'status',
      type: DataTypes.TEXT
    },                           
    image: {
      field: 'image',
      type: DataTypes.UUID
    },                             
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'orders',
  });

  Orders.beforeCreate(async (Orders, options) => {  
    Orders.id = uuidv4();
  })
 return Orders;  
};
