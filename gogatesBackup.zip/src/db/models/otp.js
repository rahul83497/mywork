'use strict';
const {Model} = require('sequelize');
const {v4 : uuidv4} = require('uuid');
const { OTP_TYPE } = require('../../utils/enums');
const { convertKeysValueToArray } = require('../../utils/bin/common');

const otpTypes = convertKeysValueToArray(OTP_TYPE);
module.exports = (sequelize, DataTypes) => {
  class Otp extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Otp.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },
    user_id: {
        type: DataTypes.UUID
    },
    customer_number: {
        type: DataTypes.STRING
    },
    otp: DataTypes.STRING,
    valid_till: DataTypes.DATE,
    type: {
        type: DataTypes.STRING,
        value: otpTypes
    },
    wrong_otp_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    send_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    payment_request_id:{
      type: DataTypes.UUID
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'otp',
  });


  Otp.beforeCreate(async (doc, options) => {  
    doc.id = uuidv4();
  })
  return Otp; 
};