'use strict';
const {
  Model
} = require('sequelize');
const {v4 : uuidv4} = require('uuid');
module.exports = (sequelize, DataTypes) => {
  class PasswordHistory extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  PasswordHistory.init({  
    id: {
      type: DataTypes.UUID,
      primaryKey: true
    },
    user_id: {
      type: DataTypes.UUID
    },
    password: {
        type: DataTypes.JSON
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'password_history',
  });
  PasswordHistory.beforeCreate(async (doc, options) => {  
      doc.id = uuidv4();
  });
  return PasswordHistory;  
};