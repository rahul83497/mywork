/** @format */

"use strict";
const { Model } = require("sequelize");
const { v4: uuidv4 } = require("uuid");
const { USER_TYPES } = require("../../utils/enums");
module.exports = (sequelize, DataTypes) => {
  class RolePermission extends Model {
   
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  RolePermission.init(
    {
      
      id: {
        primaryKey: true,
        type: DataTypes.UUID,
      },
      role_id: DataTypes.UUID,
      permission_id: DataTypes.UUID,
      status: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      user_id: {
        type: DataTypes.STRING,        
      },
    },
    {
      freezeTableName: true,
      sequelize,
      modelName: "role_permission",
    }
  );
  RolePermission.beforeCreate(async (doc, options) => {
    
    doc.id = uuidv4();
  });
  return RolePermission; 
};
