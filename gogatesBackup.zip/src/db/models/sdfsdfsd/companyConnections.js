//drivers , user ,transport
'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class CompaniesConnections extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {     
    }
  }
  CompaniesConnections.init({  
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },         
    company_id: {
      field: 'company_id',
      type: DataTypes.UUID
    },
    connected_company_id: {
      field: 'connected_company_id',
      type: DataTypes.UUID
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },    
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'companies_Connections',
  });

  CompaniesConnections.beforeCreate(async (CompaniesConnections, options) => {  
    CompaniesConnections.id = uuidv4();
  })
 return CompaniesConnections;  
};
