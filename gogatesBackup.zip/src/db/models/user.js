'use strict';
const { Model } = require('sequelize');
const {v4 : uuidv4} = require('uuid');

module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here       
      // User.belongsTo(models.account, {foreignKey: 'account_id', as: 'account'});
      // User.belongsTo(models.address, {foreignKey: 'address_id', as: 'address'});
      // User.belongsTo(models.phone, {foreignKey: 'phone_id', as: 'phone'});
      // User.belongsTo(models.phone, {foreignKey: 'comm_phone', as: 'communication_phone'})
      // User.hasOne(models.email_secondary, {foreignKey: 'id', sourceKey: 'comm_email', as: 'communication_email'})
      // User.hasOne(models.account_ind, {foreignKey: 'id', sourceKey: 'account_id', as: 'account_ind'});
      // User.hasOne(models.aggrement, {foreignKey: 'id', sourceKey: 'aggrement_id', as: 'aggrement_doc'})
       /** End of changes */
    }
  }
  User.init({  /** Shivam GLOB-1439 */ 
    id: {
        unique: true,
        primaryKey: true,
        type: DataTypes.UUID
    },
    first_name: {
        field: 'first_name',
        type: DataTypes.TEXT
    },
    last_name: {
      field: 'last_name',
      type: DataTypes.TEXT
    },
    full_name: {
      field: 'full_name',
      type: DataTypes.TEXT
    },
    password: {
      field: 'password',
      type: DataTypes.TEXT
    },    
    user_type: {
      field: 'user_type',
      type: DataTypes.TEXT
    },
      /** Shivam GLOB-1439 Removed Duplicate code */ 
    user_status: {
      field: 'user_status',
      type: DataTypes.TEXT
    },
    valid_from: {
      field: 'valid_from',
      type: DataTypes.DATE
    },
    valid_to: {
      field: 'valid_to',
      type: DataTypes.DATE
    },
    
    address_id: {
      field: 'address_id',
      type: DataTypes.UUID
    },
    phone_id: {
      field: 'phone_id',
      type: DataTypes.UUID
    },  
    dob: {
      type: DataTypes.DATE,
    },
    wrong_count: {
      type: DataTypes.INTEGER
    },
    two_way_auth: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    comm_phone: {
      type: DataTypes.UUID
    },
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
    admin_role_id: {
      type: DataTypes.STRING(10)
    },
    wrong_pass_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    last_login: {
      type: DataTypes.DATE
    },
    remember_token: {
      field: 'remember_token',
      type: DataTypes.TEXT
    },
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'user',
  });

  User.beforeCreate(async (user, options) => {  /** Shivam GLOB-1439 */ 
      user.id = uuidv4();
  })
  return User;  /** Shivam GLOB-1439 */ 
};