'use strict';
const {
  Model
} = require('sequelize');
const { v4: uuidv4 } = require('uuid');
module.exports = (sequelize, DataTypes) => {
  class UserActivityLogs extends Model {  
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  UserActivityLogs.init({  
    id: {
      primaryKey: true,
      type: DataTypes.UUID
    },
    email: DataTypes.STRING,
    user_id: DataTypes.UUID,
    api_url: DataTypes.STRING,
    action: DataTypes.STRING,
    device: DataTypes.STRING,
    date_time: DataTypes.STRING,
    location: DataTypes.STRING,
    browser: DataTypes.STRING,
    ip_address: DataTypes.STRING,
    session_id: DataTypes.STRING(50),
    status: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    isValid: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    message: DataTypes.STRING,
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
  }, {
    freezeTableName: true,  
    sequelize,
    modelName: 'user_activity_logs',
  });
  UserActivityLogs.beforeCreate(async (doc, options) => {  
    doc.id = uuidv4();
})
  return UserActivityLogs;  
};