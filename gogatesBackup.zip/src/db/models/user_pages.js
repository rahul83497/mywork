/** @format */

"use strict";
const { Model } = require("sequelize");
const { v4: uuidv4 } = require("uuid");

module.exports = (sequelize, DataTypes) => {
  class UserPages extends Model {
    /** Arvind GLOB-1861 */
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  UserPages.init(
    {
      /** Arvind GLOB-1861 */
      id: {
        primaryKey: true,
        type: DataTypes.UUID,
      },
      name: DataTypes.STRING,
      url: DataTypes.STRING,
      status: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
    },
    {
      freezeTableName: true /** Arvind GLOB-1861 */,
      sequelize,
      modelName: "user_pages",
    }
  );
  UserPages.beforeCreate(async (doc, options) => {
    /** Arvind GLOB-1861 */
    doc.id = uuidv4();
  });
  return UserPages; /** Arvind GLOB-1861 */
};
