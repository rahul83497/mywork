'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserStatus extends Model { 
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  UserStatus.init({  
    user_id: DataTypes.UUID,
    account_subscription: DataTypes.STRING(20),
    processing_agreement: DataTypes.STRING(20),
    submit_kyc: DataTypes.STRING(20),
    additional_info: DataTypes.STRING(20),
    user_mode: DataTypes.STRING(45),
    createdAt: {
      field: 'created_at',
      type: DataTypes.DATE
    },
    updatedAt: {
      field: 'updated_at',
      type: DataTypes.DATE
    },
  }, {
    freezeTableName: true,
    sequelize,
    modelName: 'user_status',
  });
  return UserStatus;  
};