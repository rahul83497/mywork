
const db = require('../../db/models');
const { loginUser, details, adminverifyTWAEmail, createCompany, updateCompany, addRole, addAdminPage, AdminPagePermission, addAdminRolePermission, addcompanyAdmin, addRoles, addRoleUser, assignUserRole, getCompanyById, getCompanyList, getcompanyAdminById, addCompanyType, getCompanyType
} = require('./admin.service');

const { RESPONSEMESSAGES, MESSAGES, USER_TYPE } = require('../../utils/constants');
const logger = require('../../utils/logger');
const { decodeToken, isValidPass } = require('../../utils/bin/common');
const { OTP_TYPE } = require('../../utils/enums');
const { userRegistration } = require('../users/user.service');
const { findOne } = require('../common/common.queries');

const deleteUserFlag = process.env.DELETE_USER_ALLOWED;

class AdminController {
    constructor() {
        this.Users = db.users;
    }

    /**
     * loing user
     * @param {*} body
     */
    async loginAdmin(body) {
        try {
            const user = await details(body);

            const data = await loginUser({ body, user }); 
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error); 
        }
    }

    /**
     * AdminVerifyOTP
     * @param {*} body
     * @returns
     */
    async adminVerifyOTP(body) {
        try {
            const decode = await decodeToken(body.token);            
            let data = null;
            if(decode.type == OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION) {
                data = await adminverifyTWAEmail({...body, ...decode});
             } else{
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_DATA);
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            if(error.message==='jwt expired'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.LINK_EXPIRED));
              }else if (error.message==='invalid token'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
              }else{
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message|| error); 
          }
        }
    }   
    /**
     * AdminCreateCompany
     * @param {*} body
     * @returns
     */
    async createCompany(body) {
        try {               
            let data = await createCompany({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminUpdateCompany
     * @param {*} body
     * @returns
     */
    async updateCompany(body) {
        try {               
            let data = await updateCompany({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdmingetCompanyById
     * @param {*} body
     * @returns
     */
    async getCompanyById(body) {
        try {               
            let data = await getCompanyById({...body});                       
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminAddCompanytype
     * @param {*} body
     * @returns
     */
    async addCompanyType(body) {
        try {               
            let data = await addCompanyType({...body});                       
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdmingetCompanytype
     * @param {*} body
     * @returns
     */
    async getCompanyType(body) {
        try {               
            let data = await getCompanyType({...body});                       
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminGetCompanyAll
     * @param {*} body
     * @returns
     */
    async getCompanyList(body) {
        try {                           
            let data = await getCompanyList({...body});                       
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminAddRole
     * @param {*} body
     * @returns
     */
    async addRole(body) {
        try {               
            let data = await addRole({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminAddpages
     * @param {*} body
     * @returns
     */
    async addAdminPage(body) {
        try {               
            let data = await addAdminPage({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    /**
     * AdminAddPagePermissiom
     * @param {*} body
     * @returns
     */
    async addAdminPagePermission(body){
        try {               
            let data = await AdminPagePermission({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }  
    
    
    /**
     * AdminAddRolePermissiom
     * @param {*} body
     * @returns
     */
    async addAdminRolePermission(body){
        try {               
            let data = await addAdminRolePermission({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                               
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   
    
    /**
     * AddCompanyAdmin
     * @param {*} body
     * @returns
     */
    async addcompanyAdmin(body){                        
            try {                
                let data;
                isValidPass(body);                                            
                let userRole = await findOne('role_user',{user_id:body.current_user.id})                                    
                if(body.current_user.user_type != USER_TYPE.ADMIN) {
                    if(userRole.role_id != 2 || userRole.role_id != 1){
                        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
                    }
                }
                let exist = await findOne('admins',{company_id: body.company_id})   
                if(exist) throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.COMPANY_ADMIN_REDY_EXIST)
                const user = await userRegistration(body);                
                if(user){
                    let newbody = {}
                    newbody.user_id = user.data.id
                    newbody.company_id = body.company_id
                    newbody.role_id = 4
                    await assignUserRole(newbody);   
                    delete newbody.role_id 
                    data = await addcompanyAdmin(newbody);               
                }
                return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
            } catch (error) {
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
            }
    }   

 /**
     * getCompanyAdmin
     * @param {*} body
     * @returns
     */

    async getcompanyAdmin(body) {
        try {               
            let data = await getcompanyAdminById({...body});                       
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                        
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   



    /**
     * AdduserRole
     * @param {*} body
     * @returns
     */
    async addRoles(body){
        try {               
            let data = await addRoles({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                               
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   

    /**
     * AddRoleUser
     * @param {*} body
     * @returns
     */
    async addRoleUser(body){
        try {               
            let data = await addRoleUser({...body});             
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {                                                               
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message|| error));
          
        }
    }   

}

module.exports = new AdminController();
