const logger = require('../../utils/logger');
const { OTP_TYPE, US_PAYMENT_GATEWAY_TYPE, IND_PAYMENT_GATEWAY_TYPE } = require('../../utils/enums');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const yml = require('yaml');
const os = require('os');
const path = require('path');
const db = require('../../db/models');
const { Op, UUID } = require('sequelize');
const moment = require('moment');
const admZip = require('adm-zip');
//const { EMAILPATTERN, USER_TYPE } = require('../../utils/constants');
const { EMAILPATTERN, USER_TYPE } = require('../../utils/constants');

const { getfiles } = require('../../services/file-upload');
const { REDIRECT_FORGOT_PASSWORD_URL } = require('../../utils/bin/links');
const { sendEmail, sendMailLiveMode } = require('../../services/http');
const { uploadFile } = require('../../services/file-upload');

const { GLOBAL_OBJ } = require('../../utils/bin/global');

const VERIFICATION_LINKS = require('../../utils/constants');
const USER_SERVICE = require('../users/user.service');



const { MESSAGES, RESPONSEMESSAGES, BASE_ATTRIBUTES, SERVER, NUDGE_CHANNEL, CUSTOME_ERROR_CODE_TO_MESSAGE, 
} = require('../../utils/constants');
const { decryptor, validFileExtension, token, Fun_IfElseCondition, 
} = require('../../utils/bin/common');
const { findOne, update, findAll, findAndCountAll, count, lastCreatedDoc, create, remove,
} = require('../common/common.queries');

const {stringFilterQuery, merchantIdResponse, createdAtFilterQuery} = require('../../utils/bin/globalVariables');

const CURRENT_FILE_NAME = 'admin.service';
const ADMIN_SERVICE = {};

/**

 * Create business account
 * @param {*} body
 */
 ADMIN_SERVICE.loginUser = async (payload) => {
    let user_id = '';
    try {
        payload.body.password = decryptor(payload.body.password); 
       
        let user = await ADMIN_SERVICE.details(payload.body);
        user_id = user.id;         
         if (!process.env.NO_EXPIRY_EMAILS.includes(payload.body.email)) {
            await USER_SERVICE.checkIfPasswordIsExpired({ user_id: user.id });
            }           
            const otpDoc = await findOne('otp', {user_id: user.id, type: OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION}); 
          if(otpDoc) await remove('otp', { id: otpDoc.id }); 
        const twa = await USER_SERVICE.applyTwoWayAuth(payload.user, payload.body);
        let data = { email: user.email, user_id: user.id, ...twa,user_type: user.user_type };
        if(twa) {
            data  = {...data, ...twa};
        }
        data.session_id = uuidv4();
        
        user.token = token(data);
        await update('user', {id: user.id}, {wrong_count: 0, wrong_otp_count: 0});
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/admin/login"})
       // await update('user_activity_logs',{id:actLog.dataValues.id}, {user_id:user_id, session_id: data.session_id, message:MESSAGES.LOGGED_IN_SUCCESSFULLY.message})
        delete data.session_id;
        if(twa.type) {
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( 
                MESSAGES.TWO_WAY_AUTHENTICATION_CODE_SENT,
                {token: user.token, full_name: user.full_name, ...data}
            );
        }
        payload.user.token = token({email: payload.user.email, user_id: payload.user.id, session_id: uuidv4()});
        user = { ...payload.user, ...payload.user.user };

        delete user.password;
        delete user.createdAt;
        delete user.updatedAt;
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( 
            MESSAGES.LOGGED_IN_SUCCESSFULLY,
            user
        );
    } catch(error) {
        console.log(error)
        const code = CUSTOME_ERROR_CODE_TO_MESSAGE[error.message] || null;
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/login"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:error?.error?.message ||error.message, isValid:false, user_id:user_id}) 
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error, code); 
    }  /** End of changes */
}


/**
 * Verify two way authenticatio by email
 * @param {*} body
 */
ADMIN_SERVICE.adminverifyTWAEmail = async (body) => {
    let user = await ADMIN_SERVICE.details(body);
    const otp = await findOne('otp', {user_id: body.user_id, type: body.type});
    const current = new Date();
    if (!otp) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.WRONG_OTP_COUNT_ERROR); 
    }
    if(otp.wrong_otp_count >= SERVER.WRONG_OTP_COUNT) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.WRONG_OTP_COUNT_ERROR); 
    }
    if (otp.otp !== body.otp) {
        otp.wrong_otp_count = (otp.wrong_otp_count || 0) + 1;
        otp.save();
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_OTP); 
    }

    if(current > otp.valid_till ) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.OTP_EXPIRED); 
    }

    const data = { email: user.email, user_id: user.id };
    data.session_id = body.session_id;
    const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/verify_otp"})
    await update('user_activity_logs',{id:actLog.dataValues.id}, {email:user.email, user_id:user.user_id, session_id:user.session_id})
    user.token = token(data);
    user = { ...user};

    delete user.password;
    delete user.user;
    await remove('otp', { id: otp.id });
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.OTP_VERIFY_SUCCESSFULLY,user); 
}

ADMIN_SERVICE.details = async (body) => {
    try {  
        
        const criteria = {};
        if(body.email) {
            criteria.email = body.email;
        }
        else if(body.user_id) {
            criteria.user_id = body.user_id;
        }
        else {
            throw MESSAGES.INVALID_DATA;
        }
        let userData = await findOne('email',criteria) 
        const email = await findOne('email', criteria, {
            include: [{
                where: {id: userData.user_id},
                model: db.user,
                as: "user",
                attributes: { exclude: ['valid_to'] }
            }]
        });
        
        if (!email) throw MESSAGES.YOU_DON_NT_HAVE_ADMIN_ACCESS;      
        let user = email.dataValues.user;
        user = { ...email.dataValues, ...user.dataValues };
        if (user.user_status === "0") throw MESSAGES.USER_BLOCKED('Your');
        if (!email.is_verified) {
            await USER_SERVICE.sendEmailVerificationData({ ...body, type: VERIFICATION_LINKS.EMAIL }, user);
            throw MESSAGES.EMAIL_NOT_VERIFIED_LINK_SHARED;
        }
        delete user.user;
        return user;
    } catch (error) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error)
    } 
}

ADMIN_SERVICE.adminverifyTWAEmail = async (body) => {

    let user = await ADMIN_SERVICE.details(body);
    const otp = await findOne('otp', {user_id: body.user_id, type: body.type});
    const current = new Date();
    if (!otp) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.WRONG_OTP_COUNT_ERROR); 
    }
    if(otp.wrong_otp_count >= SERVER.WRONG_OTP_COUNT) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.WRONG_OTP_COUNT_ERROR); 
    }
    if (otp.otp !== body.otp) {
        otp.wrong_otp_count = (otp.wrong_otp_count || 0) + 1;
        otp.save();
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_OTP);
    }

    if(current > otp.valid_till ) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.OTP_EXPIRED); 
    }

    const data = { email: user.email, user_id: user.id };
    data.session_id = body.session_id;
    const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/verify_otp"})
    await update('user_activity_logs',{id:actLog.dataValues.id}, {email:user.email, user_id:user.user_id, session_id:user.session_id})
    user.token = token(data);
    user = { ...user};

    delete user.password;
    delete user.user;
    await remove('otp', { id: otp.id });
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.OTP_VERIFY_SUCCESSFULLY,user); 
}
ADMIN_SERVICE.createCompany = async (body) => {        
    let userRole = await findOne('role_user',{user_id:body.current_user.id})                                    
     if(body.current_user.user_type != USER_TYPE.ADMIN) {
            if(userRole.role_id != 2 || userRole.role_id != 1){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
        }
    let company = await create("company", body)
    let ccData = {};
    ccData.id = uuidv4();
    ccData.company_id = company.id 
    await create("companies_Connections", ccData)

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,company); 
}
ADMIN_SERVICE.updateCompany = async (body) => {

    let data = {}    
    let exist;
    const criteria = { id: body.id };
    exist = await findOne('company',criteria)
    if(!exist) throw MESSAGES.NOT_FOUND 
        Fun_IfElseCondition([body?.name,()=>{
            data.name = body.name
        }])
        
        Fun_IfElseCondition([body?.aname,()=>{
            data.aname = body.name
        }])
        Fun_IfElseCondition([body?.email,()=>{
            data.email = body.email
        }])
        Fun_IfElseCondition([body?.cr,()=>{
            data.cr = body.cr
        }])
        Fun_IfElseCondition([body?.company_type,()=>{
            data.company_type = body.company_type
        }])
        Fun_IfElseCondition([body?.coverImage,()=>{
            data.coverImage = body.coverImage
        }])
        Fun_IfElseCondition([body?.longititude,()=>{
            data.longititude = body.longititude
        }])
        Fun_IfElseCondition([body?.letitude,()=>{
            data.letitude = body.letitude
        }])
        Fun_IfElseCondition([body?.gate,()=>{
            data.gate = body.gate
        }])
        Fun_IfElseCondition([body?.address_id,()=>{
            data.address_id = body.address_id
        }])          

        await update('company',criteria,data)

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN); 
}


ADMIN_SERVICE.createCompanyType = async (body) => {                                              
    let userRole = await findOne('role_user',{user_id:body.current_user.id})                                    
     if(body.current_user.user_type != USER_TYPE.ADMIN) {
            if(userRole.role_id != 2 || userRole.role_id != 1){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
        }
    let company = await create("company", body)
    let ccData = {};
    ccData.id = uuidv4();
    ccData.company_id = company.id 
    await create("companies_Connections", ccData)

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,company); 
}


ADMIN_SERVICE.getCompanyById = async (body) => {        
    let data = await findOne('company',{id:body.id})
    if(!data) throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.RECORDS_NOT_FOUND);
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}


ADMIN_SERVICE.addCompanyType = async (body) => {        
    let userRole = await findOne('role_user',{user_id:body.current_user.id})                                    
     if(body.current_user.user_type != USER_TYPE.ADMIN) {
            if(userRole.role_id != 2 || userRole.role_id != 1){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
        }
    body.id = uuidv4();
    let data = await create("companytypes", body)   
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

ADMIN_SERVICE.getCompanyType = async (body) => {  
    
    let data ;
    let userRole = await findOne('role_user',{user_id:body.current_user.id})                                    
     if(body.current_user.user_type != USER_TYPE.ADMIN) {
            if(userRole.role_id != 2 || userRole.role_id != 1){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
        }    
    if(body.id){
        data = await findOne("companytypes",{id:body.id})          
        if(!data) throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.RECORDS_NOT_FOUND)
    }else{
        data = await findAll("companytypes")   
    }
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}



ADMIN_SERVICE.getcompanyAdminById = async (body) => {        
    let data = await findOne('admins',{company_id:body.company_id})
    if(!data) {
        data = []
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
    }   
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

ADMIN_SERVICE.getCompanyList = async (body) => {         
    let data ={}     
            let query;
            let query1;
            let idQuery = ``;
            let emailQuery = ``;
            let typeQuery = ``;
            let createAtQuery = ``;                      
            let attributes = ``;                      
            if (body.filter){                             
                 Fun_IfElseCondition([body.filter.id , async()=>{
                    idQuery = stringFilterQuery(body.filter.id,fieldName="c.id")
                 }])
                 Fun_IfElseCondition([body.filter.email ,()=>{
                    emailQuery = stringFilterQuery(body.filter.email,fieldName="c.email")
                 }])
                 Fun_IfElseCondition([body.filter.company_type ,()=>{
                    typeQuery = stringFilterQuery(body.filter.company_type,fieldName="ct.company_type")
                 }])
                 Fun_IfElseCondition([body.filter.createdAt ,()=>{
                    createAtQuery = createdAtFilterQuery(body.filter.createdAt,fieldName="c.created_at")
                 }])                            
            }

            attributes = "c.id, c.short_name, c.ename, c.aname, c.phone, c.email, c.countries_id, c.status, c.cr, c.logo, c.long, c.lat, c.company_type_id as companyType, c.created_at  AS createdAt, c.updated_at AS updatedAt, c.deleted_at AS deletedAt"

            query = `select ${attributes} from company as c left join companytypes as ct on ct.id = c.company_type_id where c.id like "%%" ${idQuery} ${emailQuery} ${typeQuery} ${createAtQuery} limit ${body.offset},${body.limit}`;                               
            query1 = `select count(*) as total from company as c left join companytypes as ct on ct.id = c.company_type_id where c.id like "%%" ${idQuery} ${emailQuery} ${typeQuery} ${createAtQuery} limit ${body.offset},${body.limit}`
            const data1 = await db.sequelize.query(query)
            
            let companyData = {}
            for(let i of data1[0]){                
                let companyType =  await findOne('companytypes',{id:i.companyType})                
                i.companyType = companyType.dataValues                
            }

            const counts = await db.sequelize.query(query1)

            data.total = counts[0][0].total
            data.data = data1[0]
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

ADMIN_SERVICE.addRole = async (body) => {    
    let data = await create("admin_roles", body)    
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}
ADMIN_SERVICE.addAdminPage = async (body) => {    
     
    let data = await create("admin_pages", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}
ADMIN_SERVICE.AdminPagePermission = async (body) => {            
    let data = await create("user_permission", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}


ADMIN_SERVICE.addAdminRolePermission = async (body) => {         
    body.id = uuidv4();    
    let data = await create("role_permission", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}



ADMIN_SERVICE.assignUserRole = async (body) => {         
    body.id = uuidv4();        
    let data = await create("role_user", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

ADMIN_SERVICE.addcompanyAdmin = async (body) => {         
    body.id = uuidv4();        
    let data = await create("admins", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

/** Role section  */
ADMIN_SERVICE.addRoles = async (body) => {                   
    let data = await create("roles", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

ADMIN_SERVICE.addRoleUser = async (body) => {         
    body.id = uuidv4();            
    let data = await create("role_user", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

module.exports = ADMIN_SERVICE;