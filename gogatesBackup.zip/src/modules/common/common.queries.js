'use strict';

const db = require('../../db/models');
const { RESPONSEMESSAGES, MESSAGES } = require('../../utils/constants');
const logger = require('../../utils/logger');

const COMMON_REPOSITORY = {};
const CURRENT_FILE_NAME = "common.query";

/**
 * Save business info
 * @param {*} id 
 * @param {*} data 
 * @param {*} userId 
 * @returns 
 */
 COMMON_REPOSITORY.create = async (model, body, transaction = {}) => {
    try {
        return await db[model].create(body, transaction);
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

/**
 * Save business info
 * @param {*} id 
 * @param {*} data 
 * @param {*} userId 
 * @returns 
 */
 COMMON_REPOSITORY.countWithDetails = async (model, criteria, options) => {
    try {
        const where = {
            where: criteria,
        }
        if(options.limit) {
            where.offset = options.offset;
            where.limit = options.limit || 20;
        }
        if(options.attributes)
            where.attributes = options.attributes;

        if(options.include && options.include.length) {
            where.include = options.include;
        }
        return await db[model].findAndCountAll(where);
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

/**
 * Save business info
 * @param {*} id 
 * @param {*} data 
 * @param {*} userId 
 * @returns 
 */
 COMMON_REPOSITORY.count = async (model, criteria) => {
    try {
        return await db[model].count({
            where: criteria,
        });
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}


/**
 * Update user data
 * @param {*} id 
 */
 COMMON_REPOSITORY.update = async (model, where, data, t) => {
    const criteria = {where};
    if(t) criteria.transaction = t.transaction;
    return db[model].update(data, criteria);
}

/**
 * Find one 
 * @param {*} model 
 * @param {*} criteria 
 * @returns 
 */
COMMON_REPOSITORY.findOne = async (model, _criteria, options) => {
    const criteria = {where: _criteria};
    if(options && options.include && options.include.length) 
        criteria.include = options.include;
    if(options && options.attributes && options.attributes.length) 
        criteria.attributes = options.attributes;

    return db[model].findOne(criteria);
}

/**
 * Find one 
 * @param {*} model 
 * @param {*} criteria 
 * @returns 
 */
 COMMON_REPOSITORY.findAll = async (model, _criteria, options) => {
    const criteria = {where: _criteria};
    if(options && options.include && options.include.length) 
        criteria.include = options.include;
    if(options && options.attributes && options.attributes.length) 
        criteria.attributes = options.attributes;
    else if (options && options.attributes) {
        criteria.attributes = options.attributes;
    }
    return db[model].findAll(criteria);
}



/**
 * Find one 
 * @param {*} model 
 * @param {*} criteria 
 * @returns 
 */
COMMON_REPOSITORY.findAndCountAll = async (model, criteria) => {
    return db[model].findAndCountAll(criteria);
}


/**
 * Find one 
 * @param {*} model 
 * @param {*} criteria 
 * @returns 
 */
 COMMON_REPOSITORY.lastCreatedDoc = async (model, criteria) => {
     const where = {
         where: criteria,
         order: [['created_at', 'DESC']],
         limit: 1
    }
    return db[model].findOne(where);
}
 COMMON_REPOSITORY.lastCreatedDocTen = async (model, criteria) => {
     const where = {
         where: criteria,
         order: [['created_at', 'DESC']],
         limit: 10
    }
    return db[model].findAll(where);
}

/**
 * Find one 
 * @param {*} model 
 * @param {*} criteria 
 * @returns 
 */
 COMMON_REPOSITORY.remove = async (model, criteria) => {
    return db[model].destroy({where: criteria});
}

module.exports = COMMON_REPOSITORY;