'use strict';

const db = require('../../db/models');
const {create, update, getConfigs, assignConfig, channelAdd, statesAdd, countryAdd} = require('./config.service');
const { RESPONSEMESSAGES, MESSAGES } = require('../../utils/constants');
const logger = require('../../utils/logger');
const CURRENT_FILE_NAME = "config.controller";

class ConfigController {
    constructor() {
        this.Users = db.users;
    }
    
    /**
     * Submit owner
     * @param {*} body 
     */
     async createConfig(body) {
        try { 
            const data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, await create(body));
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error)  
        } /** End of changes */
    }
    
    /**
     * Edit contact
     * @param {*} body 
     * @returns 
     */
    async editConfig(body) {
        try {   
            const data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,await update(body));
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
                );
            } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error)  
        }  /** End of changes */
    }
    
    /**
     * Get contacts
     */
    async getConfig(body) {
        try {  
            const data =  await getConfigs(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
                );
            } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error)
        }  /** End of changes */
    }
    
    /**
     * Assigning config to user
     * @param {*} body 
     * @returns 
     */
    async assignConfigToUser(body) {
        try { 
            const data = await assignConfig(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
                );
            } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        } /** End of changes */
    }

    /**
     * Add channel to the data
     * @param {*} body 
     */
     async addChannel(body) {
        try {
            const data = await channelAdd(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        }
    }
    /**
     * Add channel to the data
     * @param {*} body 
     */
     async addCountry(body) {
        try {  
            const data = await countryAdd(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        }  /** End of changes */
    }
    
    /**
     * Add channel to the data
     * @param {*} body 
     */
     async addStates(body) {
        try {  
            const data = await statesAdd(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        }  /** End of changes */
    }
    
}


module.exports = new ConfigController();