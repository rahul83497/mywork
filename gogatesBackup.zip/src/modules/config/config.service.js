'use strict';
const { create, update, findOne, findAll, findAndCountAll, countWithDetails } = require('../common/common.queries');
const logger = require('../../utils/logger');
const {MESSAGES, RESPONSEMESSAGES} = require('../../utils/constants');
const { v4: uuidv4 } = require('uuid');
const { Op } = require('sequelize');
const fs = require('fs');
const yml = require('yaml');
const os = require('os');
const path = require('path');
const db = require('../../db/models');
const CURRENT_FILE_NAME = 'config.service';
const CONFIG_SERVICE = {};

/**
 * Create config account
 * @param {*} body 
 */
 CONFIG_SERVICE.create = async (body) => {
    try {
        const or = [
            {
                name: {
                    [Op.like]: body.name
                }
            }
        ];

        if(body.merchant_id) {
            or.push({
                merchant_id: body.merchant_id
            });
        }

        const config = await findOne('config', {
            [Op.or]: or
        });
        if(config && config.merchant_id === body.merchant_id) throw new Error(MESSAGES.MERCHANT_ID_IS_ALREADY_EXISTS);
        if(config) throw new Error(MESSAGES.CONFIG_WITH_NAME_ALREADY_EXISTS);
        return await create('config', body);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

/**
 * Config is exists or not
 */
CONFIG_SERVICE.isExists = async (criteria) => {
    const config = await findOne('config', criteria);
    if(!config) throw new Error('Config not exist')
    return config;
}


/**
 * Create config account
 * @param {*} body 
 */
 CONFIG_SERVICE.update = async (body) => {
    try {
        await CONFIG_SERVICE.isExists({id: body.id});
        const or = [
            {
                name: {
                    [Op.like]: body.name
                }
            },
        ];

        if(body.merchant_id) {
            or.push({
                merchant_id: body.merchant_id
            });
        }

        const config = await findOne('config', {
            id: {
                [Op.not]: body.id
            },
            [Op.or]: or
        });
        if(config && config.merchant_id === body.merchant_id) throw MESSAGES.MERCHANT_ID_IS_ALREADY_EXISTS; 
        if(config) throw MESSAGES.CONFIG_WITH_NAME_ALREADY_EXISTS; 

        return await update('config', {id: body.id}, body);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);  
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}

/**
 * Get all configs
 * @param {*} body 
 */
CONFIG_SERVICE.getConfigs = async (body) => {
    try {
        let criteria = {}; 
        if(body.search) {
           criteria.name = {
                [Op.like]: `%${body.search}%`
           }
        }
        if(body.type_of_config) {
            criteria.type_of_config = body.type_of_config;
        }
        const data = await countWithDetails('config', criteria, body);
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

/**
 * Assign config
 * @param {*} body 
 */
CONFIG_SERVICE.assignConfig = async (body) => {
    try {
        const user = await findOne('user', {id: body.user_id});
        if(!user) throw MESSAGES.USER_NOT_FOUND;
        
        const config = await findOne('config', {id: body.ref_config_id, type_of_config: 'PLATFORM_CONFIG'});
        if(!config) throw (MESSAGES.CONFIG_NOT_FOUND);
        
        user.ref_to_config = config.id;
        await user.save();
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
         /** End of changes */
    }
}

/**
 * Add channel
 * @param {*} body 
 * @returns 
 */
CONFIG_SERVICE.channelAdd = async(body) => {
    try {
        await update('config', { type_of_config: "CHANNEL_CONFIG"}, { data: body.data[0]});  
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN);  
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

CONFIG_SERVICE.countryAdd= async(body)=>{
    try {
        const data = await findOne('countries', {code:body.country_code})
        if(data) throw MESSAGES.COUNTRY_ALREADY_EXIST;
        const id = uuidv4();
        const res = await create('countries',{id, name:body.country,code:body.country_code, currency:body.currency});
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN, res);
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
        /** End of changes */
    }
}

/**
 * Upload Indian States
 * @param {*} body 
 */
CONFIG_SERVICE.statesAdd = async (body) => {
    try {
        const statesData = JSON.parse(body.data.data.toString());
        const data = await findOne('countries', {code:body.country_code})
        if(!data) throw MESSAGES.COUNTRY_NOT_FOUND; 
        if(!statesData.states) throw MESSAGES.INVALID_FILE_FORMAT;  

        let states = [];
        let cities = [];
        statesData.states.forEach( ele => {
            const state_data = {id:uuidv4(), code:ele.state_code, name:ele.state, country_code:body.country_code}
            states.push(state_data);
            ele.cities.forEach(element => {
                const cities_data = {id:uuidv4(), code: element, name:element, state_code: ele.state_code}
                cities.push(cities_data);
            });
        });
        const checkData = await findOne('states',{country_code:body.country_code})
        if(checkData) throw MESSAGES.STATES_CITIES_ALREADY_EXIST; 
        await db.states.bulkCreate(states);
        await db.cities.bulkCreate(cities);
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS); 
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message); 
    }
}
module.exports = CONFIG_SERVICE;