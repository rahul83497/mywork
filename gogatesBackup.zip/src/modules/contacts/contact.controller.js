'use strict';

const db = require('../../db/models');
const {saveContact, updateContact,updatePrimary, getUserContacts, removeContact} = require('./contact.service');
const {saveContactInd, updateContactInd, updatePrimaryInd, getUserContactsInd, removeContactInd} = require('./contact.service.ind');
const { RESPONSEMESSAGES, MESSAGES } = require('../../utils/constants');
const logger = require('../../utils/logger');
const { contactRequest } = require('../authenticating_com/authenticating_com.controller');
const { checkEmailExist } = require('../phone/phone.service');
const { create } = require('../common/common.queries');
const CURRENT_FILE_NAME = "contact.controller";
const { v4: uuidv4 } = require('uuid');

class ContactController {
    constructor() {
        this.Users = db.users;
    }

    /**
     * Submit owner
     * @param {*} body
     */
     async addContact(body) {
        try {  
             if (!body.current_user.account_id) {
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.USER_ACCOUNT_ID_NOT_FOUND);
        }
        let data;
        let emailExist = await checkEmailExist(body);
        if (!emailExist){
            emailExist = await create('email_secondary', {id: uuidv4(), email:body.email, user_id: body._u_id});
        }
        body.email = emailExist.id;

        if(body.current_user.country_code=='IND'){ 
            data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SAVED_SUCCESSFULLY,await saveContactInd(body));
        }else{
            data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SAVED_SUCCESSFULLY,await saveContact(body));
        }
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS, data
        );
    } catch (error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        } 
        /** End of changes */
    }

    /**
     * Edit contact
     * @param {*} body
     * @returns
     */
    async editContact(body) {
        try { 
            if (!body.current_user.account_id) {
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.BUSINESS_INFO_NOT_FOUND);
            }
            let data;
            let emailExist = await checkEmailExist(body);
            if (!emailExist){
                emailExist = await create('email_secondary', {id: uuidv4(), email:body.email, user_id: body._u_id});
            }
            body.email = emailExist.id;

            if(body.current_user.country_code=='IND'){
                data = await updateContactInd(body);
            }else{
                data = await updateContact(body);
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
         } 
          /** End of changes */
    }

    /**
     * Get contacts
     */
    async getContacts(body) {
        try {  
          if (!body.current_user.account_id) {
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.USER_ACCOUNT_ID_NOT_FOUND);
            }
            let data;
            if(body.current_user.country_code=='IND'){
                data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,await getUserContactsInd(body));
            }else{
                 data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,await getUserContacts(body));
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS, data
           );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
    }  /** End of changes */
    }

       /**
    * Update Primary
    * @param {*} body
     * @returns
     */
        async editPrimary(body) {
            if (!body.current_user.account_id) {
                 throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.BUSINESS_INFO_NOT_FOUND);
              }
              let data;
              if(body.current_user.country_code=='IND'){
                  data = await updatePrimaryInd(body);
              }else{
             data = await updatePrimary(body);
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS, data
             );
          }

    /**
     * Remove contact
     * @param {*} body
     * @returns
     */
    async removeContact(body) {
        try {  
            if (!body.current_user.account_id) {
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.USER_ACCOUNT_ID_NOT_FOUND);
            } let data;
            if(body.current_user.country_code=='IND'){
                data = await removeContactInd(body);
            }else{
                data = await removeContact(body);
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_DELETED, data
            );
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        }
    } /** End of changes */

}


module.exports = new ContactController();