'use strict';
const { create, findOne, count, update, findAndCountAll, remove, lastCreatedDoc } = require('../common/common.queries');
const { createAddress, addressData } = require('../address/address.service');
const { addPhoneNumber, phoneData, checkIsPhoneExist } = require('../phone/phone.service');
const { uploadKYCDoc, getAccountDetails } = require('../kyc/kyc.service');
const { createRequest } = require('../../services/authentication');

const logger = require('../../utils/logger');
const {splitNames, getExtension, dobValidate, isValidFileExtension} = require('../../utils/bin/common');
const {MESSAGES, RESPONSEMESSAGES, BASE_ATTRIBUTES} = require('../../utils/constants');
const { v4: uuidv4 } = require('uuid');
const db = require('../../db/models');
const { validateContactRequest } = require('./contacts.repository');
const ownershipShare = process.env.OWNERSHIPSHARE || 5;
const CURRENT_FILE_NAME = 'contact.service';
const CONTACT_SERVICE = {};

/**
 * Create business account
 * @param {*} body
 */
 CONTACT_SERVICE.createContacts = async (data, transaction = {}) => {
    try {
        data.percentage_ownership = `${data.percentage_ownership}`;
        return await create('contact', data, transaction);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw error;
    }
}


/**
 * Save info entries
 * @param {*} body
 * @returns
 */
 CONTACT_SERVICE.saveContact = async (body) => {
    try {
        const account_id = body.current_user.account_id;
        await validateContactRequest(body);
        const account = await getAccountDetails(body);
        let totalPerc = 0;
        let contactId = null;
        account.contacts.map(_c => {
            if(_c.percentage_ownership && !isNaN(_c.percentage_ownership)) {
                contactId = _c.id;
                totalPerc = (totalPerc + (+_c.percentage_ownership));
            }
        })

        if((totalPerc + body.percentage_ownership) > 100) {
            const per = (100 - totalPerc).toFixed(2);
            throw MESSAGES.CONTACT_PERC_CHECK(per); 
        }

        if ((body.percentage_ownership) < ownershipShare) {
            throw MESSAGES.CONTACT_PERC_NOT_ALLOWED(ownershipShare);
        }
        body.contact_id = contactId || uuidv4();
        if (body.contact_id) {
            const counddata = await lastCreatedDoc('contact', { id: body.contact_id })
            if(counddata) body.count= counddata.count;
            else body.count = 0;
        } else body.count = 0;

        return await db.sequelize.transaction(async (t) => { 
            const transaction = { transaction: t };
            body.count = ++body.count;
            const file = await uploadKYCDoc(body.kyc);
            const kycId = uuidv4();
            const kyc = await create('kyc', {id: kycId, ...file}, transaction);
            body.document_id = kyc.id;
            const data = await CONTACT_SERVICE.saveOwnerInfo(body, t);

            if(!account.contact_id) {
                account.contact_id = body.contact_id;
                await update('account', {id: account_id}, {contact_id: body.contact_id});
            }
            return data;
        });
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}


/**
 * Save owner info
 * @param {*} info
 * @param {*} body
 */
 CONTACT_SERVICE.saveOwnerInfo = async (body, t) => {
    try {
        const transaction = { transaction: t };
        body.address.address_id = uuidv4();
        const _addressData = await createAddress(
            addressData({ ...body.address, _u_id: body._u_id }), transaction
        );
        const _phoneData = phoneData({...body, phone_type:body.address_type});
        let phone = await checkIsPhoneExist(_phoneData,  transaction)
        if (!phone){
            phone = await addPhoneNumber(_phoneData,  transaction)           
        }
        body.phone_id = phone.id; 
        body.address_id = _addressData.id;
        let _contactData = CONTACT_SERVICE.contactData(body);
        _contactData = await CONTACT_SERVICE.createContacts(_contactData, transaction);
        _contactData.dataValues.phone = _phoneData.dataValues;
        _contactData.dataValues.address = _addressData.dataValues;
        return _contactData;
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw new Error(error.message);
    }
}

/**
 * Save info entries
 * @param {*} body
 * @returns
 */
 CONTACT_SERVICE.updateContact = async (body) => {
    try {
        const account_id = body.current_user.account_id;
        if(!account_id) throw MESSAGES.BUSINESS_INFO_NOT_FOUND; 
        if(!dobValidate(body.dob)) throw MESSAGES.AGE_IS_MORE_THAN_HUNDRED;  
        const account = await getAccountDetails(body);
        let totalPerc = 0;
        account.contacts.map(_c => {
            if(_c.id !== body.id && _c.percentage_ownership && !isNaN(_c.percentage_ownership)) {
                totalPerc = (totalPerc + (+_c.percentage_ownership));
            }
        })

        if((totalPerc + body.percentage_ownership) > 100) {
            const per = (100 - totalPerc).toFixed(2);
            throw MESSAGES.CONTACT_PERC_CHECK(per);  
        }
        if ((body.percentage_ownership) < ownershipShare){
            throw MESSAGES.CONTACT_PERC_NOT_ALLOWED(ownershipShare);
        }
        const criteria = {count: body.count, id: body.id};
        const contact = await findOne('contact', criteria);
        if(!contact) throw MESSAGES.INVALID_CONTACT_TO_UPDATE; 

        await db.sequelize.transaction(async (t) => {
            const transaction = { transaction: t };

            if(body.kyc.front) {
                const file = await uploadKYCDoc(body.kyc);
                await update('kyc', {id: contact.document_id}, file, transaction);
            }
            const addressRes = body.address;
            addressRes.house_number = addressRes.address;

            await update('address', {id: contact.address_id}, addressRes, transaction);
            await update('phone', {id: contact.phone_id}, {phone_number: body.phone_number, ccc: body.ccc}, transaction);
            let _contactData = CONTACT_SERVICE.contactData(body);
            _contactData = await update('contact', criteria, _contactData, transaction);
            return _contactData;
        });
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.UPDATED_SUCCESSFULLY);   
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}
/**
 * Primary Owner
 * @param {*} body
 * @returns
 */
 CONTACT_SERVICE.updatePrimary = async (body) => {
        try {
            const account_id = body.current_user.account_id;
            if(!account_id) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.BUSINESS_INFO_NOT_FOUND);  
            const criteria = {count: body.count, id: body.id};
            const criteria1 = {id:body.id}
            const contact = await findOne('contact', criteria);
            if(!contact) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_CONTACT_TO_UPDATE);  

            await db.sequelize.transaction(async (t) => {
                const transaction = { transaction: t };
                let is_primaary_false = {is_primary:0}
                await update('contact', criteria1, is_primaary_false, transaction);  
                let _is_primary = {is_primary:body.is_primary};
                _is_primary = await update('contact', criteria, _is_primary, transaction);
                return _is_primary;
            });
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.UPDATED_SUCCESSFULLY);   
        } catch (error) {
            logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);   
        }
    }

/**
 * Get user contacts
 */
CONTACT_SERVICE.getUserContacts = async (body) => {
    try {
        const criteria = {
            where: {id: body.id},
            include: [
                {
                    attributes: { exclude: BASE_ATTRIBUTES.EXCLUDE.PHONE_EXCLUDE },
                    model: db.phone, as: "phone"
                },
                {
                    attributes: { exclude: BASE_ATTRIBUTES.EXCLUDE.ADDRESS_EXCLUDE },
                    model: db.address, as: "address"
                },
                {model: db.kyc, as: "document"},
                {model:db.email_secondary, as : "email_secondary"}
            ]
        }
        if(body.offset) criteria.offset = body.offset;
        if(body.count) criteria.where.count = body.count;
        if(body.limit) criteria.limit = body.limit;

        return await findAndCountAll('contact', criteria);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}


/**
 * Get user contacts
 */
 CONTACT_SERVICE.removeContact = async (body) => {
    try {
        const criteria =  {id: body.id, count: body.count};
        const contact = await findOne('contact', criteria);
        if(!contact) throw MESSAGES.INVALID_CONTACT_TO_DELETE;  
        if(contact.is_primary) throw MESSAGES.PRIMARYUSER_NOT;
        if (contact.address_id) await remove('address', {id: contact.address_id});
        if (contact.document_id) await remove('kyc', {id: contact.document_id});
        if (contact.email_id) await remove('email_secondary', {id: contact.email_id});

        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.REMOVED_SUCCESSFULLY, await remove('contact', criteria));  
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
    }
}


/**
 * Address Data to save
 * @param {*} body
 * @returns
 */
 CONTACT_SERVICE.contactData = (body) => {
    splitNames(body);
    return {
        user_id: body._u_id,
        first_name: body.first_name,
        last_name: body.last_name || '',
        email: body.email,
        full_name: body.full_name,
        ssn: body.ssn,
        passport: body.passport,
        personal_guarantee: body.personal_guarantee,
        percentage_ownership: body.percentage_ownership,
        title: body.title,
        phone_id: body.phone_id,
        id: body.contact_id,
        address_id: body.address_id,
        dob: body.dob,
        document_id: body.document_id,
        count: body.count || 1,
        non_us: body.non_us,
        is_primary:body.is_primary
    }
}



module.exports = CONTACT_SERVICE;