'use strict';

const { RESPONSEMESSAGES, MESSAGES } = require('../../utils/constants');
const logger = require('../../utils/logger');
const db = require('../../db/models');
const { getExtension, isValidFileExtension, dobValidate } = require('../../utils/bin/common');

const CONTACT_REPOSITORY = {};

/**
 * Get profile images
 * @param {*} body 
 */
CONTACT_REPOSITORY.getProfileImages = async (criteria) => {
    try {
        const images = await db.contact.findAll({
            where: criteria,
            attributes: ['document_id']
        });

        if (images.length) return images;

        return null;
    } catch (error) {
        logger.error(`error_${error.message}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

CONTACT_REPOSITORY.validateContactRequest = async (body) => {
    try {
        if(!body.current_user.account_id) { throw MESSAGES.BUSINESS_INFO_NOT_FOUND;}
        if (body.kyc && body.kyc.document_name){
            const ext1 = await getExtension(body.kyc.document_name);
            let validateExtension = await isValidFileExtension(ext1);
            if (!validateExtension ){
                throw MESSAGES.INVALID_FILE_FORMAT;
            }
            if (body.kyc && body.kyc.document_name_back){
                const ext2 = getExtension(body.kyc.document_name_back);
                validateExtension = await isValidFileExtension(ext2);
                if(!validateExtension){
                    throw MESSAGES.INVALID_FILE_FORMAT; 
                }
            }
        }
        if(!dobValidate(body.dob)) throw MESSAGES.AGE_IS_MORE_THAN_HUNDRED;
        return true;
    } catch (error) {
        logger.error(`error_${error.message}`, error);
        throw error;
    }
}

module.exports = CONTACT_REPOSITORY;