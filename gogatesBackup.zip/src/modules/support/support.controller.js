const db = require("../../db/models");
const { RESPONSEMESSAGES, MESSAGES } = require("../../utils/constants");
const { getResolutionTicket } = require("./support.repository");
const { createTicket, getAllTickets, updateTicketResolution, pickTicket } = require("./support.service");

class SupportController {
  constructor() {
    this.support_ticket = db.support_ticket;
  }

  async createTicket(body) {
    try {
      let data = await createTicket(body);
      return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_UPDATED,
        data
      );
    } catch (error) {
      throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
  }

  async getAllTickets(body) {
    try {
      let data = await getAllTickets(body);
      return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESS,
        data
      );
    } catch (error) {
      throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
  }

  async pickTicket(body) {
    try {
      let data = await pickTicket(body);
      return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESS,
        data
      );
    } catch (error) {
      throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
  }

  async updateTicketresolution(body) {
    try {
      let data = await updateTicketResolution(body);
      return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESS,
        data
      );
    } catch (error) {
      throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
  }
  async getTicketresolution(body) {
    try {
      let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESSN,
        await getResolutionTicket(body)
      ); 
      return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESS,
        data
      );
    } catch (error) {
      throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
  }


}

module.exports = new SupportController();
