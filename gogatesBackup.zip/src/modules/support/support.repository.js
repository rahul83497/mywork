const { v4: uuidv4 } = require("uuid");
const db = require("../../db/models");
const { count, create, findAll, update, findOne } = require("../common/common.queries");
const SUPPORT_REPOSITORY = {};
const CURRENT_FILE_NAME = "support.repository";

SUPPORT_REPOSITORY.getSupportTicketCount = async (body) => {
  return count("support_ticket");
};

SUPPORT_REPOSITORY.createNewTicket = async (body) => {
  if (!body.id) body.id = uuidv4();
  return create("support_ticket", body);
};

SUPPORT_REPOSITORY.getAllTicketRecord = async (body) => {
  const data = await db.sequelize.query(
    `select ticket_number, support_type, support_priority, support_subject, support_description, support_status, email as created_by from support_ticket as a join email as b on a.created_by = b.user_id where a.id like "%%" ${body.createdByQuery} ${body.statusQuery} ${body.descriptionQuery} ${body.ticketNumberQuery} ${body.typeQuery} ${body.priorityQuery} ${body.subjectQuery} order by a.created_at desc LIMIT ${body.offset}, ${body.limit};`
  );
  const countData = await db.sequelize.query(
    `select count(*) as total from support_ticket where id like "%%" ${body.createdByQuery} ${body.statusQuery} ${body.descriptionQuery} ${body.ticketNumberQuery} ${body.typeQuery} ${body.priorityQuery} ${body.subjectQuery} ;`
  );
  return {count: countData[0][0].total, data:data[0]}
};

SUPPORT_REPOSITORY.getTickets = async (body) => {
  return findOne("support_ticket", { ticket_number: body.ticket_number });
}

SUPPORT_REPOSITORY.createPickTicketRecord = async(body)=>{
  if(!body.id) body.id = uuidv4()
  return create('ticket_resolution', body)
}

SUPPORT_REPOSITORY.updateTicketResolution = async(body)=>{
  return update('ticket_resolution',{ticket_number: body.ticket_number}, body)
  
}

SUPPORT_REPOSITORY.updateTicketstatus = async(body)=>{
  return update('support_ticket',{ticket_number: body.ticket_number}, body)  
}

SUPPORT_REPOSITORY.getResolutionTicket = async(body)=>{
  const criteria = {where: {ticket_number: body.ticket_number},  order:[['created_at','DESC']]}
  return db['ticket_resolution'].findAll(criteria);  
}

SUPPORT_REPOSITORY.getCustomerEmail = async (body)=> {
  return findOne('email', {user_id: body} ) 
}

module.exports = SUPPORT_REPOSITORY;
