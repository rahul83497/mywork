
const { sendEmail } = require("../../services/http");
const { GLOBAL_OBJ } = require("../../utils/bin/global");
const { ticketstatusQuery, ticketDescriptionQuery, ticketNumQuery, ticketTypeQuery, ticketPriorityQuery, ticketSubjectQuery, ticketCreatedByQuery } = require("../../utils/bin/globalVariables");
const { MESSAGES, RESPONSEMESSAGES, NUDGE_CHANNEL } = require("../../utils/constants");
const { logger } = require("../../utils/logger");
const { create } = require("../common/common.queries");
const {
  getSupportTicketCount,
  createNewTicket,
  getTickets,
  updateTicketstatus,
  getAllTicketRecord,
  createPickTicketRecord,
  getResolutionTicket,
  updateTicketResolution,
  getCustomerEmail,
} = require("./support.repository");
const SUPPORT_SERVICE = {};
const CURRENT_FILE_NAME = "support.service";

SUPPORT_SERVICE.createTicket = async (body) => {
  try {
    const { support_type, support_priority, support_subject, support_description } = body;
    const criteria = { support_type, support_priority, support_subject, support_description };
    const getTicketCount = await getSupportTicketCount(body);
    criteria.ticket_number = `Monay_${parseInt(getTicketCount) + 1}`;
    criteria.created_by = body._u_id;
    criteria.account_id = body.current_user.account_id;
    await createNewTicket(criteria);
    
    const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;         
        const data = {
            ToEmailAddress: "support@monay.com",
            toName: "Support Team",
            channel: NUDGE_CHANNEL.EMAIL,
            mergeTags: [
                { "tagName": "Ticket_Id", "tagValue": criteria.ticket_number },
                { "tagName": "Priority", "tagValue": support_priority },
                { "tagName": "Type", "tagValue": support_type },
                { "tagName": "Subject", "tagValue": support_subject },
                { "tagName": "Email", "tagValue": body.current_user.email },
            ],
            nudgeId: nudgeConfig.notify_to_csr.hostid
        };
        const mailData =   await sendEmail(data);
        await create('nudge_logs',{user_id: body._u_id, email_or_phone:"support@monay.com", url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"NOTIFY_TO_CSR",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors })

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
      MESSAGES.TICKET_CREATED_SUCCESSFULLY
    );
  } catch (error) {
    logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
    throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
  }
};

SUPPORT_SERVICE.getAllTickets = async (body) => {
  try {
    let createdByQuery = ``;
    let statusQuery = ``;
    let descriptionQuery = ``;
    let ticketNumberQuery = ``;    
    let typeQuery = ``;
    let priorityQuery = ``;
    let subjectQuery = ``;

    if (body.filter) {
      statusQuery = ticketstatusQuery(body.filter);
      descriptionQuery = ticketDescriptionQuery(body.filter);
      ticketNumberQuery = ticketNumQuery(body.filter);    
      typeQuery = ticketTypeQuery(body.filter);
      priorityQuery = ticketPriorityQuery(body.filter);
      subjectQuery = ticketSubjectQuery(body.filter);
      createdByQuery = ticketCreatedByQuery(body.filter);
    }
    if (body.current_user.user_type == 2) {
      createdByQuery = `and account_id = "${body.current_user.account_id}"`;
    }
    const res = await getAllTicketRecord({
      createdByQuery,
      statusQuery,
      descriptionQuery,
      ticketNumberQuery,      
      typeQuery,
      priorityQuery,
      subjectQuery,
      ...body,
    });
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
      MESSAGES.DEFAULT_SUCCESSN,
      res
    );
  } catch (error) {
    logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
  }
};

SUPPORT_SERVICE.pickTicket = async (body) => {
  try {
    const { ticket_number, picked_by, assigned_to } = body;
    const ticket = await getTickets(body);
    if (!ticket) throw MESSAGES.INVALID_SUPPORT_TICKET;
    const criteria = { ticket_number, picked_by, assigned_to };
    criteria.picked_at = new Date().toISOString();
    await createPickTicketRecord(criteria);
    const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;         
        const data = {
            ToEmailAddress: assigned_to,
            toName: "Team",
            channel: NUDGE_CHANNEL.EMAIL,
            mergeTags: [
                { "tagName": "Ticket_Id", "tagValue": ticket_number },
                { "tagName": "Priority", "tagValue": ticket.support_priority },
                { "tagName": "Type", "tagValue": ticket.support_type },
                { "tagName": "Subject", "tagValue": ticket.support_subject },
            ],
            nudgeId: nudgeConfig.notify_to_assignee.hostid
        };
        const mailData =   await sendEmail(data);
        await create('nudge_logs',{user_id:  body._u_id, email_or_phone: assigned_to, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"NOTIFY_TO_ASSIGNEE",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors })
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
      MESSAGES.TICKET_ASSIGNED_SUCCESSFULLY
    );
  } catch (error) {
    logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
  }
};

SUPPORT_SERVICE.updateTicketResolution = async (body) => {
  try {
    const { ticket_number, resolved_by, resolution_notes, support_status } = body;
    const ticket = await getTickets(body);
    if (!ticket) throw MESSAGES.INVALID_SUPPORT_TICKET;
    const isPicked = await getResolutionTicket(body);
    if(!isPicked) throw MESSAGES.TICKET_NOT_PICKED_YET;
    await updateTicketstatus(body)
    const criteria = { ticket_number, resolved_by, resolution_notes };
    await updateTicketResolution(criteria);
    const customerMail = await getCustomerEmail(ticket.created_by)
    if(support_status == "RESOLVED"){
      const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;         
        const data = {
            ToEmailAddress: customerMail.email,
            toName: "Dear",
            channel: NUDGE_CHANNEL.EMAIL,
            mergeTags: [
                { "tagName": "ticketId", "tagValue": ticket_number },
                { "tagName": "resolutionNotes", "tagValue": resolution_notes },
                { "tagName": "customerEmail", "tagValue": customerMail.email },
            ],
            nudgeId: nudgeConfig.notify_to_customer_on_resolve.hostid
        };
        const mailData =   await sendEmail(data);
        await create('nudge_logs',{user_id: body._u_id, email_or_phone: customerMail.email, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"NOTIFY_TO_CUSTOMER",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors })
    }
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
      MESSAGES.TICKET_RESOLUTION_UPDATED
    );
  } catch (error) {
    logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
  }
};

module.exports = SUPPORT_SERVICE;
