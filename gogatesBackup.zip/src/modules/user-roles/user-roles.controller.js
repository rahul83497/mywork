/** @format */

const db = require("../../db/models");
const { RESPONSEMESSAGES, MESSAGES } = require("../../utils/constants");
const {
	rolesGet,
	pagesAdd,
	rolesDelete,
	permissionAdd,
	addUserRole,
	getRolePermission,
	registerSubUser,
	assignPermission,
	getUserRolesPermisson,
	pagesUpdate,
	updateUserRole,
	updateSubUsrStatus,
	deleteSubUsr,
	permissionUpdate,
	getSubAdminLists,
	revokePermission,
	updateAssignedPermission,
	addAdminProfile,
	updateAdminProfile,
	deleteAdminProfile,
} = require("./user-roles.services");
const { isValidPass } = require("../../utils/bin/common");
const CURRENT_FILE_NAME = "user-role.controller";

class UserRolesController {
	constructor() {
		this.Users = db.users;
	}

	/**
	 * Add Pages
	 */
	async addPages(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = await pagesAdd(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}

	/**
	 * Update Pages
	 */
	async updatePages(body) {
		try {
			/** Arvind GLOB-1861 updated below changes*/
			let data = await pagesUpdate(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}

	/**
	 * delete Page or Permission or role
	 */
	async deleteRoles(body) {
		try {
			let data = await rolesDelete(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		}
	}

	/**
	 * Get Roles
	 * @param {*} body
	 * @returns
	 */
	async getRoles(body) {
		try {
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await rolesGet(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}

	/**
	 * Add permission
	 * @param {*} body
	 * @returns
	 */
	async addPermission(body) {
		try {
			/** Arvind GLOB-1861 updated below changes*/
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await permissionAdd(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}
	async updatePermission(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = await permissionUpdate(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}
	async permissionAssign(body) {
		try {
			/** Arvind GLOB-1861 updated below changes */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await assignPermission(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}

	async revokePermission(body) {
		try {
			/** Arvind GLOB-1861 updated below changes */
			let data = await revokePermission(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}
	async updateAssignedPermission(body) {
		try {
			let data = await updateAssignedPermission(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		}
	}
	async addRoles(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await addUserRole(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}
	async getUserRole(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await getRolePermission(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}
	async getAdminRoles(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await getUserRolesPermisson(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}

	async registerSubUser(body) {
		try {
			/** Arvind GLOB-1861 */
			isValidPass(body);
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SUCCESS_MESSAGE_GLOBAL("Sub user", "created"), await registerSubUser(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		}
	}
	async updateAdmin(body) {
		try {
			/** Arvind GLOB-1861 */
			let data = await updateUserRole(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		} /** End of changes */
	}
	async getSubAdminList(body) {
		try {
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await getSubAdminLists(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}

	async updateSubUserStatus(body) {
		try {
			let data = await updateSubUsrStatus(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		}
	}

	async deleteSubUser(body) {
		try {
			let data =  await deleteSubUsr(body);
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
		}
	}
	async addAdminProfile(body) {
		try {
			/** Arvind GLOB-1828 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await addAdminProfile(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}
	async updateAdminProfile(body) {
		try {
			/** Arvind GLOB-1828 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await updateAdminProfile(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}
	async deleteAdminProfile(body) {
		try {
			/** Arvind GLOB-1828 */
			let data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await deleteAdminProfile(body));
			return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
		} catch (error) {
			throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); /** Arvind GLOB-1861 */
		}
	}
}

module.exports = new UserRolesController();
