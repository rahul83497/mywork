/** @format */

const db = require("../../db/models");
const { logger } = require("../../utils/logger");
const { v4: uuidv4 } = require("uuid");

const { GLOBAL_OBJ } = require('../../utils/bin/global');
const { token, Fun_checkAndCondition } = require('../../utils/bin/common');
const { sendEmail } = require("../../services/http");
const { REDIRECT_EMAIL_VERIFICATION } = require('../../utils/bin/links');
const { encodePassword, splitNames, getSplitStr, decryptor, toUpperCaseArray, Fun_IfElseCondition
} = require("../../utils/bin/common");
const { RESPONSEMESSAGES, MESSAGES, BASE_ATTRIBUTES, USER_TYPE, SERVER, NUDGE_CHANNEL } = require("../../utils/constants");
const { create, findAll, update, findOne, findAndCountAll, lastCreatedDoc, remove } = require("../common/common.queries");

const { userFullNameResponse, textFilterQuery, userstatusResponse, roleNameResponse, createdAtResponse,
	checkPermissionResult
} = require("../../utils/bin/globalVariables");
const CURRENT_FILE_NAME = "usr-roles.service";
const ROLES_SERVICE = {};

const userRoleMgmtLogsUpdate = async (body) => {
	let activityLog = null;
	if (body.api_url) {
		activityLog = await lastCreatedDoc("user_activity_logs", { api_url: body.api_url });
	}
	if (!activityLog) {
		return;
	}
	const dataToUpdate = {};
	Fun_IfElseCondition([body.message,() => { dataToUpdate.message = body.message.substring(0, 255);}]);
	Fun_IfElseCondition([body.isValid,() => { dataToUpdate.isValid = body.isValid;}]);
	await update("user_activity_logs", { id: activityLog.id }, { message: body.message, isValid: body.isValid });
	return true;
};
ROLES_SERVICE.pagesAdd = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		body.name = body.name.trim();
		body.url = body.url.trim(); /** Arvind GLOB-1861 */
		Fun_IfElseCondition([!body.name.length,	() => {	throw MESSAGES.NAME_REQUIRED; }]);
		Fun_IfElseCondition([!body.url.length, () => { throw MESSAGES.INVALID_DATA;}]); /** Arvind Validation added */
		const page = await findOne("user_pages", {
			name: body.name,
			url: body.url,
			status: true,
		});
		if (page) throw MESSAGES.PAGES_ALREADY_EXIST;
		const result = await create("user_pages", {
			name: body.name,
			url: body.url,
		});

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/page/add",
			isValid: true,
			message: `page ${body.name} created by ${createdBy}`,
		});

		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, result);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/page/add",
			isValid: false,
			message: `Failed: ${createdBy} failed to create page ${body.name} and Message: ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.pagesUpdate = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name; /** Arvind GLOB-1861 */
	try {
		body.name = body.name.trim();
        body.url = body.url.trim();
        Fun_IfElseCondition([!body.name.length, ()=>{ throw MESSAGES.NAME_REQUIRED }]);
        Fun_IfElseCondition([!body.url.length, ()=>{ throw MESSAGES.INVALID_DATA }]); /** Arvind Validation added */
		const page = await findOne("user_pages", { id: body.id, status: true });
		if (!page) throw MESSAGES.PAGE_ID_NOT_VALID;
		await update("user_pages", { id: body.id }, { name: body.name, url: body.url });
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/page/update",
			isValid: true,
			message: `${createdBy} updated pageid ${body.id} from name ${page.name} to ${body.name} and url ${page.url} to ${body.url}`,
		});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/page/update",
			isValid: false,
			message: `Failed:${createdBy} failed to update page name to ${body.name} and url to ${body.url} for pageId: ${body.id} and Message:${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};

ROLES_SERVICE.permissionAdd = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		Fun_IfElseCondition([ body.data.length < 1, () => {	throw MESSAGES.INVALID_DATA; }]);
		const dataArray = [];
		for (let data1 of body.data) {
			if (!data1?.name.length) {
				throw MESSAGES.INVALID_DATA;
			} /** Arvind GLOB-1861 */
			data1.name = toUpperCaseArray(data1.name);
			const checkPage = await findOne("user_pages", {
				id: data1.page_id,
				status: true,
			});
			if (!checkPage) {
				throw MESSAGES.PAGE_ID_NOT_VALID;
			}
			let checkPermissionName = await db.sequelize.query(`select * from user_permission where page_id = "${data1.page_id}"`);
			checkPermissionName = checkPermissionName[0];
			const checkPerm = await checkPermissionResult(checkPermissionName, data1);
			if (!checkPerm) {
				throw MESSAGES.PERMISSION_NOT_ALLOWED;
			} /** Arvind GLOB-1861 */
			dataArray.push({
				id: uuidv4(),
				name: data1.name,
				page_id: data1.page_id,
			});
		}
		const result = db.user_permission.bulkCreate(dataArray);
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/page/add",
			isValid: true,
			message: `permission added for pages ${JSON.stringify(dataArray)} and created by ${createdBy}`,
		});
		return result;
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/permission/add",
			isValid: false,
			message: `user ${createdBy} and Error is ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); /** Arvind GLOB-1861 */
	}
};
ROLES_SERVICE.permissionUpdate = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		const page = await findOne("user_permission", {
			id: body.id,
			status: true,
		});
		if (!page) throw MESSAGES.PERMISSION_ID_NOT_ALLOWED;
		Fun_IfElseCondition([ !body.name, () => { throw MESSAGES.NAME_REQUIRED; }]);
		body.name = body.name.trim(); /** Arvind GLOB-1861 */
		Fun_IfElseCondition([!body.name, () => { throw MESSAGES.NAME_REQUIRED; }]);
		body.name = toUpperCaseArray([body.name]);
		await update("user_permission", { id: body.id }, { name: body.name });
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/permission/update",
			isValid: true,
			message: `For pageId ${body.id} permission updated from ${page.name} to ${body.name} created by ${createdBy}`,
		});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/permission/update",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.assignPermission = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if (body.permission_id.length) {
			let roleExists = {};
			if(body.role_id == 1){
				roleExists = await findOne("user_roles", {
					id: body.role_id,
					status: true,
				});
			}else{
				Fun_IfElseCondition([!body.current_user.account_id, ()=>{
					throw MESSAGES.ACCOUNT_NOT_EXISTS;
				}])
				roleExists = await findOne("user_roles", {
					id: body.role_id,
					account_id: body.current_user.account_id,
					status: true,
				});
			}
			Fun_IfElseCondition([!roleExists, ()=>{
				throw MESSAGES.ROLE_ID_NOT_VALID;
			}]);
			const dataArray = [];
			for (let index of body.permission_id) {
				/** Arvind GLOB-1861 */
				const data1 = index;
				const checkPerm = await findOne("user_permission", {
					id: data1,
					status: true,
				});
				if (!checkPerm) throw MESSAGES.PERMISSION_ID_NOT_ALLOWED; /** Arvind GLOB-1861 */
				const permissionAlreadyExist = await findOne('role_permission', {role_id: body.role_id, permissinon_id: data1, user_type: "2"});
				if(permissionAlreadyExist){
					continue;
				}
				dataArray.push({
					id: uuidv4(),
					role_id: body.role_id,
					permissinon_id: data1,
					user_type: "2",
				});
			}
			Fun_IfElseCondition([!dataArray.length, ()=>{
				throw MESSAGES.PERMISSION_ALREADY_EXIST;
			}])
			const result = await db.role_permission.bulkCreate(dataArray);
			await userRoleMgmtLogsUpdate({
				api_url: "/v1/user/roles/assign_permission",
				isValid: true,
				message: `permission for ${JSON.stringify(body.permissinon_id)} added for user ${body.role_id} by ${createdBy}`,
			});
			return result;
		} else {
			return MESSAGES.INVALID_DATA; /** Arvind GLOB-1861 */
		}
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/assign_permission",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.revokePermission = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		Fun_IfElseCondition([ body.role_id == 1, () => { throw MESSAGES.DO_NOT_HAVE_PERMISSION;}]);
		Fun_IfElseCondition([ body.permission_id.length < 1, () => { throw MESSAGES.INVALID_DATA;},]);
		const checkRole = await findOne("user_roles", {
			id: body.role_id,
			account_id: body.current_user.account_id,
			status: true,
		});
		if (!checkRole) throw MESSAGES.ROLE_ID_NOT_VALID;
		for (let index of body.permission_id) {
			/** Arvind GLOB-1861 */
			const data1 = index;
			const checkPerm = await findOne("user_permission", {
				id: data1,
				status: true,
			});
			if (!checkPerm) throw MESSAGES.PERMISSION_ID_NOT_ALLOWED;
			await remove("role_permission", {
				permissinon_id: data1,
				role_id: body.role_id,
				status: true,
				user_type: "2",
			});
		} /** Arvind GLOB-1861 */
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/revoke_permission",
			isValid: true,
			message: `permission revoked of ${JSON.stringify(body.permission_id)} for user ${body.role_id} by ${createdBy}`,
		});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.UPDATED_SUCCESSFULLY);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/revoke_permission",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.updateAssignedPermission = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		Fun_IfElseCondition([
			body.role_id == 1,
			() => {
				throw MESSAGES.DO_NOT_HAVE_PERMISSION;
			},
		]);
		Fun_IfElseCondition([body.permissionArr.length < 1,	() => {
			throw MESSAGES.INVALID_DATA;
		}]);
		const roleExists = await findOne("user_roles", {
			id: body.role_id,
			account_id: body.current_user.account_id,
			status: true,
		});
		Fun_IfElseCondition([!roleExists, () => {
			throw MESSAGES.ROLE_ID_NOT_VALID;
		}]);
		for (let element of body.permissionArr) {
			let { pageId, pagePermissionId, is_checked } = element;
			const permissionIdsForPage = await findAll("user_permission", {
				page_id: pageId,
				status: true,
			});
			/** Arvind GLOB-1861 */
			for (let item of permissionIdsForPage) {
				if (item.id && (await findOne("role_permission", {role_id: body.role_id, permissinon_id: item.id, user_type: "2"}))) {
					await remove("role_permission", {
						role_id: body.role_id,
						permissinon_id: item.id,
					});
				}
			}
			if (is_checked) {
				const permissionExist = await findOne("user_permission", {
					id: pagePermissionId,
					status: true,
				});
				if (permissionExist) {
					await create("role_permission", {
						id: uuidv4(),
						role_id: body.role_id,
						permissinon_id: pagePermissionId,
						user_type: "2",
					});
				} else {
					throw MESSAGES.PAGE_PERMISSION_DOES_NOT_EXIST;
				}
			}
		}
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/update_assigned_permission",
			isValid: true,
			message: `permission updated ${JSON.stringify(body.permissionArr)} for ${body.role_id} by ${createdBy}`,
		});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.UPDATED_SUCCESSFULLY);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/update_assigned_permission",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.rolesGet = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		let data;
		const criteria = { where: { status: true } };
		if (body.offset) criteria.offset = body.offset;
		if (body.limit) criteria.limit = body.limit; /** Arvind modify below changes to get sorted data */
		if (body.type === "PAGE") {
			criteria.order = [["name", "ASC"]];
			criteria.attributes = ["id", "name", "url"];
			data = await findAndCountAll("user_pages", criteria);
		} else if (body.type === "ROLE") {
			Fun_IfElseCondition([!body.current_user.account_id, ()=>{
				throw MESSAGES.ACCOUNT_NOT_EXISTS;
			}])
			const conditions = {
				account_id: body.current_user.account_id,
				status: true
			};
			criteria.attributes = ["id", "role_name", "account_id"];
			data = await findAll("user_roles",conditions, criteria);
		} else {
			criteria.attributes = ["id", "name", "url"];
			data = await findAndCountAll("user_pages", criteria);
			if (data && data.rows) {
				for (let values of data.rows) {
					/** Arvind GLOB-1920 */
					const page = await findAll("user_permission", { page_id: values.dataValues.id }, { attributes: ["id", "name"] });
					values.dataValues.permission = page;
				}
			}
		}
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/get/",
			isValid: true,
			message: `${body.type} details taken  by ${createdBy} from db`,
		});
		return data;
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/get/",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); /** Arvind GLOB-1861 */
	}
};
ROLES_SERVICE.rolesDelete = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if (body.type === "ROLE") {
			if(!body.current_user.account_id){
				throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
			}
			const checkRole = await findOne("user_roles", { id: body.id, account_id: body.current_user.account_id });
			Fun_IfElseCondition([ !checkRole, () => { throw MESSAGES.ROLE_ID_NOT_VALID; }]);
			const rolePermissionAssigned = await findAll("role_permission", {
				role_id: body.id,
				user_type: "2",
			});
			Fun_IfElseCondition([ rolePermissionAssigned.length != 0, () => {
				throw MESSAGES.REMOVE_EXISTING_PERMISSION;
			}]);
			await remove("user_roles", { id: body.id, account_id: body.current_user.account_id }); /** Arvind GLOB-1861 */
		} else if (body.type === "PERMISSION") {
			const checkPerm = await findOne("user_permission", { id: body.id });
			Fun_IfElseCondition([!checkPerm, () => { throw MESSAGES.PERMISSION_ID_NOT_ALLOWED; }]);
			await remove("user_permission", { id: body.id }); /** Arvind GLOB-1861 */
		} else {
			const pageDetails = await findOne("user_pages", {
				id: body.id,
			}); /** Arvind GLOB-1861 */
			Fun_IfElseCondition([ !pageDetails,	() => {	throw MESSAGES.PAGE_ID_NOT_VALID;}]);

			const userPermissionDetails = await findAll("user_permission", {
				page_id: body.id,
			});
			if (!userPermissionDetails.length) {
				await remove("user_pages", { id: body.id });
				await userRoleMgmtLogsUpdate({
					api_url: "/v1/user/roles/delete/",
					isValid: true,
					message: `${body.type} with id ${body.id} deleted by ${createdBy} from db`,
				});
				return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_DELETEDN);
			}
			let pageAssignedFlag = false; /** Arvind GLOB-1861 */
			for (let userPermission of userPermissionDetails) {
				const rolePermissionDetails = await findAll("role_permission", {
					permissinon_id: userPermission.id,
				});
				if (rolePermissionDetails.length) {
					pageAssignedFlag = true;
					break;
				}
			}
			Fun_IfElseCondition([
				pageAssignedFlag,
				() => {
					throw MESSAGES.PAGE_CAN_NOT_BE_DELETED;
				},
			]);
			/** Arvind GLOB-1293 */
			await remove("user_permission", { page_id: body.id });
			await remove("user_pages", { id: body.id });
		}
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/delete/",
			isValid: true,
			message: `${body.type} with id ${body.id} deleted by ${createdBy} from db`,
		});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_DELETEDN);
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/delete/",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};
ROLES_SERVICE.addUserRole = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		const checkRole = await findOne("user_roles", {
			role_name: body.role_name,
			account_id: body.current_user.account_id
		});
		if (checkRole) throw MESSAGES.ROLE_ALREADY_EXIST;
		if(!body.current_user.account_id){
			throw MESSAGES.ACCOUNT_NOT_EXISTS;
		}
		const userRoleData = {
			role_name: body.role_name,
			account_id: body.current_user.account_id
		};
		await create("user_roles", userRoleData); /** Arvind GLOB-1861 */

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/add",
			isValid: true,
			message: `${body.role_name} added by ${createdBy} into db`,
		});
		return await db["user_roles"].findOne({
			order: [["createdAt", "DESC"]],
			limit: 1,
			attributes: ["id", "role_name", "account_id"],
		});
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/add",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); /** Arvind GLOB-1759 */
	}
};
ROLES_SERVICE.getRolePermission = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if(!body.current_user.account_id && body.current_user.admin_role_id != 1){
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}
		let roleQuery = `select u.id, u.role_name, rp.role_id, rp.permissinon_id, perm.name as permission, pages.name as page_name, pages.url as page_url  from user_roles as u  join role_permission as rp on rp.role_id = u.id join user_permission as perm on perm.id = rp.permissinon_id join user_pages as pages on pages.id = perm.page_id where rp.user_type= '2' and u.id = "${body.current_user.admin_role_id}"`;

		if(body.current_user.admin_role_id !=1 && body.current_user.account_id){
			roleQuery += ` and u.account_id = "${body.current_user.account_id}";`
		}
		const data = await db.sequelize.query(roleQuery);
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/user_role",
			isValid: true,
			message: `getting all role permissions by ${createdBy} from db`,
		});

		return data[0]; /** Arvind GLOB-1861 */
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/user_role",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message);
	}
};

ROLES_SERVICE.getUserRolesPermisson = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if(!body.current_user.account_id && body.current_user.admin_role_id != 1){
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}
		let roleQuery = ``;
		if (body.role_name) {
			const role = await getSplitStr(body.role_name);
			if (role[0] === "contains") {
				roleQuery = `and role_name like "%${role[1]}%"`;
			}
			if (role[0] === "startswith") {
				roleQuery = `and role_name like "${role[1]}%"`;
			}
			if (role[0] === "isequal") {
				roleQuery = `and role_name = "${role[1]}"`;
			}
			if (role[0] === "isnotequal") {
				roleQuery = `and role_name != "${role[1]}"`;
			}
		}
		const adminRoles = await db.sequelize.query(`select id, role_name from user_roles where account_id = "${body.current_user.account_id}" ${roleQuery} order by createdAt desc LIMIT ${body.offset}, ${body.limit};`);
		const superAdminRole = await db.sequelize.query(`select id, role_name from user_roles where id = 1`);
		const counts = await db.sequelize.query(`select count(*) as total from user_roles where account_id = "${body.current_user.account_id}" ${roleQuery}`);
		adminRoles[0].push(superAdminRole[0]?.[0]);
		counts[0][0].total+=1;
		for (let i of adminRoles[0]) {
			/** Arvind GLOB-1439 */
			const values = i;
			const rolesPer = await db.sequelize.query(
				`select pages.name as page_name, pages.url, perm.name as permission, perm.id as permission_id from role_permission as rp join user_permission as perm on rp.permissinon_id = perm.id join user_pages as pages on perm.page_id = pages.id where rp.user_type = '2' and rp.role_id = ${values.id}`
			);
			values.pages = rolesPer[0] || "null";
		}

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/get_all_permission/",
			isValid: true,
			message: `getting admin roles permissions for ${createdBy} from db`,
		});
		return { count: counts[0][0].total, data: adminRoles[0] };
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/roles/get_all_permission/",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message); /** Arvind GLOB-1861 */
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message);
	}
};

ROLES_SERVICE.registerSubUser = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		Fun_IfElseCondition([Fun_checkAndCondition(!body.current_user.account_id, body.current_user.admin_role_id != 1), ()=>{
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}]);
		Fun_IfElseCondition([!body.current_user.account_id, ()=>{
			throw MESSAGES.MERCHANT_ID_REQUIRED;
		}]);
		//validate user ans subuser email domain
		const userSplittedEmail = body.current_user.email.split('@');
		const subUserEmailSplit = body.email.split('@');
		const userDomain = userSplittedEmail[userSplittedEmail.length-1];
		const subUserDomain = subUserEmailSplit[subUserEmailSplit.length-1];
		Fun_IfElseCondition([userDomain!=subUserDomain, ()=>{
			throw MESSAGES.NOT_VALID("sub-user domain");
		}])
		const checkRole = await findOne("user_roles", { id: body.admin_role_id, account_id: body.current_user.account_id });
		Fun_IfElseCondition([!checkRole, ()=>{
			throw MESSAGES.ROLE_ID_NOT_VALID;
		}]);
		const criteria = { email: body.email };
		const options = { attributes: BASE_ATTRIBUTES.INVOLVE.EMAIL_ATTRIBUTE };
		let emailDoc = await findOne("email", criteria, options);
		Fun_IfElseCondition([emailDoc, ()=>{
			throw MESSAGES.EMAIL_IS_ALREADY_REGISTERED;
		}]);
		body.password = decryptor(body.password);
		body.password = await encodePassword(body.password);
		splitNames(body);

		const data = {
			user_status: 1,
			user_type: USER_TYPE.CUSTOMER,
			two_way_auth: true,
			...body,
			admin_role_id: body.admin_role_id,
			account_id: body.current_user.account_id,
			country_code: body.current_user.country_code
		};
		const user = await create("user", data);
		emailDoc = await create("email", {
			user_id: user.id,
			email: body.email,
			is_verified: 0,
		});
		const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
		const tokenData = { email: body.email, user_id: user.id, type: body.type };
        const _token = token(tokenData, SERVER.TOKEN_EXPIRE_IN);
        const uri = encodeURI(`${REDIRECT_EMAIL_VERIFICATION}/${_token}`);
		const emailVerificationData = {
            nudgeId: nudgeConfig.email_verify.hostid,
            ToEmailAddress: body.email,
            toName: body.full_name || user.full_name,
            channel: NUDGE_CHANNEL.EMAIL,
            mergeTags: [
                { "tagName": "name", "tagValue": body.full_name || user.full_name },
                { "tagName": "url_new", "tagValue": uri }
            ]
        };
		await sendEmail(emailVerificationData);

		await create("password_history", {
			user_id: user.id,
			password: user.dataValues.password,
		});

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/regiter/User",
			isValid: true,
			message: `sub-user registred with userId ${user.id} and emailId ${body.email} by ${createdBy} into db`,
		});
		delete user.dataValues.password;
		return { ...user.dataValues, ...emailDoc.dataValues };
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/register/User",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); /** Arvind GLOB-1861 */
	}
};
ROLES_SERVICE.updateUserRole = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if(!body.current_user.account_id && body.current_user.admin_role_id != 1){
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}
		const checkUser = await findOne("user", {
			id: body.user_id,
			user_type: "2",
		});
		if (!checkUser) throw MESSAGES.USER_NOT_FOUND;
		const checkRole = await findOne("user_roles", {
			id: body.admin_role_id,
			account_id: body.current_user.account_id,
			status: true,
		});
		if (!checkRole) throw MESSAGES.ROLE_ID_NOT_VALID;
		await update("user", { id: body.user_id }, { admin_role_id: body.admin_role_id, account_id: body.current_user.account_id });

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/role/update_sub_role",
			isValid: true,
			message: `admin role from ${checkRole.admin_role_id} to ${body.admin_role_id} for userId ${body.user_id} by ${createdBy} in db`,
		});

		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATEDN); /** Arvind GLOB-1861 */
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/role/update_sub_role",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); /** Arvind GLOB-1401 */
	}
};

/**
 * Arvind GLOB-1861
 * Get all Sub User based on Filter
 * @param {*} body
 * @returns
 */
ROLES_SERVICE.getSubAdminLists = async (body) => {
	const createdBy = body.current_user.email || body.current_user.full_name;
	try {
		if(!body.current_user.account_id){
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}
		let emailQuery = ``;
		let statusQuery = ``;
		let userQuery = ``;
		let roleNameQuery = ``;
		let createdAtQuery = ``;
		if (body.filter) {
			/** Arvind reduce code complexity */
			if (body.filter.email) {
				emailQuery = textFilterQuery(body.filter.email, "em.email");
			}
			if (body.filter.full_name) {
				userQuery = userFullNameResponse(body.filter.full_name);
			}
			if (body.filter.user_status) {
				statusQuery = userstatusResponse(body.filter.user_status);
			}
			if (body.filter.role_name) {
				roleNameQuery = await roleNameResponse(body.filter.role_name);
			}
			if (body.filter.created_at) {
				createdAtQuery = await createdAtResponse(body.filter.created_at);
			}
			/** End of changes */
		}
		let dataQuery = `select u.id as user_id, em.email, u.full_name, u.user_status, u.created_at, u.admin_role_id, role.role_name from user as u
              join email as em on u.id = em.user_id left outer join user_roles as role on u.admin_role_id = role.id where u.user_type = 2 and u.account_id = '${body.current_user.account_id}' and u.admin_role_id is not null ${userQuery} ${emailQuery} ${roleNameQuery} ${statusQuery} ${createdAtQuery} order by u.created_at desc LIMIT ${body.offset}, ${body.limit};`;
		let countQuery = `select count(*) as total from user as u join email as em on u.id = em.user_id left outer join user_roles as role on u.admin_role_id = role.id where u.user_type = 2 and u.account_id = '${body.current_user.account_id}' and u.admin_role_id is not null ${userQuery} ${emailQuery} ${roleNameQuery} ${statusQuery} ${createdAtQuery};`;

		const user = await db.sequelize.query(dataQuery);
		const counts = await db.sequelize.query(countQuery);

		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/sub_admin/list",
			isValid: true,
			message: `Getting sub-admin list by ${JSON.stringify(body.filter)} from db by ${createdBy}`,
		});
		return { count: counts[0][0].total, data: user[0] };
	} catch (error) {
		await userRoleMgmtLogsUpdate({
			api_url: "/v1/user/sub_admin/list",
			isValid: false,
			message: `user ${createdBy} and ${error.message}`,
		});
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}
};

ROLES_SERVICE.updateSubUsrStatus = async (body) => {
try {

	if (body.user_id == body.current_user.id){
		throw MESSAGES.CANNOT_INACTIVE_YOURSELF;
	}

	const user = await findOne("user", {id:body.user_id});
    if(!user) throw MESSAGES.USER_NOT_FOUND;

	if(!user.account_id){
		throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
	}

	const subUsers = await findAll('user', { account_id: user.account_id, admin_role_id: 1, user_status: 1});
	if(subUsers.length<2){
		if(user.admin_role_id == 1 && !body.user_status){
			throw MESSAGES.CANNOT_INACTIVE_USER;
		}
	}

	
	await update("user", {id:user.id}, {user_status:body.user_status } );
   	
   	return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SUCCESS_MESSAGE_GLOBAL('User status', 'updated'));
}catch (error) {
	logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);

}

}


ROLES_SERVICE.deleteSubUsr = async (body) => {
	try {

		if (body.user_id == body.current_user.id){
			throw MESSAGES.CANNOT_INACTIVE_YOURSELF;
		}
		const user = await findOne("user", {id:body.user_id});
		if(!user) throw MESSAGES.USER_NOT_FOUND;

		if(!user.account_id){
			throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
		}
        /** if only one user with admin_role_id == 1 then cannot delete that user*/
		const subUsers = await findAll('user', { account_id: user.account_id, admin_role_id: 1, user_status: 1});
		if(subUsers.length<2){
			if(user.admin_role_id == 1 && !body.user_status){
				throw MESSAGES.CANNOT_DELETE_USER;
			}
		}
		await remove('password_history', {user_id: body.user_id})
		await remove('email', {user_id: body.user_id});
		await remove("user", {id:user.id});
		return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SUCCESS_MESSAGE_GLOBAL('User', 'deleted'));
	} catch (error) {
		logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
		throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
	}

}
module.exports = ROLES_SERVICE;
