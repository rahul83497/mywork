'use strict';

const db = require('../../db/models');
const {
    loginUser, getUserStatus, verify, userRegistration,
    sendEmailVerificationData, sendPhoneVerificationData,
    sendEmailVerification, getUserContries,
    getUserStates, getUserCities, forgetPassword,
    resetPassword, changePassword, getUser,getUserEmail,
    getAllUsers, verifyTWAEmail, resendTWA,
    sendShareLinkPaymentOTPVerification, verifyShareLinkPaymentOTP,
    updateUserProfile, verifyPhoneNumber,verifyEmail,
    getUserProfile, saveUserActivity, logoutUser,getCurrUserCC,
    forgetUserEmail, resendOTPPhoneVerification, addCompanyGate, UpdateCompanyGate, DeleteCompanyGate, GetCompanyGateList, addCompanyStaff, getCompanyUserList,
} = require('../users/user.service');

const { RESPONSEMESSAGES, MESSAGES, VERIFICATION_LINKS,OTP_EMAIL_PHONE_TYPE} = require('../../utils/constants');
const { decodeToken, encodePassword, encryptor, decryptor, isValidPass } = require('../../utils/bin/common');
const { OTP_TYPE, SMS_TYPE, OTP_VERIFICATION_TYPE } = require('../../utils/enums');
const { createIndividualUser } = require('../../services/authentication');
const { create, findOne } = require('../common/common.queries');
class UserController {
    constructor() {
        this.Users = db.users;
    }

    /**
     * Register user
     * @param {*} body
     * @returns
     */
    async register(body) {
        try {
            isValidPass(body);
            const user = await userRegistration(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, user);
        } catch (error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message||error);
        }

    }

    /**
     * login User
     * @param {*} body
     * @returns
     */
    async login(body) {
        
        try {
            const user = await loginUser(body);
           return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, user);
       } catch (error) {
           throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
       }
       /** End of changes */
    }

    /**
     * Get user status
     * @param {*} body
     * @returns
     */
    async getUserStatus(body) {
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,await getUserStatus(body)); 
    }

    /**
     * Verify token
     * @param {*} body
     * @returns
     */
    async verifyToken(body) {
        try {
            const decode = await decodeToken(body.token);
            return await verify(decode);
        } catch(error) {
            if(error.message==='jwt expired'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.LINK_EXPIRED));
              }else if (error.message==='invalid token'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
              }
              else {
                   throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
              }
        }
    }

    /**
     * VerifyOTP
     * @param {*} body
     * @returns
     */
    async verifyOTP(body) {
        try {
            const decode = await decodeToken(body.token);
            let data = null;
            switch(decode.type) {
                case OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION:
                    data = await verifyTWAEmail({...body, ...decode});
                    break;
                case OTP_TYPE.SHARE_LINK_PAYMENT_OTP:
                    data = await verifyShareLinkPaymentOTP({...body, ...decode});
                        break;
                case OTP_TYPE.PHONE_VERIFICATION:
                    data = await verifyPhoneNumber({...body, ...decode});
                    break;
                case OTP_TYPE.EMAIL_VERIFICATION:
                    data = await verifyEmail({...body, ...decode});
                    break;
                default:
                    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_DATA);
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            if(error.message==='jwt expired'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.LINK_EXPIRED));
              }else if (error.message==='invalid token'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
              }
              else {
                  throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message|| error);
              }
        }
    }

    /**
     * Resend OTP
     * @param {*} body
     */
     async userLogout(body) {
        try {
            const data = await logoutUser(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }

    /**
     * Add Company gate
     * @param {*} body
     */
     async addCompanyGate(body) {
        try {
            const data = await addCompanyGate(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }
    /**
     * Update Company gate
     * @param {*} body
     */
     async UpdateCompanyGate(body) {
        try {
            const data = await UpdateCompanyGate(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }
    /**
     * Delete Company gate
     * @param {*} body
     */
     async DeleteCompanyGate(body) {
        try {
            const data = await DeleteCompanyGate(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }

    /**
     * get Company gate list
     * @param {*} body
     */
     async GetCompanyGateList(body) {
        try {
            const data = await GetCompanyGateList(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }

    
    /**
     * addCompanyStaff
     * @param {*} body
     */
     async addCompanyStaff(body) {
        try {
            const data = await addCompanyStaff(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }
    /**
     * getCompanyUserList
     * @param {*} body
     */
     async getCompanyUserList(body) {
        try {
            const data = await getCompanyUserList(body);
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
        }
    }





    
    /**
     * Resend OTP
     * @param {*} body
     */
    async resendOTP(body) {
        try {
            const decode = await decodeToken(body.token);
            const data = await resendTWA({...body, ...decode});
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            if(error.message==='jwt expired'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.LINK_EXPIRED));
              }else if (error.message==='invalid token'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
              }else{
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
            }
        }
    }
    /**
     * @param { token } body
     * @returns
     */
    async resendOTPAuth(body) {
        const decode = await decodeToken(body.otp_token);
        try {
            let result;
            switch(decode.type) {
                case OTP_TYPE.PHONE_VERIFICATION:
                    result = await sendPhoneVerificationData({...decode, ...body});
                    break;
                case OTP_TYPE.EMAIL_VERIFICATION:
                    result = await sendEmailVerification({...decode,...body});
                    break;
                default:
                    throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_DATA); 
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, result);
        } catch(error) {
            if(error.message==='jwt expired'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.LINK_EXPIRED));
              }else if (error.message==='invalid token'){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
              }else{
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
            }
        }
    }
    /**
     * Send SMS OTP
     * @param {*} body
     * @returns
     */
    async sendSMS(body) {
        try  {
            let data = {};
            if(body.type == SMS_TYPE.SHARE_LINK_PAYMENT_OTP) {
                data = await sendShareLinkPaymentOTPVerification(body);
            }else{
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE); 
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error.error||error); 
        }
    }

    async phoneVerificationToken (body){
        try {
            let data = {};
            if(body.type == OTP_VERIFICATION_TYPE.PHONE_VERIFICATION) {
                data = await sendPhoneVerificationData(body);
            }
           else if (body.type == OTP_VERIFICATION_TYPE.EMAIL_VERIFICATION){
                 data = await sendEmailVerification(body);
           }
         else{
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE); 
            }
            return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error); 
        }
    }

    /**
     * Send email verification token
     * @param {*} body
     */
    async sendVerificationTokens(body) {
        
        try {
        if(body.type === VERIFICATION_LINKS.EMAIL) {
            const user = await getUserEmail(body);
            
            if(!user) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_IS_NOT_REGISTERED); 
            const isVerified = !!user.dataValues.is_verified;
            if (isVerified) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(
                MESSAGES.EMAIL_IS_ALREADY_VERIFIED(body.email)
                );

                const userData = await findOne('user', {id:user.user_id});
                user.full_name = userData.full_name; //End of changes
                const data = await sendEmailVerificationData(body, user);
                return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
                MESSAGES.DEFAULT_SUCCESS,
                data
            );
        }
        else if (body.type  === VERIFICATION_LINKS.PHONE) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.INVALID_DATA);
        }
        else {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.INVALID_DATA);
        }
    } catch (error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
    }
    /** End of changes */
    }

    /**
     * Get countries
     * @param {*} body
     */
    async getContries(body) {
        const data = await getUserContries(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }
    /**
     * Get current user country
     * @param {*} body
     * @returns
     */
    async getCurUserCountryCode (body){
        const data = await getCurrUserCC (body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }

    /**
    * Get countries
    * @param {*} body
    */
    async getCities(body) {
        const data = await getUserCities(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }

    /**
    * Get countries
    * @param {*} body
    */
    async getStates(body) {
        const data = await getUserStates(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }


    /**
     * Get other info
     * @param {*} body
     * @returns
     */
    async getOtherInfo(body) {
        const accountId = await getAccountId(body);
        if (!accountId) RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.NOT_FOUND, null);
        const result = await getUserOtherInfo(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            result
        );
    }

    /**
     * Forget Email
     */
    async forgetEmail(body) {
        try{
        let data = await forgetUserEmail(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    } catch(error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
    }
    }
    /**
     * Forget password
     * @param {*} body
     */
    async forgetPassword(body) {
        try{
        let data = await forgetPassword({ ...body });
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.EMAIL_SUCCESSFULLY_SENT,
            data
        );
    } catch(error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
    }
    }

    /**
     * Reset password password
     * @param {*} body
     */
    async resetPassword(body) {
        try{
        await resetPassword(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            body
        );
    } catch(error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error); 
    }
    }

    /**
     * Change password
     * @param {*} body
     */
    async changePassword(body) {
        try {
            isValidPass(body); 
        body.password = decryptor(body.password);
        let data;
        if (body.token) {
           data = await resetPassword(body);
        }
        else {
            data = await changePassword(body);
        }
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
    } catch (error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
    }
    /** End of changes */
    }

    /**
     * Get all users
     * @param {*} body
     * @returns
     */
    async getUsers(body) {
        const users = await getAllUsers(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.SUCCESS, users);
    }

    /**
     * Get user Profile
     * @param {*} body
     * @returns
     */
     async getProfile(body) {
        const data = await getUserProfile(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }
    /**
     * Get Encrypted Password
     * @param {*} body
     * @returns
     */
     async getPass(body) {  
        
        try {
       const data = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN, await encryptor(body.password))
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    } catch (error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message|| error);
    }
    /** End of changes */
    }
    /**
     * Save user's Activity
     * @param {*} body
     * @returns
     */
     async saveActivity(body) {
        const data = await saveUserActivity(body);
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS,
            data
        );
    }

    /**
     * Update user data
     * @param {*} body
     */
    async updateUser(body) {
        try {
        const _phoneData = phoneData(body);
        const _addressData = addressData(body.address);
        const _commEmail = commEmail(body);
        const _commPhone = commPhone(body.communication_phone)            
        const data = await updateUserProfile({...body, phone: _phoneData, address: _addressData, cEmail: _commEmail, cPhone: _commPhone});
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(MESSAGES.DEFAULT_UPDATED, data);
        } catch(error) {
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message || error);
        }
    }
}


module.exports = new UserController();