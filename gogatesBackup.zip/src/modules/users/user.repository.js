
const db = require('../../db/models');
const logger = require('../../utils/logger');
const {findOne, update} = require('../../modules/common/common.queries');
const { MESSAGES, RESPONSEMESSAGES, BASE_ATTRIBUTES } = require('../../utils/constants');
const { Op } = require('sequelize');

const USER_REPOSITORY = {};
const CURRENT_FILE_NAME = 'user.repository';


/**
 * Get user by criteria
 * @param {*} criteria
 * @returns
 */
USER_REPOSITORY.getUserByCriteria = async (criteria) => {
    return db.user.findAll({ where: criteria });   
}


/**
 * Get user by criterias
 * @param {*} criteria
 * @returns
 */
USER_REPOSITORY.getOneUserByCriteria = async (criteria) => {
    try {
        const emailDoc = await USER_REPOSITORY.getUserEmailByCriteria(criteria);
        if (!emailDoc) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_IS_NOT_REGISTERED);
        if (!emailDoc.is_verified)throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_NOT_VERIFIED);

        const options = {attributes: {exclude: BASE_ATTRIBUTES.EXCLUDE.USER_EXCLUDE}}
        const userDoc = await findOne('user', { id: emailDoc.user_id }, options);
        if (!userDoc) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.USER_NOT_REGISTERED);
        userDoc.dataValues.email = emailDoc.email;
        userDoc.dataValues.is_verified = emailDoc.is_verified;

        return userDoc;
    } catch (error) {
        logger.error(`${CURRENT_FILE_NAME}_error`, error);
        throw error;
    }
}

/**
 * Get user emaiol by criteria
 * @param {*} criteria
 * @returns
 */
USER_REPOSITORY.getUserEmailByCriteria = async (criteria) => {
    criteria.is_verified = {[Op.like]: `%%` } 
    return db.email.findOne({
        where: criteria,
        attributes: ['email', 'user_id', 'is_verified']
    });
}

/**
 * Update user email
 * @param {*} id
 */
USER_REPOSITORY.updateUserEmail = (criteria, data) => {
    return db.email.update(data, {where: criteria});
}

/**
 * Update user data
 * @param {*} id
 */
 USER_REPOSITORY.updateUser = (criteria, data) => {
    return db.user.update(data, {where: criteria});
}


/**
 * Get countries
 * @param {*} id
 */
 USER_REPOSITORY.getContriesByUser = async (criteria) => {
    return db.countries.findAll({where: criteria,  order:[['name','ASC']]});  
}

/**s
 * Get get cities
 * @param {*} id
 */
 USER_REPOSITORY.getCitiesByUser = async (criteria) => {
    return db.cities.findAll({where: criteria,  order:[['name','ASC']]});  
}


/**
 * Get get states
 * @param {*} id
 */
 USER_REPOSITORY.getStatesByUser = async (criteria) => {
    return db.states.findAll({where: criteria, order:[['name','ASC']], attributes:{exclude:['createdAt','updatedAt']}});  
}

USER_REPOSITORY.updateLastLoginTime = async(id) => {
    const last_login = new Date().toISOString()
    return update('user', {id}, {last_login})
}
module.exports = USER_REPOSITORY;