
const {
    getOneUserByCriteria, updateUserEmail, getContriesByUser, getStatesByUser, getCitiesByUser, updateLastLoginTime
} = require('./user.repository');
const { sendEmail, sendMobileOTPToProcessPayment, sendPhone } = require('../../services/http');
const { update, findOne, create, findAndCountAll, remove, lastCreatedDoc, countWithDetails, findAll } = require('../common/common.queries');

const { comparePassword, token, encodePassword, splitNames, decodeToken, addHours, addMinutes, dobValidate, decryptor, Fun_IfElseCondition, Fun_checkAndCondition, Fun_checkOrCondition, expiryDay, backDay, isValidPass } = require('../../utils/bin/common');
const {
    RESPONSEMESSAGES, MESSAGES, DEFAULT_KYC_STATUS, DASHBOARD_KYC_BAR_CATEGORIES, DASHBOARD_KYC_STATUS_TO_ENABLE_BUTTON,
    SERVER, VERIFICATION_LINKS, BASE_ATTRIBUTES, CUSTOME_ERROR_CODE_TO_MESSAGE, USER_TYPE,OTP_EMAIL_PHONE_TYPE,NUDGE_CHANNEL,
} = require('../../utils/constants');
const db = require('../../db/models');
const { GLOBAL_OBJ } = require('../../utils/bin/global');
const { OTP_TYPE, SMS_TYPE, OTP_VERIFICATION_TYPE } = require('../../utils/enums');
const logger = require('../../utils/logger');
const moment = require('moment');
const { REDIRECT_FORGOT_PASSWORD_URL, REDIRECT_EMAIL_VERIFICATION, REDIRECT_FORGOT_PASSWORD_URL_ADMIN } = require('../../utils/bin/links');
const { Op } = require('sequelize');
const { generate } = require('otp-generator');
const { v4: uuidv4 } = require('uuid');
const { uploadFile, removefiles, removefileInds, getfiles } = require('../../services/file-upload');
const excelData = require('../../utils/bin/excelData');
const { uuid } = require('crypto.js');
const { UUIDV4 } = require('sequelize');
const { stringFilterQuery, createdAtFilterQuery, userstatusResponse, textFilterQuery } = require('../../utils/bin/globalVariables');
const CURRENT_FILE_NAME = 'user.service';
const USER_SERVICE = {};


/**
 * Get user details
 * @param {*} body
 * @returns
 */
USER_SERVICE.getUser = async (body) => {
    const criteria = { email: body.email };
   return getOneUserByCriteria(criteria); 
}

/**
 * Add company gate
 * @param {*} body
 * @returns
 */
USER_SERVICE.addCompanyGate = async (body) => {
    try {
            let query;
            let gateData;                

            body.id = uuidv4();
            gateData  = await create('gate',body)

            query = `select * from admins  where user_id = "${body.current_user.id}"`;        
            companyDetails = await db.sequelize.query(query)
            
            if(gateData){
                let companyGate = {
                    companies_id : companyDetails[0][0].company_id,
                    gate_id : gateData.id,
                };        
                await create('companiesgates',companyGate)
            }                       
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,gateData); 
    }catch (error) {        
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/company/add/gate"})
        await update('user_activity_logs',{id:actLog.id}, {message:error.message, isValid:false, user_id:body.current_user.id}) 
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
    }

}
/**
 * Update company gate
 * @param {*} body
 * @returns
 */
USER_SERVICE.UpdateCompanyGate = async (body) => {
    try {
            let role;
            let existing;
            let data;
            role = await findAll('role_user',{user_id:body.current_user.id})
            if(body.current_user.user_type != 2 && role.role_id != 4){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
            existing = await findOne('gate',{id:body.id})     
            if(!existing){
                throw MESSAGES.RECORDS_NOT_FOUND
            }    
            data = await update('gate',{id:body.id},body)      
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.UPDATED_SUCCESSFULLY); 
        }catch (error) {        
        // const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/company/Update/gate"})
        // await update('user_activity_logs',{id:actLog.id}, {message:error.message, isValid:false, user_id:body.current_user.id}) 
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
        }   
}
/**
 * Delete company gate
 * @param {*} body
 * @returns
 */
USER_SERVICE.DeleteCompanyGate = async (body) => {
    try {
            let role;
            let existing;
            let data;
            role = await findAll('role_user',{user_id:body.current_user.id})
            if(body.current_user.user_type != 2 && role.role_id != 4){
                throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(MESSAGES.DO_NOT_HAVE_PERMISSION)
            }
            existing = await findOne('gate',{id:body.id})     
            if(!existing){
                throw MESSAGES.RECORDS_NOT_FOUND
            }                
            existing = await findOne('companiesgates',{gate_id: existing.id})     
            if(existing){
                throw MESSAGES.REMOVE_EXISTING_GATE;
            }    
            data = await remove('gate',{id:body.id})    
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DELETED_SUCCESSFULLY);   
        }catch (error) {      
            // console.log(error)                    
            // const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/company/delete/gate"})
            // await update('user_activity_logs',{id:actLog.id}, {message:error.message, isValid:false, user_id:body.current_user.id}) 
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
        } 
   
}
USER_SERVICE.GetCompanyGateList = async (body) => {
    try {
        let gateData;
        let existing;
        let companyData;
        if(body.id){            
            gateData = await findOne('gate',{id:body.id})  
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,gateData); 
        }                                       
            
        query = `select a.company_id , gate.* from  admins as a left join companiesgates as cg on cg.companies_id = a.company_id join gate as gate on gate.id = cg.gate_id where a.user_id = "${body.current_user.id}"`;        
        gateData = await db.sequelize.query(query) 

        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,gateData[0]);   
        }catch (error) {      
            // console.log(error)                    
            // const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/company/delete/gate"})
            // await update('user_activity_logs',{id:actLog.id}, {message:error.message, isValid:false, user_id:body.current_user.id}) 
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
        } 
   
}
USER_SERVICE.addCompanyStaff = async (body) => {   
                let data ;
                let query;
                isValidPass(body);                                                                                                              
                const user = await USER_SERVICE.userRegistration(body);   
                query = `select * from admins  where user_id = "${body.current_user.id}"`;        
                companyDetails = await db.sequelize.query(query)             
                if(user){                    
                    let newbody = {}
                    newbody.user_id = user.data.id
                    newbody.company_id = companyDetails[0][0].company_id
                    newbody.role_id = 3
                    await USER_SERVICE.assignUserRole(newbody);   
                    delete newbody.role_id 
                    data = await USER_SERVICE.addcompanyUser(newbody);               
                }
            return MESSAGES.DEFAULT_SUCCESS, user;               
   
}
USER_SERVICE.getCompanyUserList = async (body) => {   
            let data ={}     
            let query;
            let query1;
            let idQuery = ``;
            let emailQuery = ``;            
            let createAtQuery = ``;        
            let statusQuery = ``;        
            query = `select * from admins  where user_id = "${body.current_user.id}"`;        
            companyDetails = await db.sequelize.query(query)                
            if (body.filter){                             
                Fun_IfElseCondition([body.filter.id , async()=>{
                    idQuery = stringFilterQuery(body.filter.id,fieldName="u.id")
                }])
                Fun_IfElseCondition([body.filter.email ,()=>{
                    emailQuery = textFilterQuery(body.filter.email,fieldName="")
                }])
               
                Fun_IfElseCondition([body.filter.createdAt ,()=>{
                    createAtQuery = createdAtFilterQuery(body.filter.createdAt,fieldName="u.created_at")
                }])                            
                Fun_IfElseCondition([body.filter.createdAt ,()=>{
                    statusQuery = userstatusResponse(body.filter.user_status,fieldName="u.user_status")
                }])                            
            }            
            query=`select nu.company_id,u.full_name,u.user_type,u.user_status,u.two_way_auth,u.created_at,u.updated_at, emp.email from normal_users as nu left join user as u on u.id = nu.user_id left join email as emp on emp.user_id = u.id  where u.id like "%%" ${idQuery} ${emailQuery} ${statusQuery} ${createAtQuery} limit ${body.offset},${body.limit}`;                                            
            const data1 = await db.sequelize.query(query)                        
            data.data = data1[0]
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data);            
   
}

/**
 * Get user details
 * @param {*} body
 * @returns
 */

USER_SERVICE.getUserEmail = async (body) => {
    const criteria = { email: body.email };
    return findOne('email', criteria);  
}

USER_SERVICE.assignUserRole = async (body) => {         
    body.id = uuidv4();        
    let data = await create("role_user", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

USER_SERVICE.addcompanyUser = async (body) => {         
    body.id = uuidv4();        
    let data = await create("normal_users", body)       
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESS,data); 
}

USER_SERVICE.getUserProfile = async (body) => {
    const criteria = {id:body.current_user.id};
    const attributes = ['id','first_name','last_name','full_name','user_type','user_status','profile_picture_id','account_id','dob','two_way_auth','country_code','createdAt']
    const email = await findOne('user', criteria, {
            attributes,
            include: [
                {model: db.phone, as : 'phone', attributes: {exclude: ['createdAt', 'updatedAt', 'count', 'user_id', 'country_code', 'is_primary']}},
                {model: db.address, as : 'address', attributes: {exclude: ['createdAt', 'updatedAt', 'user_id', 'postal_code', 'po_box', 'valid_from', 'valid_to']}},
                {model: db.phone, as : 'communication_phone', attributes: {exclude: ['createdAt', 'updatedAt', 'count', 'user_id', 'is_primary']}},
                {model: db.email_secondary, as : 'communication_email', attributes: {exclude: ['createdAt', 'updatedAt', 'user_id','is_primary']}},
            ]
    });

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,email); 
}


USER_SERVICE.userDetails = async (body) => {
    const criteria = {};
    if(body.email) {
        criteria.email = body.email;
        criteria.is_verified = {
            [Op.like]: `%%`
       }
    }
    else if(body.user_id) {
        criteria.user_id = body.user_id;
    }
    else {
        throw MESSAGES.INVALID_DATA; 
    }
    const email = await findOne('email', criteria, {
        include: [{
            model: db.user,
            as: "user",
            attributes: { exclude: ['valid_to', 'auth_user_access_token', 'ref_to_config', 'comm_phone', 'comm_email', 'address_id', 'phone_id'] },
            // include: [
            //     {model: db.phone, as : 'phone', attributes: {exclude: ['createdAt', 'updatedAt', 'count', 'user_id', 'country_code', 'is_primary']}},
            //     {model: db.address, as : 'address', attributes: {exclude: ['createdAt', 'updatedAt', 'user_id', 'postal_code', 'po_box', 'valid_from', 'valid_to']}},
            // ]
        }]
    });

    if (!email) throw MESSAGES.EMAIL_IS_NOT_REGISTERED;
    let user = email.dataValues.user;
    if (user.user_status === "0"){
        Fun_IfElseCondition([body.current_user?.user_type, ()=>{
            throw MESSAGES.USER_BLOCKED('This user');
        }],[true, ()=> {
            throw MESSAGES.USER_BLOCKED('Your');
        }])
    } 
    if(user.user_type != USER_TYPE.CUSTOMER) throw MESSAGES.USER_TYPE_INVALID; 
    user = { ...email.dataValues, ...user.dataValues };

    if (!email.is_verified) {
        if(body.current_user?.user_type){
            throw MESSAGES.USER_ACCOUNT_NOT_VERIFIED; 
        }else{
            body.logs_type = "LOGIN"
            await USER_SERVICE.sendEmailVerificationData({ ...body, type: VERIFICATION_LINKS.EMAIL }, user);
            throw MESSAGES.EMAIL_NOT_VERIFIED_LINK_SHARED; 
        }
    }
    return user;
}

/**
 * Validate user by email
 * @param {*} body
 * @returns
 */
USER_SERVICE.loginUser = async (body) => {
    let user_id = ``;
    try {
        body.password = decryptor(body.password);
        let user = await USER_SERVICE.userDetails(body);
        user_id = user.id;
        if (!process.env.NO_EXPIRY_EMAILS.includes(body.email)) {   
            await USER_SERVICE.checkIfPasswordIsExpired({ user_id: user.id });
        }
        await USER_SERVICE.lockUserAccount(user, body);
        const otpDoc = await findOne('otp', {user_id: user.id, type: "EMAIL_TWO_WAY_AUTHENTICATION"}); 
        if (otpDoc) await remove('otp', { id: otpDoc.id });  
        const twa = await USER_SERVICE.applyTwoWayAuth(user, body);
        let data = { email: user.email, user_id: user.id, ...twa };
        if(twa) {
            data  = {...data, ...twa};
        }

        data.session_id = uuidv4();
        user.token = token(data);
        await update('user', {id: user.id}, {wrong_count: 0, wrong_otp_count: 0});
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/login"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, {user_id:user_id, session_id: data.session_id})
        delete data.session_id;
        if(twa.type) {
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
                MESSAGES.TWO_WAY_AUTHENTICATION_CODE_SENT,
                {token: user.token, full_name: user.full_name, ...data}
            );
        }
        const merchants = await USER_SERVICE.getUserSubMerchants({
            account_id: user.account_id, origin: user.country_code
        });
        user = { ...user, ...merchants };
        await updateLastLoginTime(user.id)
        delete user.password;
        delete user.user;
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( 
            MESSAGES.LOGGED_IN_SUCCESSFULLY,
            user
        );
    } catch (error) {
        
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/login"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:error.message, isValid:false, user_id:user_id}) 
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);  
    }
}

/**
 * Verify two way authenticatio by email
 * @param {*} body
 */
USER_SERVICE.verifyTWAEmail = async (body) => {
    let criteria;
    try {
        let user = await USER_SERVICE.userDetails(body);
        criteria = {email:user.email, user_id:user.user_id, session_id:body.session_id};
        const otp = await findOne('otp', {user_id: body.user_id, type: body.type});
        const current = new Date();
        if (!otp) {
            throw MESSAGES.WRONG_OTP_COUNT_ERROR; 
        }
        if(otp.wrong_otp_count >= SERVER.WRONG_OTP_COUNT) {
            const validFrom = `${new Date(addHours(new Date(), 24)).toISOString()}`;
            await update('user', {id:user.id}, {valid_from:validFrom})
            throw MESSAGES.WRONG_OTP_MAX; 
        }
        if (otp.otp !== body.otp) {
            otp.wrong_otp_count = (otp.wrong_otp_count || 0) + 1;
            otp.save();
            throw MESSAGES.WRONG_OTP_ATTEMPTS(5-otp.wrong_otp_count); 
        }

        if(current > otp.valid_till ) {
            throw MESSAGES.OTP_EXPIRED; 
        }
        const merchants = await USER_SERVICE.getUserSubMerchants({
            account_id: user.account_id ,
            origin : user.country_code
        });

        const data = { email: user.email, user_id: user.id };
        data.session_id = body.session_id;
        criteria.message = MESSAGES.OTP_VERIFY_SUCCESSFULLY.message
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/verify_otp"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, criteria)
        user.token = token(data);
        user = { ...user, ...merchants };
        await updateLastLoginTime(user.id)
        delete user.password;
        delete user.user;
        delete user.valid_from;
        delete user.wrong_count;
        delete user.wrong_pass_count;
        await remove('otp', { id: otp.id });
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.OTP_VERIFY_SUCCESSFULLY,user); 
    } catch (error) {
        criteria.message = error.message;
        criteria.isValid = false;
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/verify_otp"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, criteria)
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error)
    }
}


USER_SERVICE.verifyPhoneNumber = async (body) => {
    try {
        const otp = await findOne('otp', {user_id: body.user_id, customer_number: `${body.ccc}${body.phone_number}`, type: body.type});
        const current = new Date();
        if (!otp) {
            throw MESSAGES.INVALID_OTP;
        }
        if(otp.wrong_otp_count >= SERVER.WRONG_OTP_COUNT) {
            throw MESSAGES.OTP_SEND_MAX;
        }
        if(otp.otp !== body.otp) {
            await update('otp', {id: otp.id}, {wrong_otp_count: ((otp.wrong_otp_count || 0) + 1)});
            throw MESSAGES.INVALID_OTP;
        }
        if(current > otp.valid_till) {
            throw MESSAGES.OTP_EXPIRED;
        }
        await update('phone', { phone_number: body.phone_number,ccc:body.ccc, user_id: body.user_id}, {is_verified: 1});
        await remove('otp', {id:otp.id});
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.PHONE_VERIFIED_SUCCESSFULLY);
    } catch (error) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
    }
}

USER_SERVICE.verifyEmail = async (body) => {
    try {
        const otp = await findOne('otp', {user_id: body.user_id, type:body.type,customer_number: body.email });
        const current = new Date();
        if (!otp) {
            throw MESSAGES.INVALID_OTP;
        }
        if(otp.wrong_otp_count >= SERVER.WRONG_OTP_COUNT) {
            throw MESSAGES.WRONG_OTP_COUNT_ERROR;
        }
        if(otp.otp !== body.otp) {
            await update('otp', {id: otp.id}, {wrong_otp_count: ((otp.wrong_otp_count || 0) + 1)});
            throw MESSAGES.INVALID_OTP;
        }
        if(current > otp.valid_till) {
            throw MESSAGES.OTP_EXPIRED;
        }
        await update('email_secondary', { email: body.email, user_id: body.user_id}, {is_verified: 1});
        await remove('otp', {id:otp.id});
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.EMAIL_VERIFIED_SUCCESSFULLY);
    } catch (error) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error);
    }
}





/**
 * User Logout
 * @param {*} body
 */
 USER_SERVICE.logoutUser = async (body) => {
    try {
        const actLog = await lastCreatedDoc('user_activity_logs', {api_url: "/v1/user/logout"})
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:MESSAGES.LOGGED_OUT_SUCCESSFULLY.message, status: false})
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.LOGGED_OUT_SUCCESSFULLY); 
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}


/**
 * Apply two way auth for user
 * @param {*} user
 * @param {*} body
 */
USER_SERVICE.applyTwoWayAuth = async (user, body) => {
    try {
        if(user.two_way_auth) {
            //const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
            /** const otp = generate(6, {
                 upperCaseAlphabets: false,
                 specialChars: false,
                 digits: true,
                 lowerCaseAlphabets: false
             }); */ 
            const otp = SERVER.DEFAULT_OTP;
            const dataToSave = {
                user_id: user.id,
                type: OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION
            };
            const otpDoc = await findOne('otp', {user_id: user.id, type: OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION});
            const current = new Date();
            if(otpDoc && otpDoc.wrong_otp_count >= SERVER.WRONG_OTP_COUNT){
                const validFrom = `${new Date(addHours(new Date(), 24)).toISOString()}`;
                await update('user', {id:user.id}, {valid_from:validFrom})
                throw MESSAGES.WRONG_OTP_MAX; 
            }
            if(otpDoc && otpDoc.send_count >= SERVER.MAX_OTP_SEND_COUNT) throw MESSAGES.OTP_SEND_MAX; 
            // const data = {
            //     ToEmailAddress: user.email,
            //     toName: user.full_name,
            //     channel: NUDGE_CHANNEL.EMAIL,
            //     mergeTags: [
            //         { "tagName": "otp", "tagValue": otp },
            //     ],
            //     nudgeId: nudgeConfig.email_otp.hostid
            // };

            if (!otpDoc) {
                dataToSave.otp = otp;
                dataToSave.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
                await create('otp', dataToSave);
            } else {
                otpDoc.otp = otp;
                otpDoc.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
                otpDoc.wrong_otp_count = 0;
                otpDoc.send_count = otpDoc.send_count+1;
                await otpDoc.save();
            }

           // const mailData = await sendEmail(data);
            await create('nudge_logs',{user_id: user.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"RESEND_OTP", errors:mailData.data.errors, hasErrors:mailData.data.hasErrors})

            return {two_way_auth: user.two_way_auth || false, type: OTP_TYPE.EMAIL_TWO_WAY_AUTHENTICATION};
        }
        return {};
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        if (error?.error_type){ 
            throw error ;
        }else{
            throw MESSAGES.SOMETHING_WENT_WRONG 
        }
    }
}

/**
 * Signup user
 * @param {*} body
 */
USER_SERVICE.userRegistration = async (body) => {
    try {
        body.password = decryptor(body.password);
        const criteria = { email: body.email };
        const options = { attributes: BASE_ATTRIBUTES.INVOLVE.EMAIL_ATTRIBUTE }
        let emailDoc = await findOne('email', criteria, options);
        if (emailDoc) throw MESSAGES.EMAIL_IS_ALREADY_REGISTERED; 
        body.password = await encodePassword(body.password);
        splitNames(body);
        body.logs_type = "REGISTRATION";

        let user = { id: uuidv4() }
       // const mailStatus = await USER_SERVICE.sendEmailVerificationData(body, user);
         
        // if (mailStatus?.dataValues?.hasErrors) {
        //     throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(mailStatus.dataValues.errors[0]); 
        // }

        if(!body.user_type){
            body.user_type = USER_TYPE.CUSTOMER
        }

        body.valid_from = new Date().toISOString();
        body.valid_to = new Date("9999-12-31").toISOString();
        const data = { id:user.id, user_status: 1, user_type: body.user_type, two_way_auth: false, ...body};
        data.admin_role_id = 1;
        user = await create('user', data);
        await create('email', { user_id: user.id, email: body.email, is_verified: 0 }); 
        await create('password_history', { user_id: user.id, password: user.dataValues.password });
        // delete user.dataValues.password;

        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.REGISTERED_SUCCESSFULLY,user);
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}

/**
 * Get user status
 * @param {*} body
 * @returns
 */
USER_SERVICE.getUserStatus = async (body) => {
    const criteria = {
        user_id: body._u_id, category_type: body.category_type
    };
    const statuses = await getUserStatusByCriteria(criteria);
    const filteredStatus = [];

    statuses.forEach(function (status, index) {
        if (categoryFilter[status.category_id])
            filteredStatus.push({
                id: status.id,
                status: status.status_id,
                user_id: status.user_id,
                ...categoryFilter[status.category_id]
            });
    });

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(
        MESSAGES.DEFAULT_SUCCESSN,
        filteredStatus
    ); 
}


/**
 * User email verify
 * @param {*} body
 */
USER_SERVICE.userEmailVerify = async (body) => {
    try {
        const emailDoc = await findOne('email', { email: body.email });
        const isVerified = !!emailDoc?.dataValues?.is_verified;
        // if(!await findOne('email_secondary', {email: body.email})){
        //     await create('email_secondary', {id: uuidv4(), email: body.email, is_verified: true, user_id: emailDoc.user_id});
        // }
        if (isVerified) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_IS_ALREADY_VERIFIED(body.email)); 

        const result = await updateVerifiedStatus(emailDoc.user_id);
        logger.info(`info_${CURRENT_FILE_NAME}`, JSON.stringify(result));
        return RESPONSEMESSAGES.SUCCESS.MISSCELANEOUSAPI(
            MESSAGES.DEFAULT_SUCCESS, RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.EMAIL_VERIFIED_SUCCESSFULLY)      
        );
    } catch (error) {
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error); 
    }
}

/**
 * Verify email or phone numbers
 * @param {*} body
 */
USER_SERVICE.verify = async (body) => {
    
    try {
      return await USER_SERVICE.userEmailVerify(body);
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw error;
    
    }
}

/**
 * Send email verificatio code
 * @param {*} body
 */

USER_SERVICE.sendEmailVerificationData = async (body, user) => {
    try {
        //const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
        if (!user) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.USER_NOT_REGISTERED); 

        const tokenData = { email: body.email, user_id: user.id, type: body.type };
        const _token = token(tokenData, SERVER.TOKEN_EXPIRE_IN);        
        console.log("first", _token)
        const uri = encodeURI(`${REDIRECT_EMAIL_VERIFICATION}/${_token}`);
        // const data = {
        //     nudgeId: nudgeConfig.email_verify.hostid,
        //     ToEmailAddress: body.email,
        //     toName: body.full_name || user.full_name,
        //     channel: NUDGE_CHANNEL.EMAIL,
        //     mergeTags: [
        //         { "tagName": "name", "tagValue": body.full_name || user.full_name },
        //         { "tagName": "url_new", "tagValue": uri }
        //     ]
        // };
        //const mailData =   await sendEmail(data);
        // if(body.logs_type ==="LOGIN"){
        //     return await create('nudge_logs',{user_id: user.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"USER_LOGIN", errors:mailData.data.errors, hasErrors:mailData.data.hasErrors})
        // }
        // if(body.logs_type ==="REGISTRATION"){
        //     return await create('nudge_logs',{user_id: user.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"USER_REGISTER", errors:mailData.data.errors, hasErrors:mailData.data.hasErrors})
        // } 
        
        // if (mailData.data.hasErrors ) {
        //     throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(mailData.data.errors[0]); 
        // } 
        let response;
        if(body.logs_type ==="REGISTRATION"){
            response = mailData
        } else response = RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.EMAIL_SUCCESSFULLY_SENT); 
        return response;
    } catch (error) {

        console.log(error)
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw MESSAGES.SOMETHING_WENT_WRONG;
    }
}

USER_SERVICE.sendPhoneVerificationData = async (body, user) => {
    try {
        Fun_IfElseCondition([!body.phone_number, ()=>{ throw MESSAGES.PHONE_NUMBER_REQUIRED}]);
        Fun_IfElseCondition([!body.ccc, ()=>{ throw MESSAGES.MOBILE_CCC_ISSUE}]);
        const phone = await findOne('phone', { phone_number:body.phone_number, ccc:body.ccc, user_id: body.current_user.id})
        if(phone && phone.is_verified) throw MESSAGES.PHONE_IS_ALREADY_VERIFIED(`${body.ccc} ${body.phone_number}`);
        if(!phone){
            const _phoneData = phoneData({ ...body, phone_type: OTP_VERIFICATION_TYPE.PHONE_VERIFICATION  });
            _phoneData.phone_number = body.phone_number;
            await addPhoneNumber(_phoneData);
        }
        const otpDoc = await findOne('otp', {user_id: body.current_user.id, customer_number:`${body.ccc}${body.phone_number}`, type: OTP_VERIFICATION_TYPE.PHONE_VERIFICATION});

        const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
        const otp = generate(6, {
            upperCaseAlphabets: false,
            specialChars: false,
            digits: true,
            lowerCaseAlphabets: false
        });
        const dataToSave = {
            user_id: body.current_user.id,
            type:OTP_VERIFICATION_TYPE.PHONE_VERIFICATION,
            customer_number:`${body.ccc}${body.phone_number}`
        };
        if(otpDoc && otpDoc.send_count &&otpDoc.send_count == SERVER.MAX_OTP_SEND_COUNT){
            dataToSave.send_count = otpDoc.send_count + 1;
            await update('otp', { id: otpDoc.id}, dataToSave);
            throw MESSAGES.OTP_SEND_MAX;
        }
        Fun_IfElseCondition([otpDoc && otpDoc.send_count &&otpDoc.send_count >= SERVER.MAX_OTP_SEND_COUNT, ()=>{
            throw MESSAGES.OTP_SEND_MAX_ERROR;
        }])
        const current = new Date();
        dataToSave.otp = otp;
        dataToSave.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
        if (!otpDoc) {
            await create('otp', dataToSave);
        } else {
            otpDoc.otp = otp;
            otpDoc.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
            dataToSave.wrong_otp_count = 0;
            dataToSave.send_count = otpDoc.send_count + 1;
            await update('otp', { id: otpDoc.id}, dataToSave);
        }

        const data = {
            ToPhoneNumber: `${body.ccc}${body.phone_number}`,
            toName: "",
            channel: NUDGE_CHANNEL.SMS,
            mergeTags: [
                { "tagName": "sms_otp", "tagValue": otp
            }
        ],
        nudgeId: nudgeConfig.phone_otp.hostid,
    };
    await sendPhone(data);
    const _token = token({ type: body.type, phone_number: body.phone_number,ccc:body.ccc, user_id:body.current_user.id });
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.OTP_SEND_SUCCESSFULLY,_token);

    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}_sendOtp`, error.message);
        if(error.error_type){
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
        }
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.SOMETHING_WENT_WRONG) 
    }
}

USER_SERVICE.sendEmailVerification = async (body) => {
    try {
        Fun_IfElseCondition([!body.email, ()=>{ throw MESSAGES.EMAIL_REQUIRED}]);
        let emailSecondary = await findOne('email_secondary', { email:body.email,  user_id: body.current_user.id})
        if(emailSecondary && emailSecondary.is_verified) throw MESSAGES.EMAIL_IS_ALREADY_VERIFIED(body.email);
        if(!emailSecondary){
            const _emailData = emailData({ ...body });
            await addEmailInSecondaryTable(_emailData);
        }
              const otp = generate(6, {
                upperCaseAlphabets: false,
                  specialChars: false,
                  digits: true,
                  lowerCaseAlphabets: false
              });
            const dataToSave = {
                user_id: body.current_user.id,
                type: OTP_VERIFICATION_TYPE.EMAIL_VERIFICATION,
                customer_number: body.email
             };
            const otpDoc = await findOne('otp', {user_id: body.current_user.id, type: OTP_VERIFICATION_TYPE.EMAIL_VERIFICATION, customer_number: body.email});
            const current = new Date();
            if(otpDoc && otpDoc.wrong_otp_count >= SERVER.WRONG_OTP_COUNT){
                throw MESSAGES.WRONG_OTP_MAX;
            }
             if(otpDoc && otpDoc.send_count &&otpDoc.send_count == SERVER.MAX_OTP_SEND_COUNT){
                dataToSave.send_count = otpDoc.send_count + 1;
                await update('otp', { id: otpDoc.id}, dataToSave);
                throw MESSAGES.OTP_SEND_MAX;
            }
            Fun_IfElseCondition([otpDoc && otpDoc.send_count &&otpDoc.send_count >= SERVER.MAX_OTP_SEND_COUNT, ()=>{
                throw MESSAGES.OTP_SEND_MAX_ERROR;
            }])
            const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
            const data = {
                ToEmailAddress: `${body.email}`,
                toName: "",
                channel: NUDGE_CHANNEL.EMAIL,
                mergeTags: [
                    { "tagName": "otp", "tagValue": otp },
                ],
                nudgeId: nudgeConfig.email_otp.hostid
            };

            if (!otpDoc) {
                dataToSave.otp = otp;
                dataToSave.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
                await create('otp', dataToSave);
            } else {
                otpDoc.otp = otp;
                otpDoc.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
                otpDoc.wrong_otp_count = 0;
                otpDoc.send_count = otpDoc.send_count+1;
                await otpDoc.save();
            }
           await sendEmail(data);
            const _token = token({ type: body.type, email: body.email, user_id:body.current_user.id });
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.OTP_SEND_SUCCESSFULLY,_token);
    } catch(error) {
        logger.error(`error_${CURRENT_FILE_NAME}_sendOtp`, error.message);
        if(error.error_type){
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
        }
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.SOMETHING_WENT_WRONG)
    }
}

/**
 * Get Email of User using First name, Last name, Business Legal name.
 * @param {*} body
 * @returns
 */
USER_SERVICE.forgetUserEmail = async  (body) => {
    try {
        let response = {}
        const {first_name, last_name, business_legal_name} = body;
        if(business_legal_name){
            const result= await db.sequelize.query(`select em.email from user as u join email as em on u.id = em.user_id join account as ac on u.id = ac.user_id where u.first_name = $first_name and u.last_name= $last_name and ac.business_legal_name = $business_legal_name;`, {
                bind: {first_name, last_name, business_legal_name}
            } )
            const resultInd= await db.sequelize.query(`select em.email from user as u join email as em on u.id = em.user_id join account_ind as ac on u.id = ac.user_id where u.first_name = $first_name and u.last_name= $last_name and ac.business_legal_name = $business_legal_name;`, {
                    bind: {first_name, last_name, business_legal_name}
                } )
    
            if(!result[0][0] && !resultInd[0][0]) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES. USER_DETAIL_NOT_FOUND);   
            response = result[0].concat(resultInd[0])
        }else {
            const data = await db.sequelize.query(`select em.email from user as u join email as em on u.id = em.user_id where u.first_name = $first_name and u.last_name= $last_name;`, {
                bind: {first_name, last_name}
            })
            if(!data[0][0]) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES. USER_DETAIL_NOT_FOUND);
            response = data[0]
        }
        
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN,response); 
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error);
    }
}

/**
 * Send email verification code
 * @param {*} body
 */
USER_SERVICE.forgetPassword = async (body) => {
    try {
        const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
        const userDoc = await getOneUserByCriteria({ email: body.email });
        if (!userDoc) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.USER_NOT_REGISTERED); 

        if (userDoc.user_status === "0") throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.PLEASE_CONTACT_ADMINISTRATOR); 
        if(userDoc.wrong_pass_count >= 5) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.PLEASE_CONTACT_ADMINISTRATOR); 
        const actLog = await lastCreatedDoc('user_activity_logs')
        await update('user_activity_logs',{id:actLog.dataValues.id}, {user_id: userDoc.id})
        const tokenData = { email: body.email, user_id: userDoc.id , type:"FORGET_PASSWORD"};  
        const _token = token(tokenData, SERVER.TOKEN_EXPIRE_IN);
        console.log("Pass", _token)
        let assignUrl = `${REDIRECT_FORGOT_PASSWORD_URL}`;
        if(userDoc.user_type==1){
            assignUrl=`${REDIRECT_FORGOT_PASSWORD_URL_ADMIN}`;
        }
        const data = {
            ToEmailAddress: body.email,
            toName: userDoc.full_name,
            channel: NUDGE_CHANNEL.EMAIL,
            mergeTags: [
                { "tagName": "name", "tagValue": userDoc.full_name },
                { "tagName": "URL", "tagValue": `${assignUrl}/${_token}` }
            ],
            nudgeId: nudgeConfig.forget_password.hostid
        };
        const mailData = await sendEmail(data);
            await create('nudge_logs',{user_id: userDoc.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status, status_desc:mailData.statusText, type:"FORGET_PASSWORD",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors })
           
            if (mailData.data.hasErrors ) {
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(mailData.data.errors[0]);  
            } // End of changes
            return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.EMAIL_SUCCESSFULLY_SENT);  
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        if(error?.error?.error_type) {  
            throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error); 
        }else{
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.SOMETHING_WENT_WRONG);
        }
    }
}

/**
 * Reset password
 * @param {*} body
 */
USER_SERVICE.resetPassword = async (body) => {
    let user_id = ``;
    try {
        let decode = null;
        try {
            decode = await decodeToken(body.token);
        } catch {
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.RESET_PASSWORD_LINK_EXPIRED); 
        }
        user_id = decode.user_id
        const checkPassInput = await findOne('user', {id:decode.user_id});
        if(checkPassInput.wrong_pass_count >= 5) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.PLEASE_CONTACT_ADMINISTRATOR); 
        decode.wrong_pass_count = checkPassInput.wrong_pass_count;
        const password = await USER_SERVICE.isPasswordValid(decode, body.password);
        const today = new Date().toISOString();
        await update('user', { id: decode.user_id }, { password, wrong_count: 0, valid_from: today, wrong_pass_count:0});
        const actLog = await lastCreatedDoc('user_activity_logs')
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:MESSAGES.SUCCESS_MESSAGE_GLOBAL('Password', 'changed').message, user_id:user_id}) 
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SUCCESS_MESSAGE_GLOBAL('Password', 'changed')); 
    } catch (error) {
        const actLog = await lastCreatedDoc('user_activity_logs')
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:error.message, user_id:user_id, isValid: false})
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error); 
    }
}


/**
 * Change password
 * @param {*} body
 */
USER_SERVICE.changePassword = async (body) => {
    let user_id = ``;
    try {
        body.old_password = decryptor(body.old_password);
        const criteria = { id: body._u_id };
        const user = await findOne('user', criteria);

        user_id = body._u_id
        if (!await comparePassword(body.old_password, user.password)) {
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_PASSWORD_OLD); 
        }
        const data = { user_id: body._u_id };
        const password = await USER_SERVICE.isPasswordValid(data, body.password);
        const actLog = await lastCreatedDoc('user_activity_logs')
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:MESSAGES.SUCCESS_MESSAGE_GLOBAL('Password', 'changed').message, user_id:user_id})
        await update('user', criteria, { password });
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.SUCCESS_MESSAGE_GLOBAL('Password', 'changed'));
    } catch (error) {
        const actLog = await lastCreatedDoc('user_activity_logs')
        await update('user_activity_logs',{id:actLog.dataValues.id}, {message:error?.message?.error?.message, user_id:user_id, isValid:false})
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error?.message||error); 
    }
}



/**
 * Get user countries
 * @param {*} body
 */
USER_SERVICE.getUserContries = async (body) => {
    const criteria = {}; 
    if (body['code']) criteria['code'] = body['code'];
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( MESSAGES.DEFAULT_SUCCESSN ,await getContriesByUser(criteria)); 
}
/**
 * Get current user country_code
 * @param {*} body
 */
USER_SERVICE.getCurrUserCC = async (body) => {
    const criteria= {};
    criteria.id = body.current_user.id;
    const data = await findOne('user', criteria);

    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( MESSAGES.DEFAULT_SUCCESSN,
        { country_code: data?.country_code });
}
/**
 * Get user states
 * @param {*} body
 */
USER_SERVICE.getUserStates = async (body) => {
    const criteria = {};
    if (body['country_code']) criteria['country_code'] = body['country_code'];
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( MESSAGES.DEFAULT_SUCCESSN, await getStatesByUser(criteria)); 
}

/**
 * Get user cities
 * @param {*} body
 */
USER_SERVICE.getUserCities = async (body) => {
    const criteria = {};
    if (body['state_code']) criteria['state_code'] = body['state_code'];
    return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI( MESSAGES.DEFAULT_SUCCESSN ,await getCitiesByUser(criteria)); 
}

/**
 * Reset password
 * @param {*} body
 */
USER_SERVICE.isPasswordValid = async (body, password) => {
    try {
        const criteria = {
            where: { user_id: body.user_id },
            order: [['created_at', 'DESC']]
        }
        criteria.offset = 0;
        criteria.limit = 5;
        const passwords = await findAndCountAll('password_history', criteria);
        if (!passwords.count) {
            const encodePass = await encodePassword(password);
            await create('password_history', { user_id: body.user_id, password: encodePass });  
            return true;
        }
        const encode = await encodePassword(password);
        for (let index of passwords.rows) {
            if (await comparePassword(password, index.password)) { 
                await update('user',{id:body.user_id}, {wrong_pass_count: body.wrong_pass_count + 1})
                throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.OLD_PASSWORD); 
            }
        }
        const { data } = GLOBAL_OBJ.password;
        if (passwords.count && passwords.count === data.max_password_count) {
            await remove('password_history', { id: passwords.rows[data.max_password_count - 1].id });
        }

        await create('password_history', { user_id: body.user_id, password: encode });
        return encode;
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.error|| error); 
    }
}

/**
 * Check if password is expired
 * @param {*} body
 */
USER_SERVICE.checkIfPasswordIsExpired = async (body) => {
    const password = await lastCreatedDoc(`password_history`, { user_id: body.user_id });           
    if (password) {  
        
        let currentdate = backDay(new Date())
        let expirydate = expiryDay(password.createdAt,60)       
        if (currentdate > expirydate) {
            throw MESSAGES.PASSWORD_HAS_BEEN_EXPIRE; 
        }
    }
    return true;
}

/**
 * Get all users
 * @param {*} body
 */
USER_SERVICE.getAllUsers = async body => {
    try {
        let criteria = {};
        if (body.search) {
            criteria.full_name = {
                [Op.like]: `%${body.search}%`
            }
        }
        if (body.user_type) {
            criteria.user_type = body.user_type;
        }
        body.attributes = ['id', 'full_name', 'user_type', 'user_status', 'ref_to_config'];
        const data = await countWithDetails('user', criteria, body);
        return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.DEFAULT_SUCCESSN ,data); 
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}`, error.message);
        throw RESPONSEMESSAGES.ERROR.BAD_REQUEST(error.message);
    }
}

/**
 * Lock user account
 * @param {*} user
 * @param {*} body
 */
USER_SERVICE.lockUserAccount = async (user, body) => {
    const dataToUpdate = {};
    const current = new Date();

    if (current < user.valid_from) {
        throw MESSAGES.USER_LOCK; 
    }
    if (!await comparePassword(body.password, user.password)) {
        if(user.wrong_count) {
            dataToUpdate.wrong_count = ++user.wrong_count;
        }
        else {
            dataToUpdate.wrong_count = 1;
        }
        if(dataToUpdate.wrong_count > 4) {
            const validFrom = `${new Date(addHours(new Date(), 24)).toISOString()}`;
            dataToUpdate.valid_from = validFrom;
            dataToUpdate.wrong_count = 0;
            await update('user', {id: user.id}, dataToUpdate);
            throw MESSAGES.ACCOUNT_LOCK_ATTEMPTS(5); 
        }

        await update('user', {id: user.id}, dataToUpdate);
        throw MESSAGES.WRONG_PASSWORD_ATTEMPTS(5 - dataToUpdate.wrong_count); 
    }
    return {}; 
}

/**
 * Update user profile
 * @param {*} body
 */
 USER_SERVICE.updateUserProfile = async body => {
    try {
        let phone = null;
        let address = null;
        if(!dobValidate(body.dob)) throw MESSAGES.AGE_IS_MORE_THAN_HUNDRED; 
        if(!body.current_user.phone_id) {
            body.phone.id = uuidv4();
            body.phone.count = 1;
            phone = await create('phone', body.phone);
        } else {
            phone = await update('phone', {id: body.current_user.phone_id}, body.phone);
        }
        let dataToUpdate;
        let pic;

        if(!body.current_user.address_id) {
            body.address.id = uuidv4();
            address = await create('address', body.address);
        } else {
            address = await update('address', {id: body.current_user.address_id}, body.address);
        }
        let cEmail  = await checkEmailExist(body.cEmail)
        if(!cEmail) {
            body.cEmail.id = uuidv4();
            cEmail = await create('email_secondary', body.cEmail);
        }
        let cPhone;
        if(!body.current_user.comm_phone) {
            body.cPhone.id = uuidv4();
            body.cPhone.user_id = body.current_user.id;
            cPhone = await create('phone', body.cPhone);
        } else {
            cPhone = await update('phone', {id: body.current_user.comm_phone}, body.cPhone);
        }
        const criteria = {id: body._u_id};
        if (body.profile_pic) {
          pic = await uploadFile(body.profile_pic);
          dataToUpdate = {
            first_name: body.first_name,
            last_name: body.last_name,
            dob: body.dob,
            address_id: address.id,
            phone_id: phone.id,
            comm_email: cEmail.id,
            comm_phone: cPhone.id,
            profile_picture_id: pic.imageName,
          };
        } else {
          dataToUpdate = {
            first_name: body.first_name,
            last_name: body.last_name,
            dob: body.dob,
            address_id: address.id,
            phone_id: phone.id,
            comm_email: cEmail.id,
            comm_phone: cPhone.id,
            profile_picture_id: " ",
          };
        }
        splitNames(dataToUpdate);
       await update('user', criteria, dataToUpdate);
      return RESPONSEMESSAGES.SUCCESSRESPONSE.MISSCELANEOUSAPI(MESSAGES.USER_UPDATED_SUCCESSFULLY) ; 
    } catch(error) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
    }
}

/**
 * Save activity logs
 * @param {*} activity
 * @returns
 */
USER_SERVICE.saveUserActivity = async (activity) => {
    try {
        activity.id = uuidv4();
        await create('user_activity_logs',activity);
        return MESSAGES.DEFAULT_SUCCESS;
    } catch (error) {
        throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error.message); 
    }
}
/**
 * Update verified status
 */
const updateVerifiedStatus = async (user_id) => {
    return Promise.all([
        await updateUserEmail({ user_id }, { is_verified: 1 }),      
    ]);
}


module.exports = USER_SERVICE;