'use strict';

const Joi = require('joi');
const { updateUserStatus, getAllUser, updateUserType, paymentEngineLogs,
    nudgeLogs, getUserKyc, getFilteredAlluser, getAllTrans, getAllSharePay,
    getActivity, updateUserTwa, sendForgetPass, switchUserMode,
    updateUserKycStatus, getDropDown, updateDropDown, addDropDown,
    deleteDropDown, userActivityLogs, generateBill, cancelBill,
    feePull, updateUserDocumentStatus, downloadUserKycDocs, deleteUsersAllData,
    resetOtpCount, generateBillInd, cancelBillInd, getOtpList, migrateDb, getMaintainanceMode,
    setMaintainanceMode,
} = require('../../modules/admin/admin.controller');
const { convertErrorIntoReadableForm, authorization } = require('../../utils/bin/common');
const { requiredHandler } = require('../../utils/bin/joiErrorHandler');
const { COMMON_TYPE, USER_TYPE } = require('../../utils/constants');
const { KYC_FILE_STATUS, FILE_VERIFICATION_TYPE } = require('../../utils/enums');

let Routes = () => [
    {
        method: 'POST',
        path: '/v1/admin/user/get_all',
        joiSchemaForSwagger: {
            body: {
                filter: {
                    email: Joi.string().optional().allow('').description('Enter user email accepted filter contains, startswith').label('email'),
                    user_name: Joi.string().optional().allow('').description('Enter user_name').label('user_name accepted filter filter isequal, isnotequal, startswith, contains'),
                    user_status: Joi.string().optional().allow('').description('Enter user_status eg: 1 for Active 0 for Inactive accepted filter filter isequal, isnotequal,').label('user_status'),
                    email_verified: Joi.string().optional().allow('').description('Enter email_verified eg: 1 for true 0 for False accepted filter filter isequal, isnotequal,').label('email_verified'),
                    valid_from: Joi.string().optional().allow('').description('Enter valid_from in YYYY-MM-DD format accepted filter isequal, isnotequal, greaterthan, greaterthanorequal, lessthan, lessthanorequal').label('valid_from'),
                    valid_to: Joi.string().optional().allow('').description('Enter valid_from in YYYY-MM-DD format accepted filter isequal, isnotequal, greaterthan, greaterthanorequal, lessthan, lessthanorequal').label('valid_to'),
                    last_login: Joi.string().optional().allow('').description('Enter last_login in YYYY-MM-DD format accepted filter isequal, isnotequal, greaterthan, greaterthanorequal, lessthan, lessthanorequal').label('last_login'),
                    country_code: Joi.string().optional().description("Enter country code").label('country code')
                },
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get All  user`,
            model: `GET_ALL_USER`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: getFilteredAlluser
    },
    {
        method: 'PUT',
        path: '/v1/admin/user/update/user_status',
        joiSchemaForSwagger: {
            query: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                user_status: Joi.string().required().default('1').description('Enter user status eg: 0 for inactive and 1 for active'),
                user_status_reason: Joi.string().required().description('Enter reason').label('user_status_reason')
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Update user's status `,
            model: `UPDATE_USER_STATUS`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: updateUserStatus
    },
    {
        method: 'PUT',
        path: '/v1/admin/user/update/user_twa',
        joiSchemaForSwagger: {
            query: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                two_way_auth: Joi.string().required().default('1').description('Enter user two_way_auth eg: 0 for False and 1 for true').label('two_way_auth'),
                two_factor_auth_reason: Joi.string().required().description('Enter user two_factor_auth_reason').label('two_factor_auth_reason')
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Update User's Two way Auth `,
            model: `UPDATE_USER_TWA`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: updateUserTwa
    },
    {
        method: 'PUT',
        path: '/v1/admin/user/update/user_type',
        joiSchemaForSwagger: {
            query: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                user_type: Joi.string().required().default('2').description('Enter user type eg: 1 for ADMIN and 2 for CUSTOMER'),
                user_type_reason: Joi.string().required().description('Enter reason').label('user_type_reason')
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Update user's type `,
            model: `UPDATE_USER_TYPE`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: updateUserType
    },   
    {
        method: 'POST',
        path: '/v1/admin/user/forget_password',
        joiSchemaForSwagger: {
            body: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                flag: Joi.boolean().default(true).required().description('Enter flag').label('flag'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Forget password of a user using user_id`,
            model: `FORGET_USER_PASSWORD`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: sendForgetPass
    },
    {
        method: 'POST',
        path: '/v1/admin/user/switch_mode',
        joiSchemaForSwagger: {
            body: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                is_test: Joi.boolean().default(true).required().description('Enter is_test to switch mode EG: true(1) for Test mode and false(0) for Live mode ').label('is_test'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Switch User mode using user_id`,
            model: `SWITCH_USER_MODE`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: switchUserMode
    },
    /* RESET OTP COUNT */
    {
        method: 'PUT',
        path: '/v1/admin/user/resetOtpCount/',
        joiSchemaForSwagger: {
            body: {
                user_id: Joi.string().optional().allow('').description('Enter user id of requested user ').label('User id'),
                customer_number: Joi.string().required().description('Enter customer number ').label('customer_number'),
                payment_request_id: Joi.string().optional().allow('').description('Enter payment request id ').label('payment_request_id'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Delete otp count requested by user`,
            model: `RESET_OTP_COUNT`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: resetOtpCount
    },
    /* Get all OTP list */
    {
        method: 'POST',
        path: '/v1/admin/user/otp/getAll',
        joiSchemaForSwagger: {
            body: {
                filter: {
                    user_id: Joi.string().optional().allow('').description('Enter user id accepted filter contains, startswith ,isequal,isnotequal').label('user_id'),
                    valid_till: Joi.string().optional().allow('').description('Enter user id accepted filter isequal,isnotequal,greaterthan, greaterthanorequal, lessthan,lessthanorequal').label('valid_till'),
                    type: Joi.string().optional().allow('').description('Enter type accepted filter isequal,isnotequal').label('type'),
                    created_at: Joi.string().optional().allow('').description('Enter created at accepted filter isequal,isnotequal,greaterthan, greaterthanorequal, lessthan,lessthanorequal').label('created_at'),
                    customer_number: Joi.string().optional().allow('').description('Enter customer number accepted filter contains, startswith ,isequal,isnotequal').label('customer_number'),
                    wrong_otp_count: Joi.string().optional().allow('').description('Enter wrong otp count accepted filter isequal,isnotequal,greaterthan, greaterthanorequal, lessthan,lessthanorequal').label('wrong_otp_count'),
                    send_count: Joi.string().optional().allow('').description('Enter send count accepted filter isequal,isnotequal,greaterthan, greaterthanorequal, lessthan,lessthanorequal').label('send_count'),
                    payment_request_id: Joi.string().optional().allow('').description('Enter user id accepted filter contains, startswith').label('send_count'), 
                                       
                },
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get all otp list`,
            model: `GET_OTP_LIST`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: getOtpList
    },
    {
        method: 'POST',
        path: '/v1/admin/logs/nudge',
        joiSchemaForSwagger: {
            body: {
                filter: {
                    email_or_phone: Joi.string().optional().allow('').description('Enter user email_or_phone accepted filter contains, startswith, isequal, isnotequal').label('email_or_phone'),
                    url: Joi.string().optional().allow('').description('Enter url accepted filter filter isequal, isnotequal, startswith, contains').label('url'),
                    status: Joi.string().optional().allow('').description('Enter status accepted filter filter isequal, isnotequal,').label('status'),
                    status_desc: Joi.string().optional().allow('').description('Enter status_desc accepted filter filter isequal, isnotequal,').label('status_desc'),
                    type: Joi.string().optional().allow('').description('Enter type accepted filter filter isequal, isnotequal, contains, startswith').label('status'),
                    createdAt: Joi.string().optional().allow('').description('Enter createdAt in YYYY-MM-DD format accepted filter isequal, isnotequal, greaterthan, greaterthanorequal, lessthan, lessthanorequal').label('createdAt'),
                    updatedAt: Joi.string().optional().allow('').description('Enter updatedAt in YYYY-MM-DD format accepted filter isequal, isnotequal, greaterthan, greaterthanorequal, lessthan, lessthanorequal').label('updatedAt'),
                    hasErrors: Joi.string().optional().allow('').description('Enter hasErrors eg: 1 for true 0 for False accepted filter filter isequal, isnotequal,').label('hasErrors'),
                },
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get Nudge Logs`,
            model: `GET_NUDGE_LOGS`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: nudgeLogs
    },   

    {
        method: 'GET',
        path: '/v1/admin/logs/user_activity',
        joiSchemaForSwagger: {
            query: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
                type: Joi.string().optional().allow('').description('Enter valid type accepted type FORGET_PASSWORD_LOGS,CHANGE_PASSWORD_LOGS,RESET_USER_PASSWORD_LOGS,INVALID_LOGS,LOGIN_AND_LOGOUT').label('type')
            },           
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get User activity logs`,
            model: `USER_ACTIVITY_LOGS`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: getActivity
    },
    
    {
        method: 'POST',
        path: '/v1/admin/logs/user_activity_logs/all',
        joiSchemaForSwagger: {
            body: {
                filter: {
                    user_id: Joi.string().optional().allow('').description('Enter user id filter contains, startswith, isequal, isnotequal').label('user_id'),
                    email: Joi.string().optional().allow('').description('Enter user email filter contains, startswith, isequal, isnotequal').label('email'),
                    from_date: Joi.string().required().allow('').description('Enter from_date in YYYY-MM-DD format accepted').label('from_date'),
                    to_date: Joi.string().required().allow('').description('Enter to_date in YYYY-MM-DD format accepted ').label('to_date'),
                },
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get User Activity Logs All`,
            model: `GET_USER_ACTIVITY_LOGS_ALL`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: userActivityLogs
    },
    /** End of changes */    
    {
        method: 'GET',
        path: '/v1/admin/user/download_kyc_documents',
        joiSchemaForSwagger: {
            query: {
                origin: Joi.string().optional().allow('').description('Enter Origin to get data').label('Origin'),
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Get User Documents`,
            model: `GET_USER_KYC_DOCUMENTS`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: downloadUserKycDocs
    },
    {
        method: 'PUT',
        path: '/v1/admin/user/kyc_documents/update_status',
        joiSchemaForSwagger: {
            body: {
                origin: Joi.string().optional().allow('').description('Enter Origin to update based on location').label('Origin'),
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                data: Joi.array().items({
                    id: Joi.string().required().error(requiredHandler).description('Enter ID of document').label('document ID'),
                    status: Joi.string().required().valid(...KYC_FILE_STATUS).description('Enter verify status').label('status'),
                    reason: Joi.string().optional().allow('').description('Enter reason on the action').label('Reason'),
                    type: Joi.string().required().valid(...FILE_VERIFICATION_TYPE).description('Enter type for verification ').label('type'),
                }).min(1)
            },
            headers: authorization(),
            group: `ADMIN_USER`,
            description: `Update User Documents Status`,
            model: `UPDATE_USER_DOCUMENTS`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: updateUserDocumentStatus
    },
    {
        method: 'GET',
        path: '/v1/admin/share_pay_link/get_all',
        joiSchemaForSwagger: {
            query: {
                user_id: Joi.string().required().description('Enter user ID').label('User ID'),
                limit: Joi.number().required().description('Limit').label('limit'),
                offset: Joi.number().required().description('Enter Offset').label('offset'),
            },
            headers: authorization(),
            group: `ADMIN_TRANSACTION`,
            description: `Get All Share Payment link based on User`,
            model: `GET_ALL_SHARE_PAYMENT_LINK`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: getAllSharePay
    },
    {
        method: 'POST',
        path: '/v1/admin/drop_downs',
        joiSchemaForSwagger: {
            body: {
                name: Joi.string().required().description('Enter name of drop down').label('name'),
                value: Joi.string().required().description('Enter value of drop down ').label('value'),
            },
            headers: authorization(),
            group: `ADMIN_DROP_DOWN`,
            description: `Add drop down list`,
            model: `ADD_DROP_DOWN_LIST`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: addDropDown
    },
    {
        method: 'PUT',
        path: '/v1/admin/drop_downs/:id',
        joiSchemaForSwagger: {
            params: {
                id: Joi.string().required().description('Enter id of drop down').label('id'),
            },
            body: {
                name:  Joi.string().required().description('Enter name of drop down').label('name'),
                value: Joi.string().required().description('Enter value of drop down ').label('value'),
            },
            headers: authorization(),
            group: `ADMIN_DROP_DOWN`,
            description: `Update drop down list`,
            model: `UPDATE_DROP_DOWN_LIST`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: updateDropDown
    },
    {
        method: 'GET',
        path: '/v1/admin/drop_downs',
        joiSchemaForSwagger: {
            query: {
                name: Joi.string().optional().description('Enter name of drop down').label('name'),
            },
            group: `ADMIN_DROP_DOWN`,
            description: `Get drop down list`,
            model: `GET_DROP_DOWN_LIST`,
            responseClass: {}
        },
        auth: false,
        failAction: convertErrorIntoReadableForm,
        handler: getDropDown
    },
    {
        method: 'DELETE',
        path: '/v1/admin/drop_downs/:id',
        joiSchemaForSwagger: {
            params: {
                id: Joi.string().required().description('Enter id of drop down').label('id'),
            },
            headers: authorization(),
            group: `ADMIN_DROP_DOWN`,
            description: `Delete drop down list`,
            model: `DELETE_DROP_DOWN_LIST`,
            responseClass: {}
        },
        authTypes: [USER_TYPE.ADMIN],
        auth: true,
        failAction: convertErrorIntoReadableForm,
        handler: deleteDropDown
    },

    
    
];
module.exports = Routes;