'use strict';

const Joi = require('joi');
const { loginAdmin, updateExcelD, adminVerifyOTP, adminresendOTP, createCompany, updateCompany, getCompanyById, addRole, addAdminPage, addAdminPagePermission, addAdminRolePermission, addcompanyAdmin, addRoles, addRoleUser, getCompanyList, getcompanyAdmin, addCompanyType, getCompanyType } = require('../../modules/admin/admin.controller');
const { convertErrorIntoReadableForm, authorization } = require('../../utils/bin/common');
const { emailHandler, passwordHandler } = require('../../utils/bin/joiErrorHandler');
const { EMAILPATTERN, USER_TYPE } = require('../../utils/constants');
const { GLOBAL_OBJ } = require('../../utils/bin/global');
const { US_PAYMENT_GATEWAY_TYPE, IND_PAYMENT_GATEWAY_TYPE } = require('../../utils/enums');
const { route } = require('../../utils/bin/routeUtils');
const routes = require('..');

let Routes = () => {
//    const {data : {min_password_length}} = GLOBAL_OBJ.password;
let min_password_length = 8
return [
        {
            method: 'POST',
            path: '/api/v1/login',
            joiSchemaForSwagger: {
                body: {
                    email: Joi.string().email().required().pattern(EMAILPATTERN)
                        .error(emailHandler).allow(``).description(`Admin\'s email id.`).label(`Email`),
                        password: Joi.string().required().min(min_password_length)
                        .error(passwordHandler).allow(``).description(`User password.`).label(`Password`),
                    //user_type: Joi.number().valid(USER_TYPE.ADMIN).required().description('Enter user type').label('User Type')
                },
                group: `LOGIN`,
                description: `Admin user.`,
                model: `ADMIN_USER`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: loginAdmin
        },        
     
        {
            method: 'POST',
            path: '/v1/admin/verify_otp',
            joiSchemaForSwagger: {
                body: {
                    token: Joi.string().required().description(`Enter token`).label(`Token`),
                    otp: Joi.string().required().description(`Enter OTP`).label(`Token`),
                },
                group: `ADMIN_AUTH`,
                description: `Admin Verify OTP!`,
                model: `ADMIN_VERIFY_OTP`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: adminVerifyOTP
        },
       
        {
            method: 'POST',
            path: '/v1/admin/resend_otp',
            joiSchemaForSwagger: {
                body: {
                    token: Joi.string().required().description(`Enter token`).label(`Token`),
                },
                group: `ADMIN_AUTH`,
                description: `Admin Resend Verify OTP!`,
                model: `ADMIN_RESEND_VERIFY_OTP`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: adminresendOTP
        },        
        {
            method: 'POST',
            path: '/v1/admin/create/company',
            joiSchemaForSwagger: {
                query: {
                    short_name: Joi.string().optional().allow('').description('Enter short Name').label('Short Name'),
                    ename: Joi.string().optional().allow('').description('Enter English Name').label('English Name'),
                    aname: Joi.string().optional().allow('').description('Enter aname').label('Aname'),
                    phone: Joi.string().optional().allow('').description("Enter phone").label('phone'),                
                    email: Joi.string().required().description("Enter email ").label('Email'),
                    countries_id: Joi.string().optional().description("Enter Contries id ").label('Country id'),
                    status: Joi.boolean().optional().description("Enter status ").label('Enter Status'),
                    cr: Joi.number().optional().allow('').description("Enter cr").label('cr'),
                    logo: Joi.string().optional().allow('').description("Enter lgo").label('logo'),
                    long: Joi.string().optional().allow('').description("Enter long").label('long'),
                    lat: Joi.string().optional().allow('').description("Enter lat").label('lat'),
                    company_type_id: Joi.string().required().description("Enter company type").label('Company Type'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Update user's data in excel file`,
                model: `Company`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: createCompany
        },     
        {
            method: 'PUT',
            path: '/v1/admin/update/company',
            joiSchemaForSwagger: {
                body: {                    
                    id: Joi.string().required().description('Enter id').label('id'),
                    short_name: Joi.string().optional().description('Enter short Name').label('Short Name'),
                    ename: Joi.string().optional().description('Enter English Name').label('English Name'),
                    aname: Joi.string().optional().description('Enter aname').label('Aname'),
                    phone: Joi.string().required().description("Enter phone").label('phone'),                
                    email: Joi.string().required().description("Enter email ").label('Email'),
                    countries_id: Joi.string().required().description("Enter Contries id ").label('Country id'),
                    status: Joi.boolean().optional().description("Enter status ").label('Enter Status'),
                    cr: Joi.number().optional().description("Enter cr").label('cr'),
                    logo: Joi.string().required().description("Enter lgo").label('logo'),
                    long: Joi.string().required().description("Enter long").label('long'),
                    lat: Joi.string().required().description("Enter lat").label('lat'),
                    company_type_id: Joi.string().required().description("Enter company type").label('Company Type'),                    
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Update Company`,
                model: `Company`,
                responseClass: {}
            },
            //auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: updateCompany
        },   
        {
            method: 'GET',
            path: '/v1/admin/get/company_by_id',
            joiSchemaForSwagger: {
                query: {
                    id: Joi.string().optional().description('Enter id').label('id'),                   
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `get Company by id `,
                model: `Company`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: getCompanyById
        },          
        {
            method: 'POST',
            path: '/v1/admin/add/companyType',
            joiSchemaForSwagger: {
                body: {                                                            
                    ename: Joi.string().optional().description('Enter English Name').label('English Name'),
                    aname: Joi.string().optional().description('Enter aname').label('Aname'),                   
                    type: Joi.string().required().description("Enter  type").label('Type'),                    
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `add Company type`,
                model: `COMPANY_TYPE`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addCompanyType
        },          
        {
            method: 'GET',
            path: '/v1/admin/get/companyType',
            joiSchemaForSwagger: {
                query: {                                                            
                    id: Joi.string().optional().description('Enter id').label('id')                                      
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `get Company type`,
                model: `COMPANY_TYPE`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: getCompanyType
        },          
        {
            method: 'POST',
            path: '/v1/admin/get/company_list',
            joiSchemaForSwagger: {                              
                body: {
                    filter: {
                        id: Joi.string().optional().allow('').description('Enter id to search accepted search contains, startswith, isequal, isnotequal').label('company id'),
                        email: Joi.string().optional().allow('').description('Enter email to search accepted search contains, startswith, isequal, isnotequal').label('cmpany email id'),                      
                        company_type: Joi.string().optional().allow('').description('Enter type to search accepted search contains, startswith, isequal, isnotequal').label('company type'),                        
                        created_at: Joi.string().optional().allow('').description('Enter created to search accepted search contains, startswith, isequal, isnotequal').label('created at ')                                                                                   
                    },
                    limit: Joi.number().required().description('Limit').label('limit'),
                    offset: Joi.number().required().description('Enter Offset').label('offset'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `get Company list `,
                model: `COMPANY_LIST`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: getCompanyList
        },          
        {
            method: 'POST',
            path: '/v1/admin/add/company_admin',
            joiSchemaForSwagger: {
                query: {
                    first_name: Joi.string().required().allow(``).description(`User\'s first name.`).label(`First name`),
                    last_name: Joi.string().optional().allow(``).description(`User\'s last name.`).label(`Last name`),
                    email: Joi.string().required().lowercase().description(`User\'s email id.`).label(`Email`),
                    password: Joi.string().required().min(min_password_length)
                    .error(passwordHandler).allow(``).description(`User password.`).label(`Password`),                                    
                    company_id: Joi.string().optional().description("Enter company id ").label('Company id'),                   
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `add company admin`,
                model: `Company`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addcompanyAdmin
        }, 

        {
            method: 'POST',
            path: '/v1/admin/get/companyAdmin/by_company_id',
            joiSchemaForSwagger: {
                query: {                                                                  
                    company_id: Joi.string().optional().description("Enter company id ").label('Company id'),                   
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `add company admin`,
                model: `Company`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: getcompanyAdmin
        }, 
        
        {
            method: 'POST',
            path: '/v1/admin/add/role',
            joiSchemaForSwagger: {
                query: {
                    role_name: Joi.string().optional().description('Enter name').label('Name'),
                    status: Joi.string().optional().description('Enter status').label('status'),
                    company_id: Joi.string().optional().description("Enter company id ").label('Company Id'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Admin add role`,
                model: `Admin permission`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addRole
        },   
        {
            method: 'POST',
            path: '/v1/admin/add/page',
            joiSchemaForSwagger: {
                query: {
                    name: Joi.string().optional().description('Enter aname').label('Name'),
                    url: Joi.string().optional().description("Enter url ").label('URL'),
                    status: Joi.string().optional().description('Enter status').label('Status'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Admin add page`,
                model: `Admin permission`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addAdminPage
        },   
        {
            method: 'POST',
            path: '/v1/admin/add/page_permission',
            joiSchemaForSwagger: {
                query: {
                    page_id: Joi.string().optional().description("Enter page id ").label('page id'),
                    name: Joi.string().optional().description('Enter aname').label('Name'),
                    status: Joi.string().optional().description('Enter status').label('Status'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Admin add page`,
                model: `Admin permission`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addAdminPagePermission
        },   
        {
            method: 'POST',
            path: '/v1/admin/add/role_permission',
            joiSchemaForSwagger: {
                query: {
                    role_id: Joi.string().optional().description("Enter role id ").label('Role id'),
                    permission_id: Joi.string().optional().description("Enter permission id ").label('Permisson id'),
                    status: Joi.string().optional().description('Enter status').label('Status'),
                    user_id: Joi.string().optional().description('Enter user id').label('User id'),
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `Admin add page`,
                model: `Admin permission`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addAdminRolePermission
        },          
        
    
        /** user roles */
        {
            method: 'POST',
            path: '/v1/admin/add/roles',
            joiSchemaForSwagger: {
                query: {
                    name: Joi.string().required().description("Enter role name ").label('Role name'),
                    description: Joi.string().optional().description("Enter description ").label('Role description'),                   
                    status: Joi.boolean().required().description("Enter active status like true or false").label('Role description'), 
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `add roles`,
                model: `Roles`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addRoles
        },           
        {
            method: 'POST',
            path: '/v1/admin/add/role_user',
            joiSchemaForSwagger: {
                query: {
                    user_id: Joi.string().optional().description("Enter role id ").label('Role id'),
                    role_id: Joi.string().optional().description("Enter company id ").label('Company id'),                                        
                },
                headers: authorization(),
                group: `ADMIN`,
                description: `add role user`,
                model: `Roles`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.ADMIN],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addRoleUser
        },   
    ];
    
}

module.exports = Routes;

