'use strict';

const Joi = require('joi');
const {
    login, verifyToken,verifyOTP, register, getPass, userLogout, addCompanyGate, UpdateCompanyGate, DeleteCompanyGate, GetCompanyGateList, addCompanyStaff, getCompanyUserList
} = require('../../modules/users/user.controller');
const { convertErrorIntoReadableForm, authorization } = require('../../utils/bin/common');
const { passwordHandler } = require('../../utils/bin/joiErrorHandler');
const { USER_TYPE } = require('../../utils/constants');


//const channelTypes = Object.values(GLOBAL_OBJ.channel);
let Routes = () => {
   // const {data : {min_password_length}} = GLOBAL_OBJ.password;
   let min_password_length = 8

   console.log(USER_TYPE)
    return [
        {
            method: 'POST',
            path: '/v1/user/register',
            joiSchemaForSwagger: {
                body: {
                    first_name: Joi.string().required().allow(``).description(`User\'s first name.`).label(`First name`),
                    last_name: Joi.string().optional().allow(``).description(`User\'s last name.`).label(`Last name`),
                    email: Joi.string().required().lowercase().description(`User\'s email id.`).label(`Email`),
                    password: Joi.string().required().min(min_password_length)
                    .error(passwordHandler).allow(``).description(`User password.`).label(`Password`),                
                    user_type: Joi.string().optional().description('Enter type ').label('User Type'),
                },
                group: `AUTH`,
                description: `Signup  user.`,
                model: `REGISTER_USER`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: register
        },

        {
            method: 'POST',
            path: '/v1/user/login',
            joiSchemaForSwagger: {
                body: {
                    email: Joi.string().required().description(`User\'s email id.`).label(`Email`),
                    password: Joi.string().required().min(min_password_length)
                    .error(passwordHandler).allow(``).description(`User password.`).label(`Password`),
                },
                group: `AUTH`,
                description: `Login user.`,
                model: `LOGIN_USER`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: login
        },

        {
            method: 'POST',
            path: '/v1/user/verify_otp',
            joiSchemaForSwagger: {
                body: {
                    token: Joi.string().required().description(`Enter token`).label(`Token`),
                    otp: Joi.string().required().description(`Enter OTP`).label(`Token`),
                },
                group: `AUTH`,
                description: `Verify OTP!`,
                model: `VERIFY_OTP`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: verifyOTP
        },
        {
            method: 'POST',
            path: '/v1/user/logout',
            joiSchemaForSwagger: {
                headers: authorization(),
                group: `AUTH`,
                description: `LOGOUT USER!`,
                model: `LOGOUT_USER`,
                responseClass: {}
            },
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: userLogout
        },
        
        {
            method: 'PUT',
            path: '/v1/user/verify/:token',
            joiSchemaForSwagger: {
                params: {
                    token: Joi.string().required().description(`Enter token`).label(`Token`)
                },
                group: `AUTH`,
                description: `Verify user token to verify email or phone or any other accordin tot type!`,
                model: `VERIFY_USER_EMAIL_OR_PHONE`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: verifyToken
        },

        {
            method: 'POST',
            path: '/v1/user/get_encrypted_password',
            joiSchemaForSwagger: {
                body: {
                    password: Joi.string().required().description(`Enter password`).label(`Password`)
                },
                group: `AUTH`,
                description: `Get encrypted password`,
                model: `GET_ENCRYPPTED_PASSWORD`,
                responseClass: {}
            },
            auth: false,
            failAction: convertErrorIntoReadableForm,
            handler: getPass
        },
        {
            method: 'POST',
            path: '/v1/company/add/gates',
            joiSchemaForSwagger: {
                body: {                    
                    ename: Joi.string().optional().allow('').description('Enter English Name').label('English Name'),
                    aname: Joi.string().optional().allow('').description('Enter aname').label('Aname'),
                    long: Joi.string().optional().allow('').description("Enter long").label('long'),
                    lat: Joi.string().optional().allow('').description("Enter lat").label('lat'),
                },
                headers: authorization(),                
                group: `COMPANY`,
                description: `add gate`,
                model: `ADD_GATE`,
                responseClass: {}
            },            
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addCompanyGate
            
        },               
        {
            method: 'PUT',
            path: '/v1/company/update/gate',
            joiSchemaForSwagger: {
                body: {      
                    id: Joi.string().required().description('Enter id').label('id'),
                    ename: Joi.string().optional().allow('').description('Enter English Name').label('English Name'),
                    aname: Joi.string().optional().allow('').description('Enter aname').label('Aname'),
                    long: Joi.string().optional().allow('').description("Enter long").label('long'),
                    lat: Joi.string().optional().allow('').description("Enter lat").label('lat'),   
                },
                headers: authorization(),                
                group: `COMPANY`,
                description: `add gate`,
                model: `UPDATE_GATE`,
                responseClass: {}
            },            
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: UpdateCompanyGate             
        },        
        {
            method: 'DELETE',
            path: '/v1/company/delete/gate',
            joiSchemaForSwagger: {
                query: {    
                    id: Joi.string().required().description('Enter id').label('id'),                                   
                },
                headers: authorization(),                
                group: `COMPANY`,
                description: `add gate`,
                model: `ADD_GATE`,
                responseClass: {}
            },            
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: DeleteCompanyGate            
        },                      
        {
            method: 'GET',
            path: '/v1/company/get/gateList',
            joiSchemaForSwagger: {
                query: {    
                    gate_id: Joi.string().optional().allow('').description('Enter id').label('id'),                                   
                },
                headers: authorization(),                
                group: `COMPANY`,
                description: `get gate`,
                model: `GET_GATE`,
                responseClass: {}
            },            
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: GetCompanyGateList            
        },                      
        {
            method: 'POST',
            path: '/v1/company/create/normalUser',
            joiSchemaForSwagger: {
                body: {      
                    first_name: Joi.string().optional().allow(``).description(`User\'s first name.`).label(`First name`),
                    last_name: Joi.string().optional().allow(``).description(`User\'s last name.`).label(`Last name`),
                    email: Joi.string().required().lowercase().description(`User\'s email id.`).label(`Email`),
                    phone: Joi.string().required().description(`User\'s phone id.`).label(`Phone`),
                    status: Joi.boolean().required().description(`User\'s status.`).label(`Status`),
                    password: Joi.string().required().min(min_password_length)
                    .error(passwordHandler).allow(``).description(`User password.`).label(`Password`),  
                    gate_id : Joi.string().required().description(`Gate id .`).label(`Gate id`)                                                   
                },
                headers: authorization(),                
                group: `Company user`,
                description: `add company normal user (staff)`,
                model: `ADD_STAFF`,
                responseClass: {}
            },            
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: addCompanyStaff           
        },
        {
            method: 'POST',
            path: '/v1/admin/get/company/user_list',
            joiSchemaForSwagger: {                              
                body: {
                    filter: {
                        id: Joi.string().optional().allow('').description('Enter id to search accepted search contains, startswith, isequal, isnotequal').label('company id'),
                        email: Joi.string().optional().allow('').description('Enter email to search accepted search contains, startswith, isequal, isnotequal').label('cmpany email id'),                                              
                        created_at: Joi.string().optional().allow('').description('Enter created to search accepted search contains, startswith, isequal, isnotequal').label('created at ')                                                                                   
                    },
                    limit: Joi.number().required().description('Limit').label('limit'),
                    offset: Joi.number().required().description('Enter Offset').label('offset'),
                },
                headers: authorization(),
                group: `Company user`,
                description: `get Company user list `,
                model: `GET_STAFF`,
                responseClass: {}
            },
            authTypes: [USER_TYPE.CUSTOMER],
            auth: true,
            failAction: convertErrorIntoReadableForm,
            handler: getCompanyUserList
        },
        

    ];
}
module.exports = Routes;

