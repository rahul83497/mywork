
/** @format */
module.exports = () => [
  ...require("./auth/user")(),
  //...require("./user_roles")(),
  ...require("./auth/admin")(),
  // ...require("./admin")(),
  // ...require("./admin_roles")(),
 //...require("./config")(),

  
   

];
