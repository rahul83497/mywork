'use strict';

const logger = require('../utils/logger');
const { decodeToken, Fun_IfElseCondition, Fun_checkAndCondition, Fun_checkOrCondition } = require('../utils/bin/common');
const { statusCode, MESSAGES, USER_TYPE, RESPONSEMESSAGES } = require('../utils/constants');
const { getUserEmailByCriteria, getOneUserByCriteria } = require('../modules/users/user.repository');

const fs = require('fs');
const os = require('os');
const path = require('path');

const db = require('../db/models');
// const _adminJSONFilePath = path.join(os.homedir(), process.env.CONFIG_BASE_PATH, 'apiPermissionData.json');
// const _pathForUserJSONFile = path.join(os.homedir(), process.env.CONFIG_BASE_PATH, 'apiUserPermissionData.json');
// const jsonDataForAdminPermission = JSON.parse(fs.readFileSync(_adminJSONFilePath, 'utf-8'));
// const jsonDataForUserPermission = JSON.parse(fs.readFileSync(_pathForUserJSONFile));
const AUTH = {};

/**
 * Auth validate user middleware
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */
AUTH.validateUser = async (req, res, next) => {
    try {
        const token = req.get('authorization');
        const decode = await decodeToken(token);
        const userDoc = await getOneUserByCriteria({ user_id: decode.user_id });

        if(Fun_checkAndCondition(decode.hasOwnProperty('two_way_auth'), decode.two_way_auth)) {
            return res.status(statusCode.BADREQUEST).json(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.TWO_WAY_AUTHENTICATION_ISPENDING));
        }
        if (decode.type) {
            return res.status(statusCode.BADREQUEST).json(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_TYPE));
        }
        Fun_IfElseCondition([!userDoc, ()=>{
            throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_IS_NOT_REGISTERED);
        }]);
        
        req.user = userDoc.dataValues;
        next();
    } catch (error) {
        logger.error('auth_error', error.message);
        return res.status(statusCode.UNAUTHORIZED).json(RESPONSEMESSAGES.ERRORRESPONSE.UNAUTHORIZED(MESSAGES.UNAUTHORIZED));
    }
}




/**
 * Auth validate Admin middleware
 * @param {*} req 
 * @param {*} res 
 * @param {*} next 
 */

AUTH.validateAdmin = async (req, res, next) => {
    try {

        const token = req.get('authorization');
        const decode = await decodeToken(token);
        Fun_IfElseCondition([Fun_checkAndCondition(decode.hasOwnProperty('two_way_auth'), decode.two_way_auth), ()=>{
            return res.status(statusCode.BADREQUEST).json(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.TWO_WAY_AUTHENTICATION_ISPENDING));
        }]);
        const userDoc = await getOneUserByCriteria({ user_id: decode.user_id });         
        Fun_IfElseCondition([!userDoc, ()=>{ throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EMAIL_IS_NOT_REGISTERED) }]);
        //Fun_IfElseCondition([userDoc.user_type != USER_TYPE.ADMIN , ()=>{ throw MESSAGES.YOU_DON_NT_HAVE_ADMIN_ACCESS }]);   
        Fun_IfElseCondition([userDoc.user_type != USER_TYPE.ADMIN , ()=>{ throw MESSAGES.YOU_DON_NT_HAVE_ADMIN_ACCESS }]);                                 
        // const adminDetails = await db.sequelize.query(`select * from admin_roles where id = ${userDoc.admin_role_id}`);
        // Fun_IfElseCondition([!adminDetails[0].length, ()=>{ throw MESSAGES.DO_NOT_HAVE_PERMISSION }]);                              
    //         const sqlQuery = `select pages.name as page_name, pages.url, perm.name as permission, perm.id as permission_id from role_permission as rp join user_permission as perm on rp.permission_id = perm.id join admin_pages as pages on perm.page_id = pages.id where rp.role_id = "${userDoc.admin_role_id}" `;
                                    
    //         const permittedPermission = await db.sequelize.query(sqlQuery);
    //         const havePermission = permittedPermission[0][0]?.permission;
    //         Fun_IfElseCondition([!havePermission.length, ()=>{ throw MESSAGES.DO_NOT_HAVE_PEGE_PERMISSION(page_name); }]);
    //         for(let permission of havePermission){

    //             if(permission_name.includes(permission)){
    //                 Fun_IfElseCondition([Fun_checkAndCondition(adminDetails[0][0].admin_profile == 'NONE', ["NONE", "SELECT"].includes(admin_profile)), ()=> { 
    //                     throw MESSAGES.NO_USER_ASSIGNED; 
    //                 }]);
    //                 if(Fun_checkAndCondition(adminDetails[0][0].admin_profile == 'SELECT', admin_profile == 'SELECT')){
    //                     const fileterResult = await filterQuery(userDoc.admin_role_id);
    //                     req.body.filter.email_filter = `in:${fileterResult.emailFilter}`;
    //                     req.body.filter.user_id_filter = `in:${fileterResult.useridFilter}`;
    //                 }
    //                 permissionFlag = true;
    //                 break;
    //             }
    //         }
            
    //    // }

    //     Fun_IfElseCondition([!permissionFlag, ()=>{ throw MESSAGES.DO_NOT_HAVE_PERMISSION; }]);
        req.user = userDoc.dataValues;
        next();
    } catch (error) {
        logger.error('auth_error', error.message);
        return res.status(statusCode.UNAUTHORIZED).json(RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error));
    }
}



const filterQuery = async(admin_role_id) =>{
    let useridFilter = `(`;
    let emailFilter = `(`;
    const allowedUserIds = await db.sequelize.query(`select * from admin_profiles where role_id = ${admin_role_id}`);
    Fun_IfElseCondition([!allowedUserIds[0].length, ()=>{ throw MESSAGES.NO_USER_ASSIGNED }])
  
    for(let row of allowedUserIds[0]){
        const { user_id } = row;
        useridFilter+= `"${user_id}",`
    }
    Fun_IfElseCondition([useridFilter.length>2, ()=>{
        useridFilter = useridFilter.slice(0, -1);
        useridFilter+=`)`;
    }]);
    const emailQuery = `SELECT * FROM email where user_id in ${useridFilter}`;
    const emailsDetails = await db.sequelize.query(emailQuery);
  
    for(let row of emailsDetails[0]){
        const { email } = row;
        emailFilter+= `"${email}",`
    }
    Fun_IfElseCondition([emailFilter.length > 2, ()=>{
        emailFilter = emailFilter.slice(0, -1);
        emailFilter+=`)`;
    }])
    return { emailFilter: emailFilter, useridFilter: useridFilter };
}

const roleQueryBuilder = (body)=>{
    let roleQuery = ``;
    Fun_IfElseCondition([!body.admin_role_id, ()=>{
        throw MESSAGES.ROLE_ID_NOT_VALID;
    }])
    if(body.admin_role_id == 1){
        roleQuery += `select * from user_roles where id = ${body.admin_role_id}`
    }else{
        Fun_IfElseCondition([!body.account_id, ()=>{
            throw MESSAGES.USER_ACCOUNT_ID_NOT_FOUND;
        }]);
        roleQuery += `select * from user_roles where id = ${body.admin_role_id} and account_id = "${body.account_id}"`;
    }
    Fun_IfElseCondition([!roleQuery, ()=>{
        throw MESSAGES.ACCOUNT_NOT_EXISTS;
    }])
    return roleQuery;
}
module.exports = AUTH;