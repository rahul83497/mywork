'use strict';

const { 
    CREATE_USER, VERIFY_SSN, VERIFY_EMAIL, VERIFY_EMAIL_CODE,
    UPLOAD_PASSPORT, CHECK_UPLOAD_PASSPORT_STATUS, VERIFY_UPLOAD_PASSPORT, SUBMIT_USER_CONSENT, BUSINESS_VERIFICATION, FULL_BUSINESS_SEARCH, GET_TEST_RESULT, VERIFY_PHONE, VERIFY_PHONE_CODE, UPLOAD_ID, VERIFY_UPLOAD_ID, CHECK_UPLOAD_ID_STATUS, GET_USER_TOKEN  } = require('../utils/bin/links');
const { POST } = require('../services/http');
const { create, update, findOne } = require('../modules/common/common.queries');
const logger = require('../utils/logger');
const {REQUEST_STATUS, AUTH_REQUEST_TYPE, DOCUMENT_TYPES, MESSAGES} = require('../utils/constants');
const CURRENT_FILE_NAME = 'authenticating.com';
const moment = require('moment');
const { getfiles } = require('../services/file-upload');
const { v4: uuidv4 } = require('uuid');
const { decryptor } = require('../utils/bin/common');

/**
 * Create user contact user
 * @param {*} data 
 */
const createRequest = async (body) => {
    try {
        const data = createOrUpdateData(body.dataValues);
        let payload;
        let request = {};
        if (!data.userAccessToken) {
            payload = CREATE_USER();

            if(!payload.data) payload.data = data; 
            request = await createUserRequest(body, payload);
            await update('contact',{id:body.id,count:body.count},{auth_user_access_token:request.user_access_code})            
        } else {
            request.user_access_code = data.userAccessToken;
        }
        if (request.user_access_code) {
            // Fetch the status from authenticating_status table for the request.user_access_code.
            const authStatus = await findOne('authenticating_status', {user_access_code: request.user_access_code});
            // If status = 2 only then we submit consent. else do not call the submit consent function.
            if (authStatus.status == REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id) {
                request.status = authStatus.status;
                await submitUSRConsents({userAccessCode: request.user_access_code,
                    isBackgroundDisclosureAccepted:true,
                    GLBPurposeAndDPPAPurpose: true,
                    FCRAPurpose: true, 
                    fullName: body.full_name
                  })
                await update('authenticating_status',{user_access_code: request.user_access_code},{status:REQUEST_STATUS.SUBMITTED_CONSENT.id});
            }            
        }

        if(data.ssn) {
            await ssnRequest({
                userAccessCode: request.user_access_code,
                client_ip: body.client_ip,
                user_id: body.user_id
            });    
        }

        if(body.document.document_type === DOCUMENT_TYPES.PASSPORT) {
            await passportUploadRequest({
                userAccessCode: request.user_access_code, 
                client_ip: body.client_ip, user_id: body.user_id, ...body.document
            });
        } else if(body.document.document_type == DOCUMENT_TYPES.DRIVING_LICENCE) { 
            await drivingUploadRequest({
                userAccessCode: request.user_access_code, 
                client_ip: body.client_ip, user_id: body.user_id, ...body.document
            });
        }

        return request;
    } catch (error) {
        logger.error(`error_${CURRENT_FILE_NAME}_createRequest`, JSON.stringify(error));
        throw error;
    }
}
/**
 *  Create individual user 
 * @param {*} body 
 * @param {*} payload 
 * @returns 
 */
 const createIndividualUser = async (body) => {
        const data = createOrUpdateDataIndivi(body);
        let request= {};  
        if (!data.userAccessToken) {
            const payload = CREATE_USER();

            payload.data = data;
            request = await createUserRequest(body, payload);
            await update('user',{id:body.id},{auth_user_access_token:request.user_access_code})                
        } else {
            request.user_access_code = data.userAccessToken;
        }
        if (request){
            // Fetch the status from authenticating_status table for the request.user_access_code.
            const authStatus = await findOne('authenticating_status', {user_access_code: request.user_access_code});
            // If status = 2 only then we submit consent. else do not call the submit consent function.
            if (authStatus.status !== 2) {
                request.status = authStatus.status;
                return request
            }
            const aa = {
                userAccessCode: request.user_access_code,
                isBackgroundDisclosureAccepted:1,
                GLBPurposeAndDPPAPurpose: 1,
                FCRAPurpose: 1, 
                fullName: body.full_name

            }
            await submitUSRConsents(aa)
            
         }
        return request  
}

/**
 * Create user request
 * @param {*} body 
 * @param {*} payload 
 * @returns 
 */
const createUserRequest = async (body, payload) => {
    const log = {
        status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
        info: JSON.stringify(payload),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
   
    let response;
    if (payload.headers) {
      response = await POST(
        { data: payload.data, url: payload.url },
        { headers: payload.headers }
      );
    } else {
      response = await POST(payload);
    }
        
            await create('kyc_logs', log); 
            await create('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.CREATE
            }); 
        
        
        return {user_access_code: response.data.userAccessCode}; 
}

/**
 * Verify ssn number
 * @param {*} body 
 */
const ssnRequest = async (body) => {
    const log = {
        status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const payload = VERIFY_SSN();
        if(!payload.data) payload.data = {userAccessCode: body.userAccessCode};
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
       
        const [logDoc, authenticating] = [
            await create('authenticating_status_contacts', { userAccessCode:body.userAccessCode, is_ssn_verify:response.data.isSSNValid}),
            await create('kyc_logs', log),
            await create('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.SSN_VERIFICATION
            })
        ];
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        throw new Error(data.errorMessage);
    }
}

/**
 * Verify ssn number
 * @param {*} body 
 */
 const passportUploadRequest = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const passport  = await getfiles(body.dataValues.front);
        const payload = UPLOAD_PASSPORT();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode,
            idFront: passport,
            country: 0
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        const [logDoc, authenticating] = [
            await create('kyc_logs', log),
            await create('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION
            })
        ];
        await checkPassportUploadStatus(body);
        await verifyUploadPassport(body);
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        throw new Error(data.errorMessage);
    }
}



/**
 * Check passport upload status
 * @param {*} body 
 */
 const checkPassportUploadStatus = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const payload = CHECK_UPLOAD_PASSPORT_STATUS();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        const [logDoc, authenticating] = [
            await create('kyc_logs', log),
            await update('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION
            }, {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION_STATUS
            })
        ];
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        return null;
    }
}

/**
 * Verify upload passport
 * @param {*} body 
 */
const verifyUploadPassport = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const payload = VERIFY_UPLOAD_PASSPORT();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
       
        const [logDoc, authenticating] = [
            await update('authenticating_status_contacts', { userAccessCode:body.userAccessCode}, {is_passport_verify:response.data.success}),
            await create('kyc_logs', log),
            await update('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION_STATUS
            }, {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION_DONE
            })
        ];
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        return null;
    }
}

/**
 * Verify upload Driving Licence
 * @param {*} body 
 */
const drivingUploadRequest = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const idFront  = await getfiles(body.dataValues.front);
        const idBack  = await getfiles(body.dataValues.back);
        const payload = UPLOAD_ID();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode,
            idFront: idFront,
            idBack: idBack,
            country: 0
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        const [logDoc, authenticating] = [
            await create('kyc_logs', log),
            await create('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.DRIVING_LICENCE_VERIFICATION
            })
        ];
        await checkDrivingtUploadStatus(body);
        await verifyUploadDL(body);
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        throw new Error(data.errorMessage);
    }
}
/**
 * Check driving upload status
 * @param {*} body 
 */
 const checkDrivingtUploadStatus = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const payload = CHECK_UPLOAD_ID_STATUS();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        const [logDoc, authenticating] = [
            await create('kyc_logs', log),
            await update('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                type: AUTH_REQUEST_TYPE.DRIVING_LICENCE_VERIFICATION
            }, {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.DRIVING_LICENCE_VERIFICATION_STATUS
            })
        ];
        return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        return null;
    }
}

/**
 * Verify upload passport
 * @param {*} body 
 */
const verifyUploadDL = async (body) => {
    const log = {
        status: REQUEST_STATUS.UPLOAD_PASSPORT,
        info: JSON.stringify(body),
        ip_address: body.client_ip,
        user_id: body.user_id
    };
    try {
        const payload = VERIFY_UPLOAD_ID();
        if(!payload.data) payload.data = {
            userAccessCode: body.userAccessCode
        };

        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        const [logDoc, authenticating] = [
            await create('authenticating_status_contacts', { userAccessCode:body.userAccessCode}, {is_passport_verify:response.data.success}),
            await create('kyc_logs', log),
            await update('authenticating_status', {
                user_access_code: response.data.userAccessCode,
                type: AUTH_REQUEST_TYPE.PASSPORT_VERIFICATION_STATUS
            }, {
                user_access_code: response.data.userAccessCode,
                status: REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM.id,
                data: payload.data,
                type: AUTH_REQUEST_TYPE.DRIVING_LICENCE_VERIFICATION_DONE
            })
        ];
       return {request:authenticating.dataValues,log:logDoc}; 
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        log.status = REQUEST_STATUS.SUBMITTED_TO_AUTHENTICATING_COM_FAILED.id;
        log.error = JSON.stringify(data);
        await create('kyc_logs', log);
        return null;
    }
}

/**
 * Send email verification code
 * @param {*} body 
 */
 const submitUSRConsents = async (body) => {
    try {
        const payload = SUBMIT_USER_CONSENT();
        if(!payload.data) payload.data = body;
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }     
        return response;
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        throw new Error(data.errorMessage);
    }
}

/**
 * Create user data 
 * @param {*} data 
 * @returns 
 */
const createOrUpdateData = (data) => {
    let details = {};
    if (data.ssn) {    
        data.ssn = decryptor(data.ssn);
    }
    if (data.auth_user_access_token) {
        details.userAccessToken = data.auth_user_access_token;
    }
    details = {
        ...details,
        firstName: data.first_name,
        middleName: data.middle_name || "",
        lastName: data.last_name || "",
        dob: moment(data.dob).format("DD-MM-YYYY"),
        email: data.email,
        houseNumber: data.address.house_number,
        streetName: data.address.street,
        address: data.address.house_number,
        city: data.address.city_code,
        state: data.address.state_code,
        zipCode: data.address.zip,
        ssn: data.ssn ||""
    }
    return details;
}
/**
 * Create user data 
 * @param {*} data 
 * @returns 
 */
const createOrUpdateDataIndivi = (data) => {
    let details = {};
    if (data.auth_user_access_token) {
        details.userAccessToken = data.auth_user_access_token;
    }
    details = {
        ...details,
        firstName: data.first_name,
        middleName: data.middle_name || "",
        lastName: data.last_name || "",
        dob: "10-10-1975",
        email: data.email       
    }
    return details;
}
const staticOwnerData = (data) => {
    let details = {};
   
    details = {
        ...details,
        firstName: "John",
        middleName: "Doe",
        lastName: "Smith",
        dob: "10-10-1975",
        email: "user@gmail.com",
        verificationOption: "EITHER"      
    }
    return details;
}


const submitFEINDetails = async(body, resul) => {
    try {
        body.tax_id = parseInt(decryptor(body.tax_id))
        await businessVerifications( { 
            userAccessCode: resul.user_access_code,
            businessList: [
                {
                    FEINumber: body.tax_id,
                    businessName: body.business_legal_name,
                    DUNSNumber: " ",
                    isUserABusinessContact: false
                }
            ]
        });
            const result = await getTestResults(resul);
            const data = {
              id: uuidv4(),
              user_access_code: resul.auth_user_access_token,
              user: result.data.user,
              contact_proof: result.data.contactProof,
              photo_proof: result.data.photoProof,
              company: result.data.company,
              identity_proof: result.data.identityProof,
              background_check: result.data.backgroundCheck,
              id_verification: result.data.idVerification,
              ssn_verification: result.data.SSNVerification,
              scanned_user: result.data.scannedUser,
              verify_ui: result.data.verifyUI,
              passport_data: result.data.passportData,
              fein_verification: result.data.FEINVerification,
              professional_licence: result.data.professionalLicense,
              education: result.data.education,
              employment: result.data.employment,
              consent: result.data.consent,
            };
             await create("authenticating_test_results", data);
             let authStatus;
             let respObject;
             let reason = MESSAGES.AUTHENTICATING_VERIFICATION_SUCCESS.message; 
            if(result && result.data.FEINVerification){
                if(result.data.FEINVerification.length > 0){
                    const dataRes = result.data.FEINVerification; 
                    for (let index of dataRes) {  
                        const element = index;  
                        if(element.FEINumber == body.tax_id){  
                            await update('account',{user_id:body.id}, {isAuthenticate: true, authenticateDate: new Date().toISOString()});
                            await update('kyc_status',{user_id: body.id}, {authenticating_status: 'VERIFIED', fiserv_status: 'NI', reason:reason});
                            await update('authenticating_status',{user_access_code: resul.user_access_code},{status:"3"});
                            authStatus = "VERIFIED";
                            respObject = {status:authStatus, reason}
                            break;
                        }else{
                            reason = MESSAGES.AUTHENTICATING_VERIFICATION_FAILED_USTAX.message;  
                            await update('authenticating_status',{user_access_code: resul.user_access_code},{status:"4"});
                            await update('kyc_status',{user_id: body.id}, {authenticating_status: 'REJECTED', reason:reason});
                            authStatus = 'REJECTED';
                            respObject = {status:authStatus, reason}
                        }                        
                    }
                    return respObject                    
                }else {
                    reason = MESSAGES.AUTHENTICATING_VERIFICATION_FAILED_USTAX.message; 
                    await update('kyc_status',{user_id: body.id}, {authenticating_status: 'REJECTED', reason:reason});
                    await update('authenticating_status',{user_access_code: resul.user_access_code},{status:"4"});
                    authStatus = 'REJECTED';
                    return {status:authStatus, reason}
                }
            }
        
        return {status:authStatus, reason};
    } catch(error) {        
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        throw new Error(data.errorMessage);
    }
}
/**
 * FEIN Verification or Business verification
 */
 const businessVerifications = async (body) => {  
    try {
        const payload = BUSINESS_VERIFICATION();
        if(!payload.data) payload.data = body; 
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
        return response;
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        throw new Error(data.errorMessage);
    } /** End of changes */
}

/**
 * User Get Test result
 */
 const getTestResults = async (resul) => {
    try {
        const payload = GET_TEST_RESULT();
        if(!payload.data) payload.data = {
            userAccessCode: resul.user_access_code
        };
        let response
        if(payload.headers){
            response = await POST({data:payload.data, url:payload.url}, {headers:payload.headers});
        }else{
            response = await POST(payload);
        }
       
        return response;
    } catch(error) {
        const { data } = error.response;
        logger.error(`error_${CURRENT_FILE_NAME}`, data.errorMessage);
        throw new Error(data.errorMessage);
    }
}
module.exports = {
    
    createRequest,
    createIndividualUser,
    submitUSRConsents,
    ssnRequest,
    passportUploadRequest,
    checkPassportUploadStatus,
    verifyUploadPassport,
    businessVerifications,
    getTestResults,
    submitFEINDetails
}
   