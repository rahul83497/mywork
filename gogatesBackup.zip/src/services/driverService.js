// const factory = require("./handlersFactory");
// const Driver = require("../models/driverModel");

// // Nested route
// // GET /api/v1/products/:productId/reviews
// exports.createFilterObj = (req, res, next) => {
//   let filterObject = {};
//   if (req.params.transportId)
//     filterObject = { transport: req.params.transportId };
//   req.filterObj = filterObject;
//   next();
// };

// // @desc    Get list of reviews
// // @route   GET /api/v1/reviews
// // @access  Public
// exports.getDrivers = factory.getAll(Driver);

// // @desc    Get specific Driver by id
// // @route   GET /api/v1/Drivers/:id
// // @access  Public
// exports.getDriver = factory.getOne(Driver);

// // Nested route (Created)
// exports.setTransportIdAndUserIdToBody = (req, res, next) => {
//   if (!req.body.transport) req.body.transport = req.params.transportId;
//   if (!req.body.user) req.body.user = req.user._id;
//   next();
// };
// // @desc    Create Driver
// // @route   POST  /api/v1/Drivers
// // @access  Private/Protect/User
// exports.createDriver = factory.createOne(Driver);

// // @desc    Update specific Driver
// // @route   PUT /api/v1/Drivers/:id
// // @access  Private/Protect/User
// exports.updateDriver = factory.updateOne(Driver);

// // @desc    Delete specific Driver
// // @route   DELETE /api/v1/Drivers/:id
// // @access  Private/Protect/User-Admin-Manager
// exports.deleteDriver = factory.deleteOne(Driver);
