// 'use strict';

// const BUCKET_NAME = process.env.BUCKET_NAME;
// const db = require('../db/models');
// const { MESSAGES, RESPONSEMESSAGES } = require('../utils/constants');
// const { v4: uuidv4 } = require('uuid');
// const AWS = require('aws-sdk');
// const credentials = new AWS.SharedIniFileCredentials({ profile: 'default' });
// const logger = require('../utils/logger');
// const { Fun_IfElseCondition } = require('../utils/bin/common');
// AWS.config.credentials = credentials;
// const AWS_REGION = process.env.AWS_REGION;
// AWS.config.update({ region: AWS_REGION });
// const S3 = new AWS.S3();

// const CURRENT_FILE_NAME = "File Upload";

// const FILE_UPLOAD = {};

// /**
//  * Upload FILE
//  * @param {*} base64 
//  * @param {*} type 
//  * @returns 
//  */
// FILE_UPLOAD.uploadFile = (base64, type) => {
//     return new Promise(async function (resolve, reject) {
//         try {
//             let ext = "";
//             let buf = "";
//             const extData = getExtension(base64, type); /** Shivam GLOB-1439 */
//             if (extData) {
//                 ext = extData.ext;
//                 buf = extData.buf;
//             }
//             const uuid = uuidv4();
//             const imageName = uuid;
//             const bucket = `${BUCKET_NAME}/utilli`;
//             const values = {
//                 Bucket: bucket,
//                 Key: imageName + "." + ext.toLowerCase(),
//                 Body: buf,
//                 ContentEncoding: 'base64',
//                 ContentType: 'image/jpeg, application/pdf, application/vnd.ms-excel, application/msword, application/ms-powerpoint, application/vnd.openxmlformats-officedocument.wordprocessingml.document, data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, data:application/vnd.openxmlformats-officedocument.presentationml.presentation, application/vnd.ms-powerpoint'
//             };

//             return S3.putObject(values, (err, result) => {
//                 if (err) {
//                     logger.error(`error_${CURRENT_FILE_NAME}`, err.message);
//                     reject(err);
//                 }
//                 resolve({ status: "success", imageName: imageName + '.' + ext.toLowerCase() });
//             });
//         } catch (error) {
//             reject(error);
//         }
//     })
// }

// /**
//  * Remove files
//  * @param {*} data 
//  * @returns 
//  */
// FILE_UPLOAD.removefiles = async (imageName) => {
//     return new Promise(function (resolve, reject) {

//         let bucket = `${BUCKET_NAME}/utilli`;
//         let params = { Bucket: bucket, Key: imageName };
//         S3.deleteObject(params, async (err, datas3) => {
//             if (err) {
//                 logger.error(`error_${CURRENT_FILE_NAME}`, err.message);
//                 return reject(false);
//             } else {
//                 const query = `DELETE FROM kyc WHERE id = '${imageName}'`;
//                 await db.sequelize.query(query);
//                 resolve(true)
//             }
//         });
//     });
// }
// /**
//  * Remove files
//  * @param {*} data 
//  * @returns 
//  */
// FILE_UPLOAD.removefileInds = async (imageName) => {
//     return new Promise(function (resolve, reject) {

//         let bucket = `${BUCKET_NAME}/utilli`;
//         let params = { Bucket: bucket, Key: imageName };
//         S3.deleteObject(params, async (err, datas3) => {
//             if (err) {
//                 logger.error(`error_${CURRENT_FILE_NAME}`, err.message);
//                 return reject(false);
//             } else {
//                 const query = `DELETE FROM kyc_ind WHERE front = '${imageName}'`;
//                 await db.sequelize.query(query);
//                 resolve(true)
//             }
//         });
//     });
// }

// /**
//  * File upload
//  * @param {*} imageName 
//  * @returns 
//  */
// FILE_UPLOAD.getfiles = async (imageName) => {

//     if(!imageName){
//         return;
//     }
//     return new Promise(async function (resolve, reject) {
//         const bucket = `${BUCKET_NAME}/utilli`;
//         const params = { Bucket: bucket, Key: `${imageName}` };

//         const splitName = imageName.split('.');
//         if (splitName.length === 1) throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.INVALID_EXTENSION);
//         const pre = base64Prefix(splitName[splitName.length - 1]);
//         return S3.getObject(params, function (err, data) {

//             if (err) {
//                 logger.error(`error_${CURRENT_FILE_NAME}`, err.message);
//                 return reject(err);
//             }
        
//             else {
//                 resolve(`${pre}${data.Body.toString('base64')}`);   
//             }
//         });
//     });
// }


// /**
//  * Get extension
//  * @param {*} data 
//  * @param {*} type 
//  * @returns 
//  */
// const getExtension = (data, type) => {
//     try {
//         let ext = null;
//         let buf = null;

//         if (!type) {
//             ext = data.match(/[^:/]\w+(?=;|,)/)[0];
//             const data1 = data.split("base64,")[1]
//             buf = Buffer.from(data1, 'base64');
            
//         } else if (type == "textType") {
//             ext = data.substring(1, 4);
//             buf = Buffer.from(data.replace(/^data:image\/\w+;base64,/, ""), 'base64');
//         }else if (type == "excelType") { /** Shivam GLOB-1439 */
//             ext = "sheet";
//             buf = Buffer.from(data.replace(/^data:image\/\w+;base64,/, ""), 'base64');
//         }
//         return { ext, buf }
//     } catch (error) {
//         throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.EXTENSION_NOT_VALID)
//     }
// }

// /**
//  * Base 64 prefix
//  * @param {*} ext 
//  * @returns 
//  */
// const base64Prefix = (ext) => {
//     const extension = ext.toLowerCase();
//     if (extension === 'png' ) {
//         return 'data:image/png;base64,';
//     }
//     if (extension === 'jpg' || extension === 'jpeg') {
//         return 'data:image/jpeg;base64,';
//     }
//     if (extension === 'pdf') {
//         return 'data:application/pdf;base64,';
//     }
//     if (extension === 'sheet') {
//         return 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'
//     }
//     if (extension === '.sheet') {
//         return 'data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,'
//     }
//     if (extension === '.presentation' ||extension === 'presentation' ) {
//         return 'data:application/vnd.openxmlformats-officedocument.presentationml.presentation;base64,'
//     }
//     if (extension === '-excel') {
//         return 'data:application/vnd.ms-excel;base64,'
//     }
//     if (extension === '-powerpoint') {
//         return 'data:application/vnd.ms-powerpoint;base64,'
//     }
//     if (extension === 'msword') {
//         return 'data:application/msword;base64,'
//     }
//     if (extension === 'document') {
//         return 'data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,'
//     }
//     return 'data:image/png;base64,'
// }

// module.exports = FILE_UPLOAD;