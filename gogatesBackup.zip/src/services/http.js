// 'use strict';
// const { GLOBAL_OBJ } = require('../utils/bin/global');
// const { MESSAGES, SERVER, RESPONSEMESSAGES, NUDGE_CHANNEL } = require('../utils/constants');
// const logger = require('../utils/logger');
// const { SEND_NUDGE_EMAIL, SEND_NUDGE_SMS, CREATE_USER, SEND_TO_NUDGE } = require('../utils/bin/links');
// const axios = require('axios');
// const { generate } = require('otp-generator');
// const { findOne, create } = require('../modules/common/common.queries');
// const { SMS_TYPE, OTP_TYPE } = require('../utils/enums');
// const { addMinutes } = require('../utils/bin/common');
// const fs = require("fs");
// const os = require("os");
// const path = require("path");
// // const _path = path.join(os.homedir(), process.env.CONFIG_BASE_PATH, 'merchantCertificate_sandbox.pem');
// // const merchantIdentityCert = fs.readFileSync(_path);
// // const _path_key = path.join(os.homedir(), process.env.CONFIG_BASE_PATH, 'certificate_sandbox.key');
// // const merchantIdentityKey = fs.readFileSync(_path_key);
// const https = require('https');

// const CURRENT_FILE_NAME = 'http';

// /**
//  * Send verification email
//  * @param {*} data
//  * @returns
//  */
// const sendEmail = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         axios.defaults.headers.common = {
//             "Authorization": nudgeConfig.token,
//             "Content-Type": "application/json"
//         };
//         const URL = `${SEND_TO_NUDGE(nudgeConfig.host)}`
//         const result = await axios({
//             method: 'post',
//             url: URL,
//             data: body,
//         });
//         logger.info(`info_${CURRENT_FILE_NAME}`, JSON.stringify(result.data));

//         return result; 
//     } catch (error) {
//         const { data } = error.response;
//         const mesg =  (data?.title || error.message);
//         logger.error(`error_${CURRENT_FILE_NAME}_send_nudge_email`, mesg);
//         throw new Error(mesg);
//     }
// }

// /**
//  * Send verification on phone
//  * @param {*} data
//  * @returns
//  */
//  const sendPhone = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         axios.defaults.headers.common = {
//             "Authorization": nudgeConfig.token,
//             "Content-Type": "application/json"
//         };
//         const result = await axios({
//             method: 'post',
//             url: `${SEND_TO_NUDGE(nudgeConfig.host)}`,
//             data: body,
//         });
//         logger.info(`info_${CURRENT_FILE_NAME}`, JSON.stringify(result.data));
//         return result; 
//     } catch (error) {
//         const { data } = error.response;
//         const mesg =  (data?.title || error.message);
//         logger.error(`error_${CURRENT_FILE_NAME}_send_nudge_email`, mesg);
//         throw new Error(mesg);
//     }
// }


// /**
//  * Get data
//  */
// const GET = async (link, options) => {
//     try {
//         axios.defaults.headers.common = {
//         };
//         if (options && options.headers) {
//             const keys = Object.keys(options.headers);
//            
//             keys.forEach(_k => {
//                 axios.defaults.headers.common[_k] = options.headers[_k]
//             });
//         }
//         return await axios({ 
//             method: 'get',
//             url: link,
//         });
//     }
//           catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_GET`, error.message);
//         throw error;
//     }
// }

// /**
//  * Post data
//  */
// const POST = async (payload, options) => {
//     try {
//         axios.defaults.headers.common = {
//             "Content-Type": "application/json"
//         };
//         if (options && options.headers) {
//             const keys = Object.keys(options.headers);
// 
//             keys.forEach(_k => {
//                 axios.defaults.headers.common[_k] = options.headers[_k]
//             });
//         }
//         return await axios({ 
//             method: 'post',
//             url: payload.url,
//             data: payload.data
//         });
//     } catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_POST`, error.message);
//         throw error;
//     }
// }

// /**
//  * PUT data
//  */
// const PUT = async (payload, options) => {
//     try {
//         axios.defaults.headers.common = {
//             "Content-Type": "application/json"
//         };
//         if (options && options.headers) {
//             const keys = Object.keys(options.headers);
//             keys.forEach(_k => {
//                 axios.defaults.headers.common[_k] = options.headers[_k]
//             });
//         }
//         return await axios({ 
//             method: 'put',
//             url: payload.url,
//             data: payload.data
//         });
//     } catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_PUT`, error.message);
//         throw error;
//     }
// }
// /**
//  * Patch data
//  */
// const PATCH = async (payload, options) => {
//     try {
//         axios.defaults.headers.common = {
//             "Content-Type": "application/json"
//         };
//         if (options && options.headers) {
//             const keys = Object.keys(options.headers);
//             keys.forEach(_k => {
//                 axios.defaults.headers.common[_k] = options.headers[_k]
//             });
//         }
//         return await axios({ 
//             method: 'patch',
//             url: payload.url,
//             data: payload.data
//         });
//     } catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_PATCH`, error.message);
//         throw error;
//     }
// }
// /**
//  * Delete
//  * @param {*} payload
//  * @param {*} options
//  * @returns
//  */
// const DELETE = async (payload, options) => {
//     try {
//         axios.defaults.headers.common = {
//             "Content-Type": "application/json"
//         };
//         if (options && options.headers) {
//             const keys = Object.keys(options.headers);
//             keys.forEach(_k => {
//                 axios.defaults.headers.common[_k] = options.headers[_k]
//             });
//         }
//         return await axios({ 
//             method: 'delete',
//             url: payload.url,
//             data: payload.data
//         });
//     } catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_DELETE`, error.message);
//         throw error;
//     }
// }


// /**
//  * Apply two way auth for user
//  * @param {*} user
//  * @param {*} body
//  */
// const sendMobileOTPToProcessPayment = async (body, request) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const otp = generate(6, {
//             upperCaseAlphabets: false,
//             specialChars: false,
//             digits: true,
//             lowerCaseAlphabets: false
//         });
//         let dataToSave;
//         let otpDoc;

//         if (body.type === OTP_TYPE.PHONE_VERIFICATION) {
//         dataToSave = {
//             user_id: request.id,
//             type: SMS_TYPE.PHONE_VERIFICATION,
//         };
//         otpDoc = await findOne('otp', { user_id: request.id, type: SMS_TYPE.PHONE_VERIFICATION });
//         } else {
//         dataToSave = {
//             customer_number: body.customer_number,
//             type: SMS_TYPE.SHARE_LINK_PAYMENT_OTP,
//         };
//         if (body.payment_request_id) {
//             dataToSave.payment_request_id = body.payment_request_id;
//             otpDoc = await findOne('otp', { customer_number: body.customer_number, type: SMS_TYPE.SHARE_LINK_PAYMENT_OTP, payment_request_id: body.payment_request_id });
//         } else {
//             otpDoc = await findOne('otp', { customer_number: body.customer_number, type: SMS_TYPE.SHARE_LINK_PAYMENT_OTP });
//         }
//         }
//         const current = new Date();

//         if(otpDoc && otpDoc.send_count &&otpDoc.send_count >= SERVER.MAX_OTP_SEND_COUNT) throw MESSAGES.OTP_SEND_MAX; 
//         const data = {
//             ToPhoneNumber: body.phone_number,
//             toName: "",
//             channel: NUDGE_CHANNEL.SMS,
//             mergeTags: [
//                 { "tagName": "sms_otp", "tagValue": otp },
//             ],
//             nudgeId: nudgeConfig.phone_otp.hostid
//         };

//         if (!otpDoc) {
//             dataToSave.otp = otp;
//             dataToSave.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
//             await create('otp', dataToSave);
//         } else {
//             otpDoc.otp = otp;
//             otpDoc.valid_till = addMinutes(current, SERVER.OTP_EXIPRY_MINUTES);
//             otpDoc.wrong_otp_count = 0;
//             otpDoc.send_count = otpDoc.send_count + 1;
//             await otpDoc.save();
//         }
//         const smsData =   await sendPhone(data);
//         // Sriram K - added user_id from request.requested_by to fill in nudge_logs
//         await create('nudge_logs',{user_id: request.requested_by, email_or_phone:body.phone_number, url:smsData.config.url, status:smsData.status,status_desc:smsData.statusText, type:"SHARE_PAYMENT_OTP",errors:smsData.data.errors, hasErrors:smsData.data.hasErrors});
//         
//         if (smsData.data.hasErrors ) {
//             throw new Error(smsData.data.errors[0]);
//         } //End of changes
//         return {};
//     } catch(error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_sendOtp`, error.message);
//         if(error.error_type){
//             throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(error); 
//         }
//         throw RESPONSEMESSAGES.ERRORRESPONSE.BAD_REQUEST(MESSAGES.SOMETHING_WENT_WRONG) 
//     }
// }

// /**
//  * Send Email on Payment reversal
//  * @param {*} body
//  * @returns
//  */
// const notifyOnPaymentRevarsal = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const refundDays = `3 business days`
//         const amount = `${body.currency} ${body.amount}`
//         const data = {
//             ToEmailAddress: body.email,
//             toName: body.customer_name,
//             channel: NUDGE_CHANNEL.EMAIL,
//             mergeTags: [
//                 { "tagName": "customer_name", "tagValue": body.customer_name },
//                 { "tagName": "Refund_amount", "tagValue": amount },
//                 { "tagName": "Payment_amount", "tagValue": amount },
//                 { "tagName": "Refund_days", "tagValue": refundDays },
//             ],
//             nudgeId: nudgeConfig.notify_payment_reversal.hostid
//         };
//         const mailData =   await sendEmail(data);
//         await create('nudge_logs',{user_id: body.current_user.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status,status_desc:mailData.statusText, type:"PAYMENT_REVERSAL",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors});
//         return {};
//     } catch (error) {
//         return {}
//     }
// }

// /**
//  * Notify on failed Payment 
//  * @param {*} body 
//  * @returns 
//  */
// const notifyOnFailedpayment = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const amount = `${body.currency} ${body.amount}`
//         let  postNumber = body.postNumber.slice(body.postNumber.length - 4);
//         const requestType = body.requestType; 
//         const data = {
//             ToEmailAddress: body.email,
//             toName: body.customer_name,
//             channel: NUDGE_CHANNEL.EMAIL,
//             mergeTags: [
//                 { "tagName": "customer_name", "tagValue": body.customerName },
//                 { "tagName": "Payment_amount", "tagValue": amount },
//                 { "tagName": "last four digits of card", "tagValue": postNumber },
//                 { "tagName": "Card_type", "tagValue": requestType },
//             ],
//             nudgeId: nudgeConfig.notify_payment_failure.hostid
//         };
//         const mailData =   await sendEmail(data);
//         await create('nudge_logs',{user_id: body.current_user.id, email_or_phone:body.email, url:mailData.config.url, status:mailData.status,status_desc:mailData.statusText, type:"PAYMENT_REVERSAL",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors});
//         return {};
//     } catch (error) {
//         return {}
//     }
// }
// /**
//  * Send Email when user Submit all kyc
//  * @param {*} body
//  * @returns
//  */
// const sendMailKycSubmit = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const email = await findOne('email', {user_id: body.current_user.id})
//         const data = {
//             ToEmailAddress: email.email,
//             toName: body.current_user.full_name,
//             channel: NUDGE_CHANNEL.EMAIL,
//             mergeTags: [
//                 { "tagName": "Submerchant_name", "tagValue": body.current_user.full_name },
//             ],
//             nudgeId: nudgeConfig.notify_on_kyc_submit.hostid
//         };
//         const mailData =   await sendEmail(data);
// // Sriram K. - added user ID below - to insert to nudge_logs table.
//         await create('nudge_logs',{user_id: body.current_user.id, email_or_phone:body.phone_number, url:mailData.config.url, status:mailData.status,status_desc:mailData.statusText, type:"KYC_SUBMIT_EMAIL",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors});

//         return {};
//     } catch (error) {
//         return {}
//     }
// }
// /**
//  * Send email when user switch to Live mode
//  * @param {*} body
//  * @returns
//  */
// const sendMailLiveMode = async (body) => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const email = await findOne('email', {user_id: body.id})
//         const data = {
//             ToEmailAddress: email.email,
//             toName: body.full_name,
//             channel: NUDGE_CHANNEL.EMAIL,
//             mergeTags: [
//                 { "tagName": "Submerchant_name", "tagValue": body.full_name },
//             ],
//             nudgeId: nudgeConfig.notify_on_live_mode.hostid
//         };
//         const mailData =   await sendEmail(data);
// // Sriram K. - added user ID below - to insert to nudge_logs table.
//         await create('nudge_logs',{user_id: body.id, email_or_phone:body.phone_number, url:mailData.config.url, status:mailData.status,status_desc:mailData.statusText, type:"SWITCH_TO_LIVE_MODE_EMAIL",errors:mailData.data.errors, hasErrors:mailData.data.hasErrors});

//         return {};
//     } catch (error) {
//         return {}
//     }
// }

// /** Inform Admin at the time of Database destruption */
// const infoAdmin = async () => {
//     try {
//         const nudgeConfig = GLOBAL_OBJ['3rdPartyConfig'].nudge;
//         const data = {
//             ToEmailAddress: "support@monay.com",
//             toName: "Monay Admin",
//             channel: NUDGE_CHANNEL.EMAIL,
//             mergeTags: [ ],
//             nudgeId: nudgeConfig.notify_to_admin.hostid
//         };
//         await sendEmail(data); 
//     } catch (error) {

//     }
// }

// /**
//  * Apple Pay session Request
//  *  
//  */
// const getSession = async (body) => {
//     try {
//         let payload = {};
//         const { applepay } = GLOBAL_OBJ['3rdPartyConfig'];
//         const endpoint = applepay.endpoints.paymentSession;
//         payload.url = `${applepay.host}${endpoint}`;
//         const httpsAgent = new https.Agent({
//             // rejectUnauthorised: false, 
//             // keepAlive: true,
//             cert: merchantIdentityCert,
//             key: merchantIdentityKey,
//             // maxVersion: 'TLSv1.2',
//             // minVersion: 'TLSv1.2'
//         })
//         axios.defaults.headers.common = {
//             "Content-Type": "application/json"
//         };
//         const initiativeContext = body.initiativeContext
//         delete body.initiativeContext;
//         payload.data = body;
//         return await axios({
//             method: 'post',
//             /**  url: payload.url,  This URL will used in production*/
//             url: initiativeContext,  /** Set URL initiative context for testing */
//             data: payload.data,
//             httpsAgent
//         });  
//     } catch (error) {
//         logger.error(`error_${CURRENT_FILE_NAME}_getSession`, error.message);
//         throw error;
//     }
// }
// module.exports = {
//     sendPhone,
//     sendMobileOTPToProcessPayment,
//     sendEmail,
//     GET,
//     POST,
//     PUT,
//     PATCH,
//     DELETE,
//     sendMailKycSubmit,
//     sendMailLiveMode,
//     infoAdmin,
//     getSession,
//     notifyOnPaymentRevarsal,
//     notifyOnFailedpayment
// }