const factory = require("./handlersFactory");
const Profile = require("../models/profileModel");

// Nested route
// GET /api/v1/products/:productId/reviews
exports.createFilterObj = (req, res, next) => {
  let filterObject = {};
  if (req.params.companyId) filterObject = { company: req.params.companyId };
  req.filterObj = filterObject;
  next();
};

// @desc    Get list of reviews
// @route   GET /api/v1/reviews
// @access  Public
exports.getProfiles = factory.getAll(Profile);

// @desc    Get specific review by id 
// @route   GET /api/v1/reviews/:id
// @access  Public
exports.getProfile = factory.getOne(Profile);

// Nested route (Create)
exports.setProductIdAndUserIdToBody = (req, res, next) => {
  if (!req.body.product) req.body.profile = req.params.profileId;
  if (!req.body.user) req.body.user = req.user._id;
  next();
};
// @desc    Create review
// @route   POST  /api/v1/reviews
// @access  Private/Protect/User
exports.createProfile = factory.createOne(Profile);

// @desc    Update specific review
// @route   PUT /api/v1/reviews/:id
// @access  Private/Protect/User
exports.updateProfile = factory.updateOne(Profile);

// @desc    Delete specific review
// @route   DELETE /api/v1/reviews/:id
// @access  Private/Protect/User-Admin-Manager
exports.deleteProfile = factory.deleteOne(Profile);
