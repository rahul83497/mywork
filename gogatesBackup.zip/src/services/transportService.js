// const factory = require("./handlersFactory");
// const Transport = require("../models/transportModel");
// // const transportModel = require("../models/transportModel");



// // @desc    Get list of reviews
// // @route   GET /api/v1/reviews
// // @access  Public
// exports.getTransports = factory.getAll(Transport);

// // @desc    Get specific review by id 
// // @route   GET /api/v1/reviews/:id
// // @access  Public
// exports.getTransport = factory.getOne(Transport);

// // Nested route (Create)
// exports.setProductIdAndUserIdToBody = (req, res, next) => {
//   if (!req.body.transport) req.body.transport = req.params.transportId;
//   if (!req.body.user) req.body.user = req.user._id;
//   next();
// };
// // @desc    Create review
// // @route   POST  /api/v1/reviews
// // @access  Private/Protect/User
// exports.createTransport = factory.createOne(Transport);

// // @desc    Update specific review
// // @route   PUT /api/v1/reviews/:id
// // @access  Private/Protect/User
// exports.updateTransport = factory.updateOne(Transport);

// // @desc    Delete specific review
// // @route   DELETE /api/v1/reviews/:id
// // @access  Private/Protect/User-Admin-Manager
// exports.deleteTransport = factory.deleteOne(Transport);




// // const asyncHandler = require("express-async-handler");
// // const { v4: uuidv4 } = require("uuid");
// // const sharp = require("sharp");
// // // const multer = require("multer");
// // const { uploadMixOfImages } = require("../middlewares/uploadImageMiddleware");
// // const factory = require("./handlersFactory");
// // const Transport = require("../models/transportModel");

// // exports.uploadTransportImages = uploadMixOfImages([
// //   {
// //     name: "imageCover",
// //     maxCount: 1,
// //   },
// //   {
// //     name: "images",
// //     maxCount: 5,
// //   },
// // ]);
 
// // exports.resizeTransportImages = asyncHandler(async (req, res, next) => {
// //   console.log(req.RequestTimeout);
// //   //1- Image processing for imageCover
// //   if (req.files.imageCover) {
// //     const imageCoverFileName = `transport-${uuidv4()}-${Date.now()}-cover.jpeg`;

// //     await sharp(req.body.imageCover[0].buffer)
// //       .resize(2000, 1333)
// //       .toFormat("jpeg")
// //       .jpeg({ quality: 95 })
// //       .toFile(`uploads/transports/${imageCoverFileName}`);

// //     // Save image into our db
// //     req.body.imageCover = imageCoverFileName;
// //   }
// //   //2- Image processing for images
// //   if (req.files.images) {
// //     req.body.images = [];
// //     await Promise.all(
// //       req.files.images.map(async (img, index) => {
// //         const imageName = `transport-${uuidv4()}-${Date.now()}-${
// //           index + 1
// //         }.jpeg`;

// //         await sharp(img.buffer)
// //           .resize(2000, 1333)
// //           .toFormat("jpeg")
// //           .jpeg({ quality: 95 })
// //           .toFile(`uploads/transports/${imageName}`);

// //         // Save image into our db
// //         req.body.images.push(imageName);
// //       })
// //     );

// //     next();
// //   }
// // });

// // exports.createaccessrObj = (req, res, next) => {
// //   let accessObject = {};
// //   if (req.params.transportId)
// //     accessObject = { transport: req.params.transportId };
// //   req.accessObject = accessObject;
// //   next();
// // };
// // // exports.createaccessObj = (req, res, next) => {
// // //   let accessObject = {};
// // //   if (req.params.transportId)
// // //     accessObject = { transport: req.params.transportId };
// // //   req.accessObject = accessObject;
// // //   next();
// // // };
// // // const mycompany = req.user.compony
// // // const coinsitedoc = Transport.compony
// // // const transport = Transport.filter(mycompany=>{

// // //  if(mycompany === mycompany)
// // // });
// // // @desc    Get list of products
// // // @route   GET /api/v1/products
// // // @access  Public
// // exports.getTransports = factory.getAll(Transport);

// // // @desc    Get specific product by id
// // // @route   GET /api/v1/products/:id
// // // @access  Public
// // exports.getTransport = factory.getOne(Transport);

// // exports.setUserIdToBody = (req, res, next) => {
// //   // console.log(req.params);
// //   if (!req.body.user) req.body.user = req.user._id;
// //   if (!req.body.mycompany) req.body.mycompany = req.params.companyId;

// //   next();
// // };
// // // @desc    Create Transport
// // // @route   POST  /api/v1/Transports
// // // @access  Private
// // exports.createTransport = factory.createOne(Transport);
// // // @desc    Update specific Transport
// // // @route   PUT /api/v1/Transports/:id
// // // @access  Private
// // exports.updateTransport = factory.updateOne(Transport);

// // // @desc    Delete specific Transport
// // // @route   DELETE /api/v1/Transports/:id
// // // @access  Private
// // exports.deleteTransport = factory.deleteOne(Transport);
