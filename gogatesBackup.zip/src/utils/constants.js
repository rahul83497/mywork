'use strict';

const { v4: uuidv4 } = require('uuid');
let constants = {};

constants.SERVER = {
    ADMINPASSWORD: process.env.ADMIN_PASSWORD,
    PROJECT_NAME: `GPS Backend.`,
    JWT_SECRET: `fasdkfjklandfkdsfjladsfodfafjalfadsfkads`,
    PUSH_NOTIFICATION_SERVER_KEY: `<PUSH NOTICICATION KEY>`,
    BCRYPT_SALT: 10,
    ARRAY_FIRST_INDEX: 0,
    NOT_FOUND_INDEX: -1,
    GUEST_PREFIX: `guest_`,
    NODEMAILER_CODE: `Gmail`,
    NODEMAILER_USER: '<gmail acccount>',
    NODEMAILER_PASSWORD: '<password>',
    TOKEN_EXPIRE_IN: process.env.TOKEN_EXPIRE_IN || '60m',
    DEFAULT_OTP: '111111',
    PAYMENT_LINK_VALID_FOR: process.env.PAYMENT_LINK_VALID_FOR || 60, //Days

    AUTH_PREFIX: `demo`,
    /** Projection keys **/
    YES: 1,
    NOT: 0,
    OTP_EXIPRY_MINUTES: process.env.OTP_EXIPRY_MINUTES || 5,
    WRONG_OTP_COUNT: process.env.WRONG_OTP_COUNT || 5,
    MAX_OTP_SEND_COUNT: process.env.MAX_OTP_SEND_COUNT || 5,  
    DEFAULT_OTP_COUNT: 0
};

constants.VERIFICATION_LINKS = {
    EMAIL: 1,
    PHONE: 2
}

constants.statusCode = {
    UNAUTHORIZED: 401,
    MONGOEXPECTION: 100,
    MISSCELANEOUSAPI: 200,
    NOTFOUND: 404,
    USERALREADYEXISTS: 405,
    BADREQUEST: 400,
    SUCCESS: 200
};

constants.USER_ROLES = {
    0: "ADMIN",
    1: "CUSTOMER",
    2: "MERCHANT",
    3: "SUB_MERCHANT",
};
constants.USER_TYPE = {
    ADMIN: 1,
    CUSTOMER:2,
    COMPANYADMIN:3
};

constants.LOGIN_TYPE = {
    NORMAL: 1,
    FB: 2,
    GUEST: 3
};

constants.IMAGE_PREFIX = {
    FEED: 'feed_',
    THUMB: 'thumb_'
};

constants.AVAILABLE_AUTHS = {
    USER: 'USER'
};

constants.OTP_EXPIRY = {
    TIME_TO_ADD: 5,
    PREFIX: 'm'
};

constants.UPLOAD_DATA = {
    MEDIA: 1,
    DOC: 2,
    CSV: 3
};


constants.EMAILPATTERN = /^(([^<>()[\]\\,;:\s@\"]+(\-[^<>[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(?!yahoo.com)(?!hotmail.com)(?!yahoo.co.in)(?!aol.com)(?!live.com)(?!outlook.com)(([a-zA-Z\-0-9]+[a-zA-Z]+\.)+[a-zA-Z]{2,}))$/;
constants.ACCEPT_CHARACTER = /^[a-zA-Z]+$/;
constants.CARDMONTHPATTERN = /^(0[1-9]|1[0-2])$/;
constants.WEBSITEPATTERN = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{2,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)/;
constants.STANDARDEMAILFORMAT = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
constants.FLOATVALUEFORMAT = /^[0-1]{1}$/

constants.MESSAGES = {    
    /** INFORMATIONAL MESSAGES */
    LINK_EXPIRED: {error_code: 100, error_type: 'I', message:'Link has been expired.'},
    PLEASE_CONTACT_ADMINISTRATOR: {error_code: 101, error_type: 'I', message:'Please contact your Administrator.'},
    YOU_DON_NT_HAVE_ADMIN_ACCESS: {error_code: 102, error_type: 'I', message:`You don't have admin access!`} ,
    USER_VERIFICATION_SENT: {error_code: 103, error_type: 'I', message:'User verification sent to authenticating!'},
    USER_ALREADY_EXIST: {error_code: 104, error_type: 'I', message:'User already exists with same name/email!'},
    PASSWORD_REQUIRED: {error_code: 105, error_type: 'I', message:'Password is required.'} ,
    EMAIL_REQUIRED: {error_code: 106, error_type: 'I', message:'Email is required.'},
    OTP_SEND_MAX: {error_code: 107, error_type: 'I', message:'You have reached maximum OTP limit.'},
    NAME_REQUIRED: {error_code: 108, error_type: 'I', message:'Name is required.'},
    USER_BLOCKED: (data)=>{return {error_code: 109, error_type: 'I', message:`${data} account has been blocked.`}},
    USER_NOT_REGISTERED: {error_code: 110, error_type: 'I', message:'User is not registered.'},
    OTP_SEND_MAX_ERROR: {error_code: 111, error_type: 'R', message:'You reached maximum OTP limit, Please contact Monay Admin.'},

    
    USER_DETAIL_NOT_FOUND: {error_code: 112, error_type: 'I', message:'User details not found!'},
    AGE_IS_MORE_THAN_HUNDRED: {error_code: 113, error_type: 'I', message:'Age more than 100 years is not allowed'},
    INCOMPLETE_USER: {error_code: 114, error_type: 'I', message:'User has not completed kyc yet.'},   
    IS_REQUIRED: {error_code: 119, error_type: 'I', message:'This field is required.'},   
    EMAIL_NOT_VERIFIED: {error_code: 123, error_type: 'I', message:'Email is not verified.'},        
    MOBILE_CCC_ISSUE: {error_code: 126, error_type: 'I', message:'Country Code is required'},
    PAGES_ALREADY_EXIST: {error_code: 127, error_type: 'I', message:'This page and URL already exists'},
    COUNTRY_ALREADY_EXIST: {error_code: 128, error_type: 'I', message:'Country already exists'},    
    PLEASE_UPLOAD_LICENSE: {error_code: 130, error_type: 'I', message:'Please Upload front and back side of the Driving Licence.'},
    PLEASE_UPLOAD_PASSPORT: {error_code: 131, error_type: 'I', message:'Please Upload Passport'},
    STATES_CITIES_ALREADY_EXIST:{error_code: 132, error_type: 'I', message:'States and cities already inserted'},
    PLEASE_UPLOAD_REQUIRED_DOCUMENTS: {error_code: 133, error_type: 'I', message:'Please upload required documents'},

    RESET_PASSWORD_LINK_EXPIRED: {error_code: 136, error_type: 'I', message:'Your reset password link is expired!'},        
    AMOUNT_PAID: {error_code: 142, error_type: 'I', message:'You have already paid the amount.'},    
    OLD_PASSWORD: {error_code: 144, error_type: 'I', message:'Choose a password that is different from your last 5 passwords.'}, 
    
    ROLE_ALREADY_EXIST: {error_code: 146, error_type: 'I', message:'Role already exists'},
    CONFIG_WITH_NAME_ALREADY_EXISTS: {error_code: 147, error_type: 'I', message:'Config with this name already exists.'},
    
        
    USER_LOCK: {error_code: 151, error_type: 'I', message:'Your account is locked for 24 hours.'},
    USER_LOCK_TRY_AFTER_SOMETIME: {error_code: 152, error_type: 'I', message:'Your account is locked.'},
    PHONE_NUMBER_REQUIRED: {error_code: 153, error_type: 'I', message:'Phone number is required'},    
    ONLY_ONE_ACTIVE_USER_WITH_ADMIN_ROLE_CANNOT_INACTIVE:{error_code:464, error_type:'I', message:'ONLY_ONE_ACTIVE_USER_WITH_ADMI_ROLE_CANNOT_ACTIVE'},
    
    
    
    EMAIL_IS_ALREADY_REGISTERED: {error_code: 158, error_type: 'I', message:'Email is already registered.'},
    ENTER_BUSINESS_EMAIL: {error_code: 159, error_type: 'I', message:'Please enter business email.'},
    ENTER_VALID_BUSINESS_EMAIL: {error_code: 160, error_type: 'I', message:'Please enter a valid business email.'},
    OTP_EXPIRED: {error_code: 161, error_type: 'I', message:'OTP Expired.'},
    TWO_WAY_AUTHENTICATION_ISPENDING: {error_code: 162, error_type: 'I', message:'Two-factor authentication is pending to verify.'},
    TWO_WAY_AUTHENTICATION_CODE_SENT: {error_code: 163, error_type: 'I', message:'Your two-factor authentication code has been sent to your registered email'},
    CONTACT_ADMINISTRATOR: {error_code: 164, error_type: 'I', message:'Please contact your Administrator'},
    INVALID_PASSWORD_LENGTH: (num) => {return{error_code: 165, error_type: 'I', message:`Password length must be at least ${num} characters long.`}},
    EMAIL_IS_ALREADY_VERIFIED: (email) => {return {error_code: 166, error_type: 'I', message:`${email} email is already verified.`}},
    PHONE_IS_ALREADY_VERIFIED:(phone) =>{return {error_code: 166, error_type: 'I', message:`${phone} Mobile number is already verified.`}},
    NOT_ADMIN: {error_code: 167, error_type: 'I', message:'You are not authorized.'},
    PASSWORD_IS_NOT_STANDARD: {error_code: 171, error_type: 'I', message:'Password must be at least one lowercase, one uppercase, one numeric, Minimum 8 characters and At least one special characters..'},
    USER_ACCOUNT_NOT_VERIFIED: {error_code: 172, error_type: 'I', message: 'Account is not verified yet.'},
    INVALID_CSV_HEADER: {error_code: 166, error_type: 'I', message:`Please upload CSV file with valid data`},
    INVALID_CSV_DATA: {error_code: 166, error_type: 'I', message:`Atleast one valid row is required to create Share Pay Link`},
    NO_USER_ASSIGNED: { error_code: 167, error_type: 'I', message: `No user assigned to you, please contact admin`},
    DO_NOT_HAVE_PEGE_PERMISSION: pageName=> { return { error_code: 168, error_type: 'I', message: `You do not have permssion to access ${pageName}`}},

    /** SUCCESS MESSAGES */
    DEFAULT_SUCCESS: 'Success.',
    DEFAULT_UPDATED: 'Updated.',
    DEFAULT_DELETED: 'Deleted.',
    FUNCTIONALITY_NOT_AVAILABLE: 'Functionality not available',
    DEFAULT_SUCCESSN: {error_code: 200, error_type: 'S', message:'Success.'},
    DEFAULT_UPDATEDN: {error_code: 201, error_type: 'S', message:'Updated.'},
    DEFAULT_DELETEDN: {error_code: 202, error_type: 'S', message:'Deleted.'},
    REGISTERED_SUCCESSFULLY: {error_code: 203, error_type: 'S', message:'Registered successfully.'},
    LOGGED_IN_SUCCESSFULLY: {error_code: 204, error_type: 'S', message:'Login successful.'},
    LOGGED_OUT_SUCCESSFULLY: {error_code: 205, error_type: 'S', message:'Logged out successfully.'},
    PASSWORD_RESET_FAILED: {error_code: 207, error_type: 'S', message:'Your password reset required is failed.'},
    EMAIL_VERIFIED_SUCCESSFULLY: {error_code: 208, error_type: 'S', message:'Email verified successfully'},    
    FILE_REMOVED_SUCCESSFULLY: {error_code: 210, error_type: 'S', message:'File removed successfully.'},
    DOCUMENT_SUBMITTED_SUCCESSFULLY: {error_code: 211, error_type: 'S', message:'Document submitted successfully.'},
    EMAIL_SUCCESSFULLY_SENT: {error_code: 212, error_type: 'S', message:'Email successfully sent.'},
    
    AUTHENTICATING_VERIFICATION_SUCCESS: {error_code: 214, error_type: 'S', message:'User successfully verified from Authenticating.com'},
    PAYMENT_REQUEST_SENT_USER: {error_code: 215, error_type: 'S', message:'Payment request has been sent to respective user!'},
    PAYMENT_REQUEST_SENT: {error_code: 216, error_type: 'S', message:'Payment request sent successfully'}, 
    USER_STATUS_UPDATED: ( status, user ) => {return{error_code: 217, error_type: 'S', message:`User's status updated to ${status} by ${user} successfully.`}},
    USER_TYPE_UPDATED: ( type, user ) => {return{error_code: 218, error_type: 'S', message:`User's type updated to ${type} by ${user} successfully.`}},   
    USER_TWA_UPDATED: ( twa, user ) => {return{error_code: 220, error_type: 'S', message:`User's 2FA updated to ${twa} by ${user} successfully.`}},
    USER_UPDATED_SUCCESSFULLY: {error_code: 221, error_type: 'S', message:'User data has been updated successfully.'},
    USER_REMOVED_SUCCESSFULLY: {error_code: 222, error_type: 'S', message:'User removed successfully.'},
    OTP_VERIFY_SUCCESSFULLY: {error_code: 224, error_type: 'S', message:'OTP verified successfully'},
    OTP_SEND_SUCCESSFULLY: {error_code: 225, error_type: 'S', message:'OTP sent successfully'},     
    SAVED_SUCCESSFULLY: {error_code: 228, error_type: 'S', message:'Saved successfully.'}, 
    UPDATED_SUCCESSFULLY: {error_code: 229, error_type: 'S', message:'Updated successfully.'}, 
    REMOVED_SUCCESSFULLY: {error_code: 229, error_type: 'S', message:'Removed successfully.'}, 
    FILE_UPLOAD_SUCCESSFULLY: {error_code: 230, error_type: 'S', message:'File uploaded successfully.'}, 
    DELETED_SUCCESSFULLY: {error_code: 231, error_type: 'S', message:'Deleted successfully.'},   
    SUCCESS_MESSAGE_GLOBAL: (data, operation) => {return {error_code: 238, error_type: 'S', message: `${data} has been ${operation} successfully.`}},
    /** REDIRECTION MESSAGES */
    EMAIL_ALREADY_EXISTS: {error_code: 300, error_type: 'R', message:'Email already registered. Please enter another email.'},
    WRONG_OTP_COUNT_ERROR: {error_code: 301, error_type: 'R', message:'Your OTP is expired. Please retry.'},
    PASSWORD_RESET_OTP: {error_code: 302, error_type: 'R', message:'One Time Password has been sent to your registered email address.'},    
    
    /** ERROR MESSAGES */
    BAD_REQUEST: {error_code: 400, error_type: 'E', message:'Bad Request'},    
    INVALID_PASSWORD: {error_code: 402, error_type: 'E', message:'Invalid password'},
    INVALID_PASSWORD_OLD: {error_code: 403, error_type: 'E', message:'Your current password is wrong'},
    NOT_FOUND: {error_code: 404, error_type: 'E', message:'Not Found'},
    EMAIL_IS_NOT_REGISTERED: {error_code: 405, error_type: 'E', message:'Email is not registered.'},
    WRONG_PASSWORD_ATTEMPTS: count => {return{error_code: 406, error_type: 'E', message:`Your password is incorrect. You have ${count} ${count > 1 ? 'attempts' : 'attempt'} left.`}},
    USER_TYPE_INVALID: {error_code: 407, error_type: 'E', message:'User type is invalid!'},
    NAME_ALREADY_EXISTS: {error_code: 408, error_type: 'E', message:'Name already registered. Please enter another name!'},
    INVALID_DATA: {error_code: 409, error_type: 'E', message:'Data is not valid, please enter valid data.'},
    INVALID_TYPE: {error_code: 410, error_type: 'E', message:'You have entered an invalid type of token verification!'},
    FILE_FORMAT_NOT_SUPPORTED: {error_code: 411, error_type: 'E', message:'File format not supported!'},
    SOMETHING_WENT_WRONG: {error_code: 412, error_type: 'E', message:'Something went wrong!'},
    INVALID_OTP: {error_code: 413, error_type: 'E', message:'OTP is invalid.'},
   
    PAGE_ID_NOT_VALID: {error_code: 425, error_type: 'E', message:'Page ID is not valid'},
    MORE_THAN_ONE_IS_NOT_ALLOWED: {error_code: 426, error_type: 'E', message:'More than one value is not allowed, please verify data'},
    PERMISSION_ID_NOT_ALLOWED: {error_code: 427, error_type: 'E', message:'Permission ID not valid'},
    ROLE_ID_NOT_VALID: {error_code: 428, error_type: 'E', message:'Role ID is not valid'},
    ACCOUNT_LOCK_ATTEMPTS: count => {return{error_code: 429, error_type: 'E', message:`Your account has been locked due to ${count} failed login attempts.`}},
    USER_NOT_FOUND: {error_code: 430, error_type: 'E', message:'User not found '},

    INVALID_EXTENSION: {error_code: 431, error_type: 'E', message:'File extension is not valid!'},
    PERMISSION_NOT_ALLOWED: {error_code: 444, error_type: 'E', message:'Permission not allowed with same id and name.'},
    INVALID_EXPIRY_DATE: {error_code: 445, error_type: 'E', message:'Enter a valid expiration date.'},
    WRONG_OTP_ATTEMPTS: count => {return{error_code: 446, error_type: 'E', message:`OTP is invalid. You have ${count} ${count > 1 ? 'attempts' : 'attempt'} left.`}}, 
    WRONG_OTP_MAX: {error_code: 449, error_type: 'I', message:'You have exceeded the maximum OTP limit. Your account is locked for 24 hours.'}, 
    INVALID_RECIPIENT: {error_code: 450, error_type: 'I', message: 'Invalid recipient!'},
    PERMISSION_ALREADY_EXIST: {error_code: 451, error_type: 'E', message:'Permission already exist.'},
    REMOVE_EXISTING_PERMISSION: { error_code: 452, error_type: 'E', message: 'Role ID can not be deleted because it has some assigned permission, Please remove all assigned permissions.'},
    DO_NOT_HAVE_PERMISSION: { error_code: 453, error_type: 'E', message: "You do not have required permission."},    
    PHONE_IS_NOT_REGISTERED:{error_code: 456, error_type: 'E', message:'Phone is not registered.'},
    PAGE_CAN_NOT_BE_DELETED: { error_code: 457, error_type: 'E', message: "Page can not be deleted due to already assigned"},
    USER_ID_NULL: { error_code: 458, error_type: 'E', message: "User id can not be null"},
    CUSTOM_LOGO_NOT_ASSIGNED: { error_code: 459, error_type: 'E', message: "Company has not set custom logo to show"},
    CONTACT_PERC_NOT_ALLOWED: perce => {return{error_code: 460, error_type: 'E', message:`You can not enter value below ${perce} percentage.`}},
    INVALID_FIELD: field => {return{error_code: 461, error_type: 'E', message:`You entered an invalid data in ${field}.`}},
    INVALID_FILE_TO_UPDATE: { error_code: 462, error_type: 'E', message: 'Invalid file to update, please provide a valid file'},
    CANNOT_INACTIVE_YOURSELF:{error_code:463, error_type:'E', message:'You can not perform this operation for yourself.'},
    CANNOT_INACTIVE_USER: { error_type: 464, error_code: 'E', message: "There is only one active user with admin role, you cannot inactive it"},
    CANNOT_DELETE_USER:{error_code:465, error_type:'I',message:'There is only one active user with admin role, you cannot delete it'},
    PROFILE_NOT_COMPETED: {error_code: 470, error_type: 'E', message:'Please Complete your profile first!'},
    PAGE_PERMISSION_DOES_NOT_EXIST: {error_code: 471, error_type: 'E', message:'Page permission does not exist in db!'},
    
    CAN_NOT_BE_DELETED: input => { return { error_code: 475, error_type: 'E', message: `${input.name} can not be deleted, it's has some assigned ${input.field}`}},
    NOT_VALID: input => { return {error_code: 476, error_type: 'E', message: `Invalid ${input}, please enter valid ${input}`}},
    
    OTP_RESET_ALREADY: {error_code: 478, error_type: 'E', message:'OTP has already been reset for this user.'}, 
    OTP_RESET_SUCCESS: {error_code: 479, error_type: 'E', message:'OTP has been reset successfully.'},    
    ALREADY_EXIST: input => { return {error_code: 480, error_type: 'E', message: `${input.name}  already exist with ${input.fieldName}`}},
    PARTIAL_PAYMENT_NOT_ALLOWED: {error_code: 481, error_type: 'E', message:'Partial payment is not allowed, please make complete payment!'},
    USER_CAN_NOT_ASSIGNED_AS_SUB_USER: {error_code: 482, error_type: 'E', message: `User can not be assigned as sub-user because account already exist`},
    COMPANY_ADMIN_REDY_EXIST: {error_code: 483, error_type: 'E', message: `User can not be assigned as company admin  because admin already exist`},
    UNAUTHORIZED_TO_CREATE_COMPANY: {error_code: 483, error_type: 'E', message: `You don't have authority to create company`},
    EMAIL_NOT_VERIFIED_LINK_SHARED: {error_code: 304, error_type: 'E', message:'Your account is not verified. Please check your email.'},
    RECORDS_NOT_FOUND: {error_code: 305, error_type: 'E', message:'details not found!'},
    REMOVE_EXISTING_GATE: { error_code: 306, error_type: 'E', message: 'Gate  can not be deleted because it has some assigned company, Please remove assigned company first.'},

    /** SERVER ERROR MESSAGE */
    MONGOERROR: {error_code: 500, error_type: 'E', message:'Database error.'},
    INTERNAL_SERVER_ERROR: {error_code: 500, error_type: 'E', message:'Internal server error.'},
    UNAUTHORIZED: 'Un-authorized access.',
    /** End of changes */

};


constants.EMAIL_TYPES = {
    FORGOT_PASSWORD: 1
};

constants.SENDINBLUE = {
    EMAILFORSENDINGEMAIL: ['<registere-email>', 'From'], 
};

constants.SUBJECT_OF_EMAILS = {
    FORGOT_PASSWORD: 'Forgot password'
};


constants.AUTH_REQUEST_TYPE = {
    CREATE: 'CREATE',
    UPDATE: 'UPDATE',
    SUBMIT_CONSENT: 'SUBMIT_USER_CONSENT',    
    DRIVING_LICENCE_VERIFICATION: 'DRIVING_LICENCE_VERIFICATION',
    DRIVING_LICENCE_VERIFICATION_STATUS: 'DRIVING_LICENCE_VERIFICATION_STATUS',
    DRIVING_LICENCE_VERIFICATION_DONE: 'DRIVING_LICENCE_VERIFICATION_DONE',
    RC_VERIFICATION: 'RC_VERIFICATION',
    RC_VERIFICATION: 'RC_VERIFICATION_STATUS',
    RC_VERIFICATION: 'RC_VERIFICATION_DONE',    
}



constants.BASE_ATTRIBUTES = {
    INVOLVE: {
        EMAIL_ATTRIBUTE: ['email', 'user_id', 'is_verified'],
        KYC_FILE_ATTRIBUTE: ['id','document_type', 'front', 'back','document_name', 'status', 'reason', 'verified_by']
    },
    EXCLUDE: {
        USER_EXCLUDE: ['createdAt', 'updatedAt'],
        ACCOUNT_EXCLUDE: ['createdAt', 'updatedAt', 'first_name', 'last_name', 'full_name', 'dob', 'other_info_id', 'address_id', 'boarding_id', 'contact_id', 'phone_id', 'contact_id'],
        PHONE_EXCLUDE: ['createdAt', 'updatedAt'],
        ADDRESS_EXCLUDE: ['createdAt', 'updatedAt'],
        BOARDING_EXCLUDE: ['createdAt', 'updatedAt'],
        CONTACT_EXCLUDE: ['createdAt', 'updatedAt', 'valid_till'],
        OTHER_INFO_EXCLUDE: ['createdAt', 'updatedAt', 'user_id', 'account_id'],
        EMAIL_EXCLUDE: ['createdAt', 'updatedAt']
    }
}

constants.DOCUMENT_TYPES = {
    DRIVING_LICENCE: 'DRIVING_LICENCE',
    REGISTRATION_CERTIFICATE: 'REGISTRATION_CERTIFICATE'
}

constants.COUNTRIES = [
    {
        name: 'United States',
        code: 'US',
        states: [
            {
                name: 'District of Columbia',
                code: 'DC',
                country_code: 'US',
                cities: [
                    {
                        name: 'Washington',
                        code: 'WA',
                        state_code: 'DC',
                    }
                ]
            },
            {
                name: 'Florida',
                code: 'FL',
                country_code: 'US',
                cities: [
                    {
                        name: 'Miami',
                        code: 'MI',
                        state_code: 'FL',
                    },
                    {
                        name: 'Jacksonville',
                        code: 'JA',
                        state_code: 'FL',
                    }
                ]
            }
        ]
    }
]

constants.CUSTOME_ERROR_CODE_TO_MESSAGE = {
    [constants.MESSAGES.PASSWORD_HAS_BEEN_EXPIRE]: 401
}

/**
 * Error and success custom respose functions
 * @type {{ERROR: {DATA_NOT_FOUND: function(*=, *=), BAD_REQUEST: function(*=, *=), MONGO_EXCEPTION: function(*=, *=), ALREADY_EXISTS: function(*=, *=), FORBIDDEN: function(*=), INTERNAL_SERVER_ERROR: function(*=, *=), UNAUTHORIZED: function(*=)}, SUCCESS: {MISSCELANEOUSAPI: function(*=)}}}
 */
constants.RESPONSEMESSAGES = {
    ERROR: {
        DATA_NOT_FOUND: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: code || 404,
                message: msg
            };
        },
        FAILED_REQUEST: (msg) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 400,
                message: msg
            };
        },
        BAD_REQUEST: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: code || 400,
                message: msg
            };
        },
        MONGO_EXCEPTION: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: code || 100,
                message: msg
            };
        },
        ALREADY_EXISTS: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: code || 409,
                message: msg
            };
        },
        FORBIDDEN: (msg) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 403,
                message: msg
            };
        },
        INTERNAL_SERVER_ERROR: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: code || 500,
                message: msg
            };
        },
        UNAUTHORIZED: (msg) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 401,
                message: msg
            };
        },
        PAYMENT_ENGINE_CUSTOM: (error, msg)=> { 
            if(msg){
                error.responseMessage = `${msg}`
            }
            return {error_code:error.responseCode, message:error.responseMessage}
        },
        PAYMENT_ENGINE_LOGIN_FAILED: (error)=>{                             
            return {error_code: error.response.data.statusCode || 400,message: error.response.data.statusDesc || error.message || "Failed with status code 400"};
        }
    },
    ERRORRESPONSE: { 
        BAD_REQUEST: (msg, code) => {
            if (!msg) {
                msg = '';
            }
            return {
                hasError: true,
                data: {},
                error: msg
                // error: { code: code || 400, error_type: 'E', message: msg }
            };
        },
        VALIDATION_ERROR: (msg, code) => {
            if (!msg) {    
                msg = '';
            }
            return {
                hasError: true,
                data: {},
                error: {error_code: code || 400, error_type: 'E', message: msg}
            };
        },
        UNAUTHORIZED: (msg) => {
            if (!msg) {
                msg = '';
            }
            return {
                hasError: true,
                data: {},
                error: {error_code: 401, error_type: 'E', message: msg}

            };
        }
    },
    SUCCESS: {
        MISSCELANEOUSAPI: (msg, data) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 200,
                message: msg,
                data: data || {}
            }
        },
        REDIRECTION: (msg, data) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 301,
                message: msg,
                data: data || {}
            }
        },
        DOWNLOADFILE: (msg, data) => {
            if (!msg) {
                msg = '';
            }
            return {
                code: 201,
                message: msg,
                data: data || {}
            }
        }
    },
    SUCCESSRESPONSE: {
        MISSCELANEOUSAPI: (msg, data) => {
            if (!msg) {
                msg = '';
            }
            return {
                hasError: false,
                error: msg,
                data: data || {},
            }
        }
    }
};

constants.swaggerDefaultResponseMessages = [
    {code: 200, message: 'OK'},
    {code: 400, message: 'Bad Request'},
    {code: 401, message: 'Unauthorized'},
    {code: 404, message: 'Data Not Found'},
    {code: 500, message: 'Internal Server Error'}
];




module.exports = constants;