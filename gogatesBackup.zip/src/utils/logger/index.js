const winston = require('./bin');
module.exports = winston;