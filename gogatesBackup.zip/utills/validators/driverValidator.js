const slugify = require("slugify");
const { check, body } = require("express-validator");
const Driver = require("../../models/driverwModel");
const validatorMiddleware = require("../../middlewares/validatorMiddleware");
exports.createDriverValidator = [
  check("drivers").isMongoId().withMessage("Invalid Driver id format"),

  check("user").isMongoId().withMessage("Invalid Driver id format"),
  check("transport").isMongoId().withMessage("Invalid Driver id format"),
  // .custom((val, { req }) =>
  //   // Check if logged user create Driver before
  //   Driver.findOne({ user: req.user._id, product: req.body.product }).then(
  //     (Driver) => {
  //       console.log(Driver);
  //       if (Driver) {
  //         return Promise.reject(
  //           new Error("You already created a Driver before")
  //         );
  //       }
  //     }
  //   )
  // ),
  validatorMiddleware,
];

exports.getDriverValidator = [
  check("id").isMongoId().withMessage("Invalid Driver id format"),
  validatorMiddleware,
];

exports.updateDriverValidator = [
  check("id").isMongoId().withMessage("Invalid Driver id format"),
  // .custom((val, { req }) =>
  //   // Check Driver ownership before update
  //   Driver.findById(val).then((Driver) => {
  //     if (!Driver) {
  //       return Promise.reject(new Error(`There is no Driver with id ${val}`));
  //     }

  //     if (Driver.user._id.toString() !== req.user._id.toString()) {
  //       return Promise.reject(
  //         new Error(`Your are not allowed to perform this action`)
  //       );
  //     }
  //   })
  // ),
  validatorMiddleware,
];

exports.deleteDriverValidator = [
  check("id").isMongoId().withMessage("Invalid Driver id format"),
  // .custom((val, { req }) => {
  //   // Check Driver ownership before update
  //   if (req.user.role === "user") {
  //     return Driver.findById(val).then((driver) => {
  //       if (!driver) {
  //         return Promise.reject(
  //           new Error(`There is no driver with id ${val}`)
  //         );
  //       }
  //       if (driver.user._id.toString() !== req.user._id.toString()) {
  //         return Promise.reject(
  //           new Error(`Your are not allowed to perform this action`)
  //         );
  //       }
  //     });
  //   }
  //   return true;
  // }),
  validatorMiddleware,
];
