const { check } = require("express-validator");
const validatorMiddleware = require("../../middlewares/validatorMiddleware");

exports.getGateValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
exports.creatGateValidator = [
  check("name")
    .notEmpty()
    .withMessage("company name required")
    .isLength({ min: 3 })
    .withMessage("too short company name")
    .isLength({ max: 32 })
    .withMessage("too Long company name"),
  validatorMiddleware,
];
exports.updateGateValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
exports.deleteGateValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
