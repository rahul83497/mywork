const { check } = require("express-validator");
const validatorMiddleware = require("../../middlewares/validatorMiddleware");
// const Transport = require("../../models/transportModel");
exports.getTransportValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
exports.creatTransportValidator = [
  check("name")
    .notEmpty()
    .withMessage("الرجاء اختيار اسم النقل")
    .isLength({ min: 4 })
    .withMessage("الاسم قصير")
    .isLength({ max: 100 })
    .withMessage("too Long company name"),
  check("companys").optional(),
  check("imageCover").optional(),
  check("images").optional(),

  validatorMiddleware,
];
exports.updateTransportValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
exports.deleteTransportValidator = [
  check("id").isMongoId().withMessage("in valalid id"),
  validatorMiddleware,
];
 